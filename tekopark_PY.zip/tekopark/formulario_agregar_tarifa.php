<?php
include_once "encabezado.php";
$dias = ['lun'=>'Lunes','mar'=>'Martes','mie'=>'Miércoles','jue'=>'Jueves','vie'=>'Viernes','sab'=>'Sábado','dom'=>'Domingo'];
?>
<div class="row">
    <div class="col-12">
        <h1>Agregar Tarifa</h1>
        <form action="guardar_tarifa.php" method="POST">
            <div class="form-group">
                <label for="actividad">Actividad</label>
                <input type="text" name="actividad" id="actividad" class="form-control" required>
            </div>

            <!-- DÍAS -->
            <div class="form-group mt-2">
                <label class="d-block">Días activos</label>
                <?php foreach ($dias as $c=>$n): ?>
                    <label class="me-2">
                        <input type="checkbox" name="dias[]" value="<?= $c ?>"> <?= $n ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="form-group mt-2">
                <label for="duracion">Duración</label>
                <select name="duracion" id="duracion" class="form-control" required>
                    <option value="30">30 Minutos</option>
                    <option value="60">1 Hora</option>
                    <option value="90">1 Hora y Media</option>
                    <option value="120">2 Horas</option>
                </select>
            </div>

            <div class="form-group mt-2">
                <label for="precio">Precio</label>
                <input type="number" step="1" name="precio" id="precio" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-success mt-3">Guardar</button>
        </form>
    </div>
</div>
