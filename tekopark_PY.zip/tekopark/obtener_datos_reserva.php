<?php
include_once "conexion.php";

if (isset($_POST['id'])) {
    $reserva_id = $_POST['id'];

    // Obtener la tarifa y la cantidad de clientes desde la reserva seleccionada
    $query = "
        SELECT r.cantidad_clientes, t.precio 
        FROM reservas r
        INNER JOIN tarifas t ON r.tarifa_id = t.id
        WHERE r.id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $reserva_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $reserva = $result->fetch_assoc();

    // Retornar los datos en formato JSON
    echo json_encode($reserva);
    exit;
}
?>
