
<?php
include_once "conexion.php";

// Función para obtener el precio de un producto por nombre
function obtenerPrecioPorNombre($nombre) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, precio FROM productos WHERE nombre = ?");
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Función para obtener el descuento de bonificación
function obtenerBonificacion($bonificacion_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT descuento FROM bonificaciones WHERE id = ?");
    $stmt->bind_param("i", $bonificacion_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc()['descuento'] ?? 0; // Retorna 0 si no hay bonificación
}

// Verificar si se recibe una solicitud AJAX para obtener el precio
if (isset($_POST['action']) && $_POST['action'] === 'obtener_precio_producto') {
    $nombre = $_POST['nombre'];
    $producto = obtenerPrecioPorNombre($nombre);
    echo json_encode($producto);
    exit;
}

// Guardar venta en la base de datos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_venta'])) {
    $reserva_id = $_POST['reserva_id'];
    $colaborador_id = $_POST['colaborador'];
    $productos = json_decode($_POST['productos'], true);
    $bonificacion_id = $_POST['bonificacion'];
    $modo_pago = $_POST['modo_pago'];

    if (empty($reserva_id) || empty($colaborador_id) || empty($productos) || empty($modo_pago)) {
        error_log("Faltan datos: reserva_id: $reserva_id, colaborador_id: $colaborador_id, productos: " . json_encode($productos) . ", modo_pago: $modo_pago");
        echo json_encode(['success' => false, 'error' => 'Faltan datos']);
        exit;
    }
    // Calcular total de la venta
    $total_venta = 0;
    foreach ($productos as $producto) {
        $total_venta += $producto['cantidad'] * $producto['precio_unitario'];
    }

    // Agregar subtotal de la tarifa
    $subtotal_tarifa = $_POST['subtotal_tarifa']; // Asegúrate de enviar este dato
    $total_venta += $subtotal_tarifa;

    // Aplicar bonificación si está seleccionada
    if ($bonificacion_id) {
        $bonificacion = obtenerBonificacion($bonificacion_id);
        $total_venta -= ($total_venta * ($bonificacion / 100));
    }

    // Insertar la venta
    $stmt = $conn->prepare("INSERT INTO ventas (reserva_id, colaborador_id, bonificacion_id, total, modo_pago) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiids", $reserva_id, $colaborador_id, $bonificacion_id, $total_venta, $modo_pago);

    if ($stmt->execute()) {
        $venta_id = $stmt->insert_id; // Obtener el ID de la venta recién creada
        // Insertar los detalles de los productos
        foreach ($productos as $producto) {
                $producto_id = $producto['id'];
                $cantidad = $producto['cantidad'];
                $precio_unitario = $producto['precio_unitario'];
                $total_producto = $cantidad * $precio_unitario; // Calcular el total del producto
            
                $stmtDetalle = $conn->prepare("INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario, total) VALUES (?, ?, ?, ?, ?)");
                $stmtDetalle->bind_param("iiddd", $venta_id, $producto_id, $cantidad, $precio_unitario, $total_producto); // Cambia iisd por isddd
            
                if (!$stmtDetalle->execute()) {
                    error_log("Error al insertar detalle de venta: " . $stmtDetalle->error); // Log para ver errores
                }
        }
        // Generar el ticket en formato HTML para la impresión
        generarTicketVenta($venta_id, $total_venta, $productos, $modo_pago, $subtotal_tarifa, $bonificacion);
        echo json_encode(['success' => true]);
    } else {
        error_log("Error al insertar la venta: " . $stmt->error); // Log para ver errores
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    exit;
}

// Función para generar el ticket de venta
function generarTicketVenta($venta_id, $total_venta, $productos, $modo_pago, $subtotal_tarifa, $bonificacion) {
    echo '<div id="ticket">';
    echo '<h2>Ticket de Venta #'.$venta_id.'</h2>';
    echo '<hr>';
    echo '<p><strong>Subtotal tarifa:</strong> $'.number_format($subtotal_tarifa, 2).'</p>';
    echo '<table border="1" cellpadding="10" cellspacing="0">';
    echo '<thead>';
    echo '<tr><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th>Total</th></tr>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($productos as $producto) {
        echo '<tr>';
        echo '<td>'.$producto['nombre'].'</td>';
        echo '<td>'.$producto['cantidad'].'</td>';
        echo '<td>$'.number_format($producto['precio_unitario'], 2).'</td>';
        echo '<td>$'.number_format($producto['cantidad'] * $producto['precio_unitario'], 2).'</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '<hr>';
    echo '<p><strong>Total Venta:</strong> $'.number_format($total_venta, 2).'</p>';
    echo '<p><strong>Modo de Pago:</strong> '.$modo_pago.'</p>';
    if ($bonificacion) {
        echo '<p><strong>Bonificación aplicada:</strong> '.$bonificacion.'%</p>';
    }
    echo '<button onclick="window.print()">Imprimir Ticket</button>';
    echo '</div>';
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>
<body>
<div class="container mt-5">
    <h1>Registrar Venta</h1>
    <div class="card mb-3">
        <div class="card-body">
            <form id="ventaForm">
                <input type="hidden" name="guardar_venta" value="1">
                <div class="row">
                    <div class="col-md-6">
                        <label for="reserva_id" class="form-label">Seleccionar Reserva</label>
                        <select name="reserva_id" id="reserva_id" class="form-select" required>
                            <?php
                            $reservas = $conn->query("SELECT id, codigo_reserva FROM reservas WHERE estado = 'pendiente'");
                            while ($row = $reservas->fetch_assoc()) {
                                echo "<option value=\"{$row['id']}\">{$row['codigo_reserva']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="colaborador" class="form-label">Seleccionar Vendedor</label>
                        <select name="colaborador" id="colaborador" class="form-select" required>
                            <?php
                            $colaboradores = $conn->query("SELECT id, nombre FROM colaboradores");
                            while ($row = $colaboradores->fetch_assoc()) {
                                echo "<option value=\"{$row['id']}\">{$row['nombre']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-6">
                        <label for="tarifa" class="form-label">Tarifa</label>
                        <input type="text" id="tarifa" class="form-control" readonly>
                    </div>
                    <div class="col-md-6">
                        <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
                        <input type="number" id="cantidad_clientes" class="form-control" readonly>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header">Productos</div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="producto" class="form-label">Buscar Producto</label>
                    <input type="text" id="producto" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="cantidad" class="form-label">Cantidad</label>
                    <input type="number" id="cantidad" class="form-control" value="1">
                </div>
            </div>
            <button id="agregarProducto" class="btn btn-primary mb-3">Agregar Producto</button>
            <table id="productos-list" class="table">
                <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card mb-3">
        <div class="card-body">
            <h3>Totales</h3>
            <p><strong>Subtotal tarifa:</strong> $<span id="subtotal-tarifa">0.00</span></p>
            <p><strong>Total Venta:</strong> $<span id="total-venta">0.00</span></p>
        </div>
    </div>

</div>

<script>
    $(document).ready(function() {
        // Búsqueda de productos
        $("#producto").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "venta.php",
                    method: "POST",
                    data: {
                        action: "obtener_precio_producto",
                        nombre: request.term
                    },
                    success: function(data) {
                        response($.map(JSON.parse(data), function(item) {
                            return {
                                label: item.nombre,
                                value: item.id
                            };
                        }));
                    }
                });
            },
            select: function(event, ui) {
                $("#producto").val(ui.item.label);
                return false;
            }
        });

        // Agregar productos a la tabla
        $("#agregarProducto").click(function() {
            var nombreProducto = $("#producto").val();
            var cantidad = $("#cantidad").val();

            $.ajax({
                url: "venta.php",
                method: "POST",
                data: {
                    action: "obtener_precio_producto",
                    nombre: nombreProducto
                },
                success: function(data) {
                    var producto = JSON.parse(data);
                    var totalProducto = producto.precio * cantidad;
                    var newRow = `<tr data-id="${producto.id}">
                                    <td>${nombreProducto}</td>
                                    <td>${cantidad}</td>
                                    <td>$${producto.precio}</td>
                                    <td>$${totalProducto.toFixed(2)}</td>
                                    <td><button class="eliminar-producto btn btn-danger">Eliminar</button></td>
                                  </tr>`;
                    $("#productos-list tbody").append(newRow);
                    $("#producto").val('');
                    $("#cantidad").val(1);
                    calcularTotal();
                }
            });
        });

        // Función para calcular el total de la venta
        function calcularTotal() {
            var totalVenta = parseFloat($("#subtotal-tarifa").text()) || 0;

            $("#productos-list tr").each(function() {
                var totalProducto = parseFloat($(this).find("td:eq(3)").text().replace("$", "")) || 0;
                totalVenta += totalProducto;
            });

            // Actualizar el total en la interfaz
            $("#total-venta").text(totalVenta.toFixed(2));
        }

        // Evento para eliminar un producto de la lista
        $(document).on('click', '.eliminar-producto', function() {
            $(this).closest('tr').remove();
            calcularTotal();
        });

        // Evento para guardar la venta
        $("#ventaForm").submit(function(e) {
            e.preventDefault();

            var formData = $(this).serializeArray();
            var productos = [];
            $("#productos-list tr").each(function() {
                productos.push({
                    id: $(this).data("id"),
                    cantidad: $(this).find("td:eq(1)").text(),
                    precio_unitario: $(this).find("td:eq(2)").text().replace("$", "")
                });
            });

            formData.push({ name: "productos", value: JSON.stringify(productos) });

            $.ajax({
                url: "venta.php",
                method: "POST",
                data: formData,
                success: function(response) {
                    var data = JSON.parse(response);
                    if (data.success) {
                        alert("Venta registrada exitosamente");
                        location.reload();
                    } else {
                        alert("Error al registrar la venta: " + data.error);
                    }
                }
            });
        });
    });
</script>
</body>
</html>
