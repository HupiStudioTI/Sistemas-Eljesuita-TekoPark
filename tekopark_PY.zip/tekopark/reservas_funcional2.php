<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <style>
        .estado-pendiente {
            background-color: #ffcc80 !important;
            color: #333;
        }
        .estado-pagada {
            background-color: #a5d6a7 !important;
            color: #333;
        }
        .estado-cancelada {
            background-color: #ef9a9a !important;
            color: #333;
        }
        .pagination .page-item.active .page-link {
            background-color: #007bff;
            border-color: #007bff;
        }
        .pagination .page-link {
            border: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
<?php
include_once "encabezado.php";
include_once "conexion.php";

// Recibir el término de búsqueda
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';

// Definir la cantidad de registros por página
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Modificar la consulta para incluir la búsqueda
$sql = "SELECT r.id, r.codigo_reserva, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, r.estado,
           (SELECT c.nombre 
            FROM clientes c 
            INNER JOIN clientes_reserva cr ON c.id = cr.cliente_id 
            WHERE cr.reserva_id = r.id 
            LIMIT 1
           ) AS cliente_nombre
    FROM reservas r
    LEFT JOIN clientes_reserva cr ON r.id = cr.reserva_id
    LEFT JOIN clientes c ON c.id = cr.cliente_id
    WHERE r.codigo_reserva LIKE '%$buscar%'
    OR r.fecha_reserva LIKE '%$buscar%'
    OR r.estado LIKE '%$buscar%'
    OR c.nombre LIKE '%$buscar%'
    OR c.telefono LIKE '%$buscar%'
    OR c.documento LIKE '%$buscar%'
    GROUP BY r.id
    ORDER BY r.fecha_reserva DESC, r.estado ASC
    LIMIT $inicio, $registros_por_pagina";

$result = $conn->query($sql);

// Contar el total de reservas para la paginación (con el filtro de búsqueda)
$total_reservas = $conn->query("SELECT COUNT(DISTINCT r.id) as total 
    FROM reservas r
    LEFT JOIN clientes_reserva cr ON r.id = cr.reserva_id
    LEFT JOIN clientes c ON c.id = cr.cliente_id
    WHERE r.codigo_reserva LIKE '%$buscar%'
    OR r.fecha_reserva LIKE '%$buscar%'
    OR r.estado LIKE '%$buscar%'
    OR c.nombre LIKE '%$buscar%'
    OR c.telefono LIKE '%$buscar%'
    OR c.documento LIKE '%$buscar%'")->fetch_assoc()['total'];

$total_paginas = ceil($total_reservas / $registros_por_pagina);
?>

<div class="container mt-5">
    <h1>Reservas</h1>
    <a href="formulario_reserva.php" class="btn btn-success mb-3">Agregar Reserva</a>

    <!-- Buscador -->
    <form method="GET" action="reservas.php" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por código de reserva, cliente, fecha, etc." value="<?php echo htmlspecialchars($buscar); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Código Reserva</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Hs Desde</th>
                <th>Hs Hasta</th>
                <th>Cant.Clientes</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Asignar clase según el estado
                    $estado_clase = '';
                    switch ($row['estado']) {
                        case 'pendiente':
                            $estado_clase = 'estado-pendiente';
                            break;
                        case 'pagada':
                            $estado_clase = 'estado-pagada';
                            break;
                        case 'cancelada':
                            $estado_clase = 'estado-cancelada';
                            break;
                    }
                ?>
                    <tr class="<?php echo $estado_clase; ?>">
                        <td><?php echo $row["id"]; ?></td>
                        <td><?php echo $row["codigo_reserva"]; ?></td>
                        <td><?php echo $row["cliente_nombre"] ? $row["cliente_nombre"] : "Sin cliente"; ?></td>
                        <td><?php echo $row["fecha_reserva"]; ?></td>
                        <td><?php echo $row["hora_desde"]; ?></td>
                        <td><?php echo $row["hora_hasta"]; ?></td>
                        <td><?php echo $row["cantidad_clientes"]; ?></td>
                        <td><?php echo ucfirst($row["estado"]); ?></td>
                        <td>
                            <a href="edit_reserva.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                        </td>
<!--                        <td>
                            <a href="eliminar_reserva.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                        </td>-->
                        <td>
                            <button class="btn btn-primary btn-sm" onclick="imprimirTicket(<?php echo $row['id']; ?>)">Imprimir</button>
                        </td>
                    </tr>
                <?php }
            } else { ?>
                <tr><td colspan="10">No se encontraron reservas.</td></tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <nav>
        <ul class="pagination">
            <?php if ($pagina_actual > 1) { ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual - 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Anterior</a>
                </li>
            <?php } ?>
            <?php for ($i = 1; $i <= $total_paginas; $i++) { ?>
                <li class="page-item <?php echo $i == $pagina_actual ? 'active' : ''; ?>">
                    <a class="page-link" href="?pagina=<?php echo $i; ?>&buscar=<?php echo urlencode($buscar); ?>"><?php echo $i; ?></a>
                </li>
            <?php } ?>
            <?php if ($pagina_actual < $total_paginas) { ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual + 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Siguiente</a>
                </li>
            <?php } ?>
        </ul>
    </nav>
</div>

<?php include_once "pie.php"; ?>
<script>
function imprimirTicket(idReserva) {
    // Realiza una solicitud AJAX para obtener los datos de la reserva
    $.ajax({
        url: 'obtener_datos_reservaticket.php', // Este archivo se encargará de obtener los datos de la reserva desde la base de datos.
        type: 'GET',
        data: { id: idReserva },
        success: function(response) {
            // Recibimos los datos de la reserva y generamos un ticket imprimible
            let datosReserva = JSON.parse(response);
            let ventanaImpresion = window.open('', '_blank', 'width=600,height=600');
            ventanaImpresion.document.write('<html><head><title>Ticket de Reserva</title></head><body>');
            ventanaImpresion.document.write('<h1>Ticket de Reserva</h1>');
            ventanaImpresion.document.write('<p><strong>Código de Reserva:</strong> ' + datosReserva.codigo_reserva + '</p>');
            ventanaImpresion.document.write('<p><strong>Cliente:</strong> ' + datosReserva.cliente_nombre + '</p>');
            ventanaImpresion.document.write('<p><strong>Fecha:</strong> ' + datosReserva.fecha_reserva + '</p>');
            ventanaImpresion.document.write('<p><strong>Hora Desde:</strong> ' + datosReserva.hora_desde + '</p>');
            ventanaImpresion.document.write('<p><strong>Hora Hasta:</strong> ' + datosReserva.hora_hasta + '</p>');
            ventanaImpresion.document.write('<p><strong>Cantidad de Clientes:</strong> ' + datosReserva.cantidad_clientes + '</p>');
            ventanaImpresion.document.write('<p><strong>Estado:</strong> ' + datosReserva.estado + '</p>');
            ventanaImpresion.document.write('</body></html>');
            ventanaImpresion.document.close();
            ventanaImpresion.focus();
            ventanaImpresion.print();
            ventanaImpresion.close();
        }
    });
}
</script>

</body>
</html>
