<?php
// guardar_reserva.php
include_once "funciones.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener y sanitizar los datos del formulario
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $codigo_reserva = isset($_POST['codigo_reserva']) ? trim($_POST['codigo_reserva']) : '';
    $actividad = isset($_POST['actividad']) ? trim($_POST['actividad']) : '';
    $tarifa_id = isset($_POST['tarifa_id']) ? intval($_POST['tarifa_id']) : null;
    $fecha_reserva = isset($_POST['fecha_reserva']) ? trim($_POST['fecha_reserva']) : '';
    $hora_desde = isset($_POST['hora_desde']) ? trim($_POST['hora_desde']) : '';
    $hora_hasta = isset($_POST['hora_hasta']) ? trim($_POST['hora_hasta']) : '';
    $cantidad_clientes = isset($_POST['cantidad_clientes']) ? intval($_POST['cantidad_clientes']) : 0;
    $estado = isset($_POST['estado']) ? trim($_POST['estado']) : 'pendiente';
    
    // Obtener clientes e identificaciones
    $clientes = isset($_POST['clientes']) ? $_POST['clientes'] : [];
    $identificaciones = isset($_POST['identificaciones']) ? $_POST['identificaciones'] : [];
    
    // Validaciones básicas
    $errores = [];
    if (empty($codigo_reserva)) $errores[] = "El código de reserva es obligatorio.";
    if (empty($actividad)) $errores[] = "La actividad es obligatoria.";
    if (empty($tarifa_id)) $errores[] = "La tarifa es obligatoria.";
    if (empty($fecha_reserva)) $errores[] = "La fecha de reserva es obligatoria.";
    if (empty($hora_desde)) $errores[] = "La hora desde es obligatoria.";
    if ($cantidad_clientes <= 0) $errores[] = "La cantidad de clientes debe ser al menos 1.";
    if (count($clientes) != $cantidad_clientes || count($identificaciones) != $cantidad_clientes) {
        $errores[] = "Número de clientes e identificaciones no coincide con la cantidad especificada.";
    }
    
    if (!empty($errores)) {
        // Manejar errores (puedes redirigir con mensajes de error)
        echo "<div class='container mt-5'>";
        foreach ($errores as $error) {
            echo "<div class='alert alert-danger'>{$error}</div>";
        }
        echo "<a href='javascript:history.back()' class='btn btn-secondary'>Volver</a>";
        echo "</div>";
        exit;
    }
    
    // Iniciar transacción
    $bd = obtenerBD();
    $bd->beginTransaction();
    
    try {
        if ($id) {
            // Actualizar reserva existente
            actualizarReserva($id, $codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado);
            // Eliminar clientes existentes asociados a la reserva
            $sqlDelete = "DELETE FROM clientes_reserva WHERE reserva_id = :reserva_id";
            $stmtDelete = $bd->prepare($sqlDelete);
            $stmtDelete->execute([':reserva_id' => $id]);
        } else {
            // Agregar nueva reserva
            $id = agregarReserva($codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado);
        }
        
        // Asociar clientes a la reserva
        asociarClientesReserva($id, $clientes, $identificaciones);
        
        // Confirmar transacción
        $bd->commit();
        
        // Redirigir con mensaje de éxito
        header("Location: reservas.php?mensaje=Reserva guardada exitosamente.");
        exit;
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $bd->rollBack();
        echo "<div class='container mt-5'><div class='alert alert-danger'>Error al guardar la reserva: " . $e->getMessage() . "</div></div>";
        exit;
    }
} else {
    // Acceso no permitido
    header("Location: reservas.php");
    exit;
}
?>
