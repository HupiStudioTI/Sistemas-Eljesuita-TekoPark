<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php
include_once "encabezado.php";
include_once "conexion.php";
// Recibir el término de búsqueda
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';
// Definir la cantidad de registros por página
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;
// Modificar la consulta para incluir la búsqueda
$sql = "SELECT id, fecha, total, modo_pago from ventas
    ORDER BY fecha DESC 
    LIMIT $inicio, $registros_por_pagina";
$result = $conn->query($sql);
// Contar el total de reservas para la paginación (con el filtro de búsqueda)
$total_ventas = $conn->query("SELECT COUNT(DISTINCT id) as total 
    FROM ventas
    WHERE fecha  LIKE '%$buscar%'
    OR reserva_id LIKE '%$buscar%'
    OR id LIKE '%$buscar%'")->fetch_assoc()['total'];
$total_paginas = ceil($total_ventas / $registros_por_pagina);
?>
<div class="container mt-5">
    <h1>Ventas</h1>
    <a href="sales.php" class="btn btn-success mb-3">Registrar Venta</a>
    <!-- Buscador -->
    <form method="GET" action="ventas.php" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por id, id de reserva, fecha." value="<?php echo htmlspecialchars($buscar); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Total $</th>
                <th>Modo de Pago</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                ?>
                    <tr class="<?php echo $estado_clase; ?>">
                        <td><?php echo $row["id"]; ?></td>
                        <td><?php echo $row["fecha"]; ?></td>
                        <td><?php echo $row["total"]; ?></td>
                        <td><?php echo $row["modo_pago"]; ?></td>
                        <td>
                            <a href="eliminar_venta.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                        </td>
                    </tr>
                <?php }
            } else { ?>
                <tr><td colspan="10">No se encontraron ventas.</td></tr>
            <?php } ?>
        </tbody>
    </table>
    <!-- Paginación -->
    <nav>
        <ul class="pagination">
            <?php if ($pagina_actual > 1) { ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual - 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Anterior</a>
                </li>
            <?php } ?>
            <?php for ($i = 1; $i <= $total_paginas; $i++) { ?>
                <li class="page-item <?php echo $i == $pagina_actual ? 'active' : ''; ?>">
                    <a class="page-link" href="?pagina=<?php echo $i; ?>&buscar=<?php echo urlencode($buscar); ?>"><?php echo $i; ?></a>
                </li>
            <?php } ?>
            <?php if ($pagina_actual < $total_paginas) { ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual + 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Siguiente</a>
                </li>
            <?php } ?>
        </ul>
    </nav>
</div>
<?php include_once "pie.php"; ?>
</body>
</html>