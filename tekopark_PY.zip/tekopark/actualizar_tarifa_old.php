<?php
include_once 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $actividad = $_POST['actividad'];
    $nombretarifa = $_POST['nombretarifa'];
    $dias = $_POST['dias'];
    $duracion = $_POST['duracion'];
    $precio = $_POST['precio'];

    // Actualizar en la base de datos
    $conn = obtenerBD();
    $query = $conn->prepare("UPDATE tarifas SET actividad = :actividad,nombretarifa = :nombretarifa,  dias = :dias, duracion = :duracion, precio = :precio WHERE id = :id");
    $query->bindParam(':actividad', $actividad);
    $query->bindParam(':nombretarifa', $nombretarifa);    
    $query->bindParam(':dias', $dias);
    $query->bindParam(':duracion', $duracion);
    $query->bindParam(':precio', $precio);
    $query->bindParam(':id', $id, PDO::PARAM_INT);

    if ($query->execute()) {
        header('Location: tarifas.php?mensaje=Tarifa actualizada correctamente');
        exit;
    } else {
        echo 'Error al actualizar la tarifa.';
    }
} else {
    echo 'Solicitud no válida.';
}
