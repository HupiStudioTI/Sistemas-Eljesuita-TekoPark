<?php
include_once "funciones.php";

$busqueda = isset($_GET['query']) ? $_GET['query'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$inicio = ($pagina - 1) * $registros_por_pagina;

// Obtener las compras
$compras = obtenerComprasPaginadas($busqueda, $inicio, $registros_por_pagina);
$total_compras = contarTotalCompras($busqueda);
$total_paginas = ceil($total_compras / $registros_por_pagina);

echo json_encode([
    'compras' => $compras,
    'total_paginas' => $total_paginas,
    'pagina_actual' => $pagina
]);
?>
