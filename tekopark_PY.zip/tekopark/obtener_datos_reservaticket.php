<?php
// obtener_datos_reservaticket.php
header('Content-Type: application/json');
include_once "conexion.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Consulta para obtener los datos de la reserva
    $sql = "SELECT r.codigo_reserva, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, r.estado,
                   (SELECT c.nombre 
                    FROM clientes c 
                    INNER JOIN clientes_reserva cr ON c.id = cr.cliente_id 
                    WHERE cr.reserva_id = r.id 
                    LIMIT 1
                   ) AS cliente_nombre
            FROM reservas r
            WHERE r.id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $datosReserva = $result->fetch_assoc();
        echo json_encode($datosReserva);
    } else {
        echo json_encode(['error' => 'Reserva no encontrada.']);
    }
} else {
    echo json_encode(['error' => 'ID de reserva no proporcionado.']);
}
?>
