<?php
include_once "conexion.php";
include_once "funciones.php";

// Verifica que el método sea POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recoger y limpiar datos del formulario
    $nombre           = trim($_POST["nombre"] ?? '');
    $nombre_fantasia  = trim($_POST["nombre_fantasia"] ?? '');
    $direccion        = trim($_POST["direccion"] ?? '');
    $ciudad           = trim($_POST["ciudad"] ?? '');
    $telefono         = trim($_POST["telefono"] ?? '');
    $email            = trim($_POST["email"] ?? '');
    $nrodocumento     = trim($_POST["nrodocumento"] ?? '');

    // Validación básica
    if (empty($nombre)) {
        echo "El nombre del proveedor es obligatorio.";
        exit;
    }

    // Preparar e insertar en la base de datos
    $sql = "INSERT INTO proveedores (nombre, nombre_fantasia, direccion, ciudad, telefono, email, nrodocumento, activo) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Error en la preparación: " . $conn->error;
        exit;
    }

    $stmt->bind_param("sssssss", $nombre, $nombre_fantasia, $direccion, $ciudad, $telefono, $email, $nrodocumento);
    
    if ($stmt->execute()) {
        header("Location: proveedores.php");
        exit;
    } else {
        echo "Error al guardar el proveedor: " . $stmt->error;
    }
} else {
    echo "Acceso no permitido.";
}
?>
