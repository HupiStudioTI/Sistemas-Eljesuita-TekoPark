<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Bonificaciones</h3>
    <h5>Administre aquí las bonificaciones disponibles.</h5>
</div>
</div>';
include 'encabezado.php';
include_once 'conexion.php';

// Variables de búsqueda y paginación
$busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Consulta principal con búsqueda
$sql = "SELECT * FROM bonificaciones WHERE nombre LIKE ? LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$searchParam = "%$busqueda%";
$stmt->bind_param("sii", $searchParam, $inicio, $registros_por_pagina);
$stmt->execute();
$result = $stmt->get_result();

// Total de bonificaciones para la búsqueda
$total_bonificaciones_sql = "SELECT COUNT(*) as total FROM bonificaciones WHERE nombre LIKE ?";
$total_stmt = $conn->prepare($total_bonificaciones_sql);
$total_stmt->bind_param("s", $searchParam);
$total_stmt->execute();
$total_bonificaciones_result = $total_stmt->get_result();
$total_bonificaciones = $total_bonificaciones_result->fetch_assoc()['total'];

$total_paginas = ceil($total_bonificaciones / $registros_por_pagina);
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="add_bonificaciones.php" class="btn btn-success btn-sm">Agregar Bonificación</a>
                <form id="buscador-form" class="d-flex" action="bonificaciones.php" method="get">
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por nombre" value="<?php echo htmlspecialchars($busqueda); ?>">
                    <button type="submit" class="btn btn-primary btn-sm">Buscar</button>
                </form>
            </div>

            <!-- Tabla de bonificaciones -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descuento (%)</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo $row["nombre"]; ?></td>
                                    <td><?php echo $row["descuento"]; ?></td>
                                    <td>
                                        <a href="edit_bonificaciones.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                                        <a href="delete_bonificaciones.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que deseas eliminar esta bonificación?');">Eliminar</a>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="4" class="text-center">No se encontraron resultados.</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center">
                    <?php for ($i = 1; $i <= $total_paginas; $i++) { ?>
                        <li class="page-item <?php echo $pagina_actual === $i ? 'active' : ''; ?>">
                            <a class="page-link" href="?busqueda=<?php echo urlencode($busqueda); ?>&pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
