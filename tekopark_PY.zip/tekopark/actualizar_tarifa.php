<?php
include_once 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id           = (int)($_POST['id']           ?? 0);
    $actividad    = $_POST['actividad']          ?? '';
    $nombretarifa = $_POST['nombretarifa']       ?? '';
    $duracion     = $_POST['duracion']           ?? 0;
    $precio       = $_POST['precio']             ?? 0;

    /*  Nuevo: array → cadena */
    $diasArray = $_POST['dias'] ?? [];
    $dias      = implode(',', $diasArray);

    $conn = obtenerBD();
    $sql  = "UPDATE tarifas
             SET actividad = :actividad,
                 nombretarifa = :nombretarifa,
                 dias = :dias,
                 duracion = :duracion,
                 precio = :precio
             WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $ok   = $stmt->execute([
        ':actividad'    => $actividad,
        ':nombretarifa' => $nombretarifa,
        ':dias'         => $dias,
        ':duracion'     => $duracion,
        ':precio'       => $precio,
        ':id'           => $id
    ]);

    header('Location: tarifas.php?mensaje=' . ($ok ? 'Tarifa actualizada correctamente' : 'Error al actualizar'));
    exit;
}
echo 'Solicitud no válida.';
