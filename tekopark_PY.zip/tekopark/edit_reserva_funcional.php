<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Reserva</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
</head>
<body>
<?php
include_once "encabezado.php";
include_once "funciones.php";

$reserva_id = isset($_GET['id']) ? $_GET['id'] : null;

if ($reserva_id) {
    $db = obtenerbd();
    $stmt = $db->prepare("SELECT * FROM reservas WHERE id = :id");
    $stmt->execute(['id' => $reserva_id]);
    $reserva = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmtClientes = $db->prepare("
        SELECT clientes_reserva.cliente_id, clientes.nombre, clientes_reserva.identificacion 
        FROM clientes_reserva
        JOIN clientes ON clientes.id = clientes_reserva.cliente_id
        WHERE clientes_reserva.reserva_id = :reserva_id
    ");
    $stmtClientes->execute(['reserva_id' => $reserva_id]);
    $clientes_reserva = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);
} else {
    header("Location: reservas.php");
    exit;
}

$tarifas = obtenerTarifas();
$actividades = obtenerDepartamentos();
?>
<div class="container mt-5">
    <h1>Editar Reserva</h1>
    <form action="guardar_reserva.php" method="post" id="reservaForm">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($reserva['id']); ?>">
        <div class="mb-3">
            <label for="codigo_reserva" class="form-label">Código de Reserva</label>
            <input type="text" class="form-control" id="codigo_reserva" name="codigo_reserva" value="<?php echo htmlspecialchars($reserva['codigo_reserva']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="actividad" class="form-label">Actividad</label>
            <select id="actividad" name="actividad" class="form-select" required>
                <option value="">Seleccione una actividad</option>
                <?php foreach ($actividades as $actividad) { ?>
                    <option value="<?php echo htmlspecialchars($actividad); ?>" <?php echo $actividad == $reserva['actividad'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($actividad); ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="tarifa_id" class="form-label">Tarifa</label>
            <select id="tarifa_id" name="tarifa_id" class="form-select" required>
                <option value="">Seleccione una tarifa</option>
                <?php foreach ($tarifas as $tarifa) { ?>
                    <option value="<?php echo htmlspecialchars($tarifa->id); ?>"
                        <?php echo (int)$tarifa->id === (int)$reserva['tarifa_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars("{$tarifa->actividad} - {$tarifa->nombretarifa} ({$tarifa->dias}) - {$tarifa->duracion} minutos - \${$tarifa->precio}"); ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="fecha_reserva" class="form-label">Fecha de Reserva</label>
            <input type="date" class="form-control" id="fecha_reserva" name="fecha_reserva" value="<?php echo htmlspecialchars($reserva['fecha_reserva']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="hora_desde" class="form-label">Hora Desde</label>
            <input type="time" class="form-control" id="hora_desde" name="hora_desde" value="<?php echo htmlspecialchars($reserva['hora_desde']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="hora_hasta" class="form-label">Hora Hasta</label>
            <input type="time" class="form-control" id="hora_hasta" name="hora_hasta" value="<?php echo htmlspecialchars($reserva['hora_hasta']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
            <input type="number" class="form-control" id="cantidad_clientes" name="cantidad_clientes" value="<?php echo htmlspecialchars(count($clientes_reserva)); ?>" required>
        </div>
        <div id="clientes_container">
            <?php
            foreach ($clientes_reserva as $i => $cliente) {
                ?>
                <div class="mb-3">
                    <label for="cliente_<?php echo $i + 1; ?>" class="form-label">Cliente <?php echo $i + 1; ?></label>
                    <input type="text" class="form-control cliente_search" id="cliente_<?php echo $i + 1; ?>" name="cliente_<?php echo $i + 1; ?>" value="<?php echo htmlspecialchars($cliente['nombre']); ?>" required>
                    <input type="hidden" name="clientes[]" class="cliente_id" value="<?php echo htmlspecialchars($cliente['cliente_id']); ?>">
                    <span class="form-text">Identificación: <?php echo htmlspecialchars($cliente['identificacion']); ?></span>
                </div>
                <?php
            }
            ?>
        </div>
        <div class="mb-3">
            <label for="estado" class="form-label">Estado</label>
            <select id="estado" name="estado" class="form-select" required>
                <option value="pendiente" <?php echo $reserva['estado'] == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                <option value="pagada" <?php echo $reserva['estado'] == 'pagada' ? 'selected' : ''; ?>>Pagada</option>
                <option value="cancelada" <?php echo $reserva['estado'] == 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
    </form>
</div>

<script>
$(document).ready(function() {
    // Función para autocompletar clientes
    $('.cliente_search').autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "buscar_clientes.php",
                method: "GET",
                dataType: "json",
                data: { query: request.term },
                success: function(data) {
                    response($.map(data, function(item) {
                        return {
                            label: item.nombre + " (" + item.telefono + ")",
                            value: item.id
                        };
                    }));
                }
            });
        },
        select: function(event, ui) {
            $(this).siblings('.cliente_id').val(ui.item.value);
            $(this).val(ui.item.label);
            return false;
        }
    });

    // Añadir campos de clientes dinámicamente si es necesario
    $('#cantidad_clientes').on('input', function() {
        let cantidad = $(this).val();
        let container = $('#clientes_container');
        container.empty();

        for (let i = 1; i <= cantidad; i++) {
            container.append(`
                    <div class="mb-3">
                        <label for="cliente_${i}" class="form-label">Cliente ${i}</label>
                        <input type="text" class="form-control cliente_search" id="cliente_${i}" name="cliente_${i}" placeholder="Buscar cliente por nombre, teléfono, etc." required>
                        <input type="hidden" name="clientes[]" class="cliente_id">
                    </div>
                    <div class="mb-3">
                        <label for="identificacion_${i}" class="form-label">Identificación del Cliente ${i}</label>
                        <input type="text" class="form-control" id="identificacion_${i}" name="identificaciones[]" placeholder="Ejemplo: FLACO, MOROCHO, CON SOMBRERO" required>
                    </div>
                `);
            // Inicializar autocomplete
            $(`#cliente_${i}`).autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: "buscar_clientes.php",
                        method: "GET",
                        dataType: "json",
                        data: { query: request.term },
                        success: function(data) {
                            response($.map(data, function(item) {
                                return {
                                    label: item.nombre + " (" + item.telefono + ")",
                                    value: item.id
                                };
                            }));
                        }
                    });
                },
                select: function(event, ui) {
                    $(this).siblings('.cliente_id').val(ui.item.value);
                    $(this).val(ui.item.label);
                    return false;
                }
            });
        }
    });
});
</script>

<?php include_once "pie.php"; ?>
</body>
</html>

