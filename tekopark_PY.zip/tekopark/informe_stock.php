<?php
include 'encabezado.php';
include_once 'funciones.php';

// Obtener la lista de productos para el filtro (se asume que tienes una función obtenerProductos())
$productos = obtenerProductos(); 

// Procesar los filtros enviados por GET
$fecha_inicio = isset($_GET['fecha_inicio']) ? $_GET['fecha_inicio'] : '';
$fecha_fin    = isset($_GET['fecha_fin']) ? $_GET['fecha_fin'] : '';
$id_producto  = isset($_GET['id_producto']) ? $_GET['id_producto'] : '';

// Se consulta la base de datos para obtener los movimientos de stock según los filtros
// Se asume que tienes una función obtenerMovimientosStock($fecha_inicio, $fecha_fin, $id_producto)
$movimientos = obtenerMovimientosStock($fecha_inicio, $fecha_fin, $id_producto);

if (isset($_GET['export_pdf'])) {
    // Exportar el informe a PDF usando TCPDF
    require_once('tcpdf/tcpdf.php');
    
    // Crear nuevo documento PDF
    $pdf = new TCPDF();
    $pdf->AddPage();
    
    // Construir el contenido HTML del PDF
    $html = '<h2>Informe de Stock</h2>';
    $html .= '<p>Fecha de impresión: ' . date('d/m/Y') . '</p>';
    $html .= '<table border="1" cellpadding="4">
                <tr>
                    <th>ID</th>
                    <th>Producto</th>
                    <th>Fecha</th>
                    <th>Movimiento</th>
                    <th>Cantidad</th>
                </tr>';
    foreach ($movimientos as $mov) {
        $html .= '<tr>
                    <td>' . $mov['id'] . '</td>
                    <td>' . $mov['producto'] . '</td>
                    <td>' . $mov['fecha'] . '</td>
                    <td>' . $mov['tipo_movimiento'] . '</td>
                    <td>' . $mov['cantidad'] . '</td>
                  </tr>';
    }
    $html .= '</table>';
    
    // Escribir el contenido en el PDF
    $pdf->writeHTML($html, true, false, true, false, '');
    
    // Enviar el PDF al navegador
    $pdf->Output('informe_stock.pdf', 'I');
    exit;
}
?>

<div class="container mt-5">
    <h3>Informe de Stock</h3>
    <form method="get" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <label>Fecha Inicio</label>
                <input type="date" name="fecha_inicio" class="form-control" value="<?php echo $fecha_inicio; ?>">
            </div>
            <div class="col-md-3">
                <label>Fecha Fin</label>
                <input type="date" name="fecha_fin" class="form-control" value="<?php echo $fecha_fin; ?>">
            </div>
            <div class="col-md-3">
                <label>Producto</label>
                <select name="id_producto" class="form-control">
                    <option value="">Todos</option>
                    <?php foreach($productos as $producto): ?>
                        <option value="<?php echo $producto['id']; ?>" <?php if($id_producto == $producto['id']) echo 'selected'; ?>>
                            <?php echo $producto['nombre']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 align-self-end">
                <button type="submit" class="btn btn-primary">Filtrar</button>
                <button type="submit" name="export_pdf" value="1" class="btn btn-danger">Exportar PDF</button>
            </div>
        </div>
    </form>

    <!-- Mostrar movimientos filtrados -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Producto</th>
                    <th>Fecha</th>
                    <th>Movimiento</th>
                    <th>Cantidad</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($movimientos)): ?>
                    <?php foreach($movimientos as $mov): ?>
                    <tr>
                        <td><?php echo $mov['id']; ?></td>
                        <td><?php echo $mov['producto']; ?></td>
                        <td><?php echo $mov['fecha']; ?></td>
                        <td><?php echo $mov['tipo_movimiento']; ?></td>
                        <td><?php echo $mov['cantidad']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No se encontraron movimientos.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
