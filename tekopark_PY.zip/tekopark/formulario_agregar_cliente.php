<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Clientes</h3>
</div>
</div>';
include_once "encabezado.php";
include_once "funciones.php";
$departamentos = obtenerDepartamentos();
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form id="cliente-form" action="guardar_cliente.php" method="post">
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input required type="text" class="form-control form-control-sm" name="nombre" id="nombre" placeholder="Nombre">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="documento" class="form-label" style="font-size: 0.9rem;">Nº Documento</label>
                        <input required type="text" class="form-control form-control-sm" name="documento" id="documento" placeholder="Número de Documento">
                    </div>
                    <div class="col-md-2 mb-2">
                        <label for="fechanac" class="form-label" style="font-size: 0.9rem;">Fecha Nac.</label>
                        <input required type="date" class="form-control form-control-sm" name="fechanac" id="fechanac">
                    </div>
                    <div class="col-md-1 mb-2">
                        <label for="edad" class="form-label" style="font-size: 0.9rem;">Edad</label>
                        <span name="edad" id="edad">0</span>
                        <input type="hidden" name="edad" id="hiddenEdad" value="0">
                    </div>
                    <div class="col-md-1 mb-2">
                        <label for="sexo" class="form-label" style="font-size: 0.9rem;">Sexo</label>
                        <select name="sexo" id="sexo" class="form-control form-control-sm">
                            <option value="Masculino">Masculino</option>
                            <option value="Femenino">Femenino</option>
                            <option value="Sin Datos">Sin Datos</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <label for="departamento" class="form-label" style="font-size: 0.9rem;">Actividad</label>
                        <select class="form-control form-control-sm" name="departamento" id="departamento">
                            <?php foreach ($departamentos as $departamento) { ?>
                                <option value="<?php echo $departamento ?>"><?php echo $departamento ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="ciudad" class="form-label" style="font-size: 0.9rem;">Ciudad</label>
                        <input required type="text" class="form-control form-control-sm" name="ciudad" id="ciudad" placeholder="Ciudad">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="tel" class="form-label" style="font-size: 0.9rem;">Tel. / Whatsapp</label>
                        <input required type="text" class="form-control form-control-sm" name="tel" id="tel" placeholder="Nº Tel. o Whatsapp">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="email" class="form-label" style="font-size: 0.9rem;">Email</label>
                        <input type="email" class="form-control form-control-sm" name="email" id="email" placeholder="Correo electrónico">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <label for="padre" class="form-label" style="font-size: 0.9rem;">Padre/Tutor</label>
                        <input type="text" class="form-control form-control-sm" name="padre" id="padre" placeholder="Nombre del Padre o Tutor">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="docpadre" class="form-label" style="font-size: 0.9rem;">Doc. Padre/Tutor</label>
                        <input type="text" class="form-control form-control-sm" name="docpadre" id="docpadre" placeholder="Doc. del Padre o Tutor">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="telpadre" class="form-label" style="font-size: 0.9rem;">Tel. Padre/Tutor</label>
                        <input type="text" class="form-control form-control-sm" name="telpadre" id="telpadre" placeholder="Nº Tel. o Whatsapp">
                    </div>
                </div>
                <div class="form-group mb-2">
                    <label for="obs" class="form-label" style="font-size: 0.9rem;">Observaciones</label>
                    <input type="text" class="form-control form-control-sm" name="obs" id="obs" placeholder="Observaciones">
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para mostrar errores -->
<div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="errorModalLabel">Verificación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                El número de documento o email ya existe.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    function calcularEdad(fechaNacimiento) {
        const hoy = new Date();
        const nacimiento = new Date(fechaNacimiento);
        let edad = hoy.getFullYear() - nacimiento.getFullYear();
        const mes = hoy.getMonth() - nacimiento.getMonth();
        if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
            edad--;
        }
        return edad;
    }

    $('#fechanac').on('change', function() {
        const edad = calcularEdad(this.value);
        $('#edad').text(edad);
        $('#hiddenEdad').val(edad);
    });

    function verificarExistencia() {
        var documento = $('#documento').val();
        var email = $('#email').val();

        $.ajax({
            url: 'verificar.php',
            type: 'POST',
            data: { documento: documento, email: email },
            dataType: 'json',
            success: function(response) {
                if (response.exists) {
                    $('#errorModal').modal('show');
                    $('#cliente-form').find('button[type="submit"]').prop('disabled', true);
                } else {
                    $('#cliente-form').find('button[type="submit"]').prop('disabled', false);
                }
            }
        });
    }

    $('#documento, #email').on('input', function() {
        verificarExistencia();
    });
});
</script>
<?php include "footer.php"; ?>
