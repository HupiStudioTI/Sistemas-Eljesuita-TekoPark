<?php
require_once 'conexion.php';
require_once 'funciones.php';

if (!isset($_GET['id'])) {
    echo "No se especificó la compra a eliminar.";
    exit;
}

$compra_id = intval($_GET['id']);
$pdo = obtenerBD();

try {
    $pdo->beginTransaction();

    // Obtener detalles de la compra para revertir el stock
    $stmt = $pdo->prepare("SELECT producto_id, cantidad FROM detalle_compras WHERE compra_id = ?");
    $stmt->execute([$compra_id]);
    $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($detalles as $detalle) {
        // Dado que en una compra se suma stock, al eliminar la compra se debe restar la cantidad\n
        $stmtUp = $pdo->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?");
        $stmtUp->execute([$detalle['cantidad'], $detalle['producto_id']]);
    }

    // Eliminar detalles de la compra
    $stmt = $pdo->prepare("DELETE FROM detalle_compras WHERE compra_id = ?");
    $stmt->execute([$compra_id]);

    // Eliminar la compra
    $stmt = $pdo->prepare("DELETE FROM compras WHERE id = ?");
    $stmt->execute([$compra_id]);

    // Opcional: eliminar movimientos de stock relacionados a esta compra si los registraste con algún criterio único.
    // Por ejemplo, si guardaste la fecha de la compra en movimientos_stock, podrías eliminarlos.
    // $stmt = $pdo->prepare("DELETE FROM movimientos_stock WHERE tipo_movimiento = 'COMPRA' AND fecha = (SELECT fecha_compra FROM compras WHERE id = ?)");
    // $stmt->execute([$compra_id]);

    $pdo->commit();
    header("Location: compras.php?eliminado=1");
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error al eliminar la compra: " . $e->getMessage();
}
?>
