<?php
require_once 'conexion.php';
require_once 'funciones.php';
session_start();

// Conexión PDO
$pdo = obtenerBD();

/**
 * Función para traer productos (con unidad de medida si es que la usas).
 * Si no la usas, quita unidad_medida del SELECT.
 */
function obtenerProductosConUnidad() {
    global $pdo;
    $stmt = $pdo->query("
        SELECT id, nombre, unidad_medida 
        FROM productos
        ORDER BY nombre
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Cargamos la lista de productos
$productos = obtenerProductosConUnidad();

// Insertar nuevo componente
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['id_producto_principal'], $_POST['id_producto_componente'], $_POST['cantidad'])) 
{
    $stmt = $pdo->prepare("
        INSERT INTO productos_componentes (id_producto_principal, id_producto_componente, cantidad)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([
        $_POST['id_producto_principal'],
        $_POST['id_producto_componente'],
        $_POST['cantidad']
    ]);
    // Redirigir para evitar reenvío
    header("Location: asignar_componentes.php?id=" . $_POST['id_producto_principal']);
    exit;
}

// Eliminar componente
if (isset($_GET['eliminar']) && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM productos_componentes WHERE id = ?");
    $stmt->execute([$_GET['eliminar']]);
    header("Location: asignar_componentes.php?id=" . $_GET['id']);
    exit;
}

// Producto principal
$idProductoPrincipal = $_GET['id'] ?? null;
$componentes = [];

// Si hay producto principal seleccionado, cargamos sus componentes
if ($idProductoPrincipal) {
    $stmt = $pdo->prepare("
        SELECT 
            pc.*,
            p.nombre AS nombre_componente,
            p.unidad_medida AS umc
        FROM productos_componentes pc
        JOIN productos p ON pc.id_producto_componente = p.id
        WHERE pc.id_producto_principal = ?
        ORDER BY p.nombre
    ");
    $stmt->execute([$idProductoPrincipal]);
    $componentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Asignar Componentes a Producto</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/select2.min.css" rel="stylesheet">
    <style>
        .select2-container .select2-selection--single {
            height: 38px;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 38px;
        }
    </style>
</head>
<body class="container mt-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">🧩 Asignar Componentes a Producto</h3>
        <!-- Botón Volver -->
        <a href="productos.php" class="btn btn-secondary">Volver</a>
    </div>

    <!-- Seleccionar producto principal -->
    <form method="GET" class="mb-4">
        <label for="id" class="form-label">Producto Principal</label>
        <select 
            class="form-select select2"
            name="id"
            id="id"
            onchange="this.form.submit()"
            required
        >
            <option value="">-- Seleccionar --</option>
            <?php foreach ($productos as $prod): ?>
                <option 
                    value="<?= $prod['id'] ?>"
                    <?= ($prod['id'] == $idProductoPrincipal) ? 'selected' : '' ?>
                >
                    <?= $prod['nombre'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <!-- Solo mostramos el formulario si hay producto principal -->
    <?php if ($idProductoPrincipal): ?>
        <form method="POST" class="row g-3 mb-4">
            <input type="hidden" name="id_producto_principal" value="<?= $idProductoPrincipal ?>">

            <div class="col-md-6">
                <label for="id_producto_componente" class="form-label">Componente</label>
                <select 
                    class="form-select select2"
                    name="id_producto_componente"
                    id="id_producto_componente"
                    required
                >
                    <option value="">-- Seleccionar --</option>
                    <?php foreach ($productos as $prod): ?>
                        <?php if ($prod['id'] != $idProductoPrincipal): ?>
                            <option
                                value="<?= $prod['id'] ?>"
                            >
                                <?= $prod['nombre'] ?>
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label for="cantidad" class="form-label">Cantidad</label>
                <!-- step=any para permitir decimales como .150, 0.150, etc. -->
                <input 
                    type="number"
                    name="cantidad"
                    id="cantidad"
                    class="form-control"
                    step="any"
                    min="0"
                    required
                >
            </div>

            <div class="col-md-3 align-self-end">
                <button type="submit" class="btn btn-success w-100">
                    Agregar Componente
                </button>
            </div>
        </form>

        <!-- Tabla de componentes -->
        <h5>Componentes actuales</h5>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Producto Componente</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th style="width: 50px;"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($componentes as $comp): ?>
                    <?php
                        // Convertir la cantidad a float
                        $cantidadNum = (float)$comp['cantidad'];
                        // Si es KG o LT => 3 decimales, sino entero
                        if ($comp['umc'] === 'KG' || $comp['umc'] === 'LT') {
                            $cantidadFormateada = number_format($cantidadNum, 3, '.', '');
                        } else {
                            $cantidadFormateada = number_format($cantidadNum, 0, '.', '');
                        }
                    ?>
                    <tr>
                        <td><?= $comp['nombre_componente'] ?></td>
                        <td><?= $cantidadFormateada ?></td>
                        <td><?= $comp['umc'] ?></td>
                        <td>
                            <a 
                                href="?id=<?= $idProductoPrincipal ?>&eliminar=<?= $comp['id'] ?>"
                                class="btn btn-danger btn-sm"
                                title="Eliminar"
                            >
                                🗑️
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($componentes)): ?>
                    <tr>
                        <td colspan="4">No hay componentes asignados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <script src="js/jquery.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
            // No necesitamos mostrar la unidad en un input, pues la retiramos
        });
    </script>
</body>
</html>
