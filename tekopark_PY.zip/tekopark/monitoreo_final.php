<?php
// monitoreo.php
include_once "conexion.php";

// Establecer la zona horaria a Buenos Aires
date_default_timezone_set('America/Argentina/Buenos_Aires');

// ---------------------
// 1. Procesar Ajax
// ---------------------

// Escanear la pulsera
if (isset($_POST['action']) && $_POST['action'] === 'scan') {
    $pulsera = trim($_POST['pulsera']);

    // Buscar el último registro de esa pulsera en monitore
    $sqlCheck = "SELECT * 
                 FROM monitore 
                 WHERE pulsera = ? 
                 ORDER BY id DESC 
                 LIMIT 1";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $pulsera);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck && $resCheck->num_rows > 0) {
        // Hay al menos un registro previo
        $lastRow = $resCheck->fetch_assoc();
        
        if ($lastRow['estado'] === 'en_juego') {
            // Finalizamos el turno actual
            $updateSql = "UPDATE monitore SET estado = 'finalizado' WHERE id = ?";
            $stmtUpd = $conn->prepare($updateSql);
            $stmtUpd->bind_param("i", $lastRow['id']);
            $stmtUpd->execute();

            echo json_encode([
                'success' => true,
                'msg' => 'Pulsera finalizada: ' . $pulsera,
                'finalizado' => true
            ]);
            exit;

        } else {
            // Si ya fue finalizada no se permite reingreso
            echo json_encode([
                'success' => false,
                'msg' => 'Pulsera ya fue finalizada, no se permite reingreso.'
            ]);
            exit;
        }

    } else {
        // No hay registros anteriores en monitore para esta pulsera
        // Verificamos si existe en clientes_reserva
        $sql = "SELECT cr.cliente_id, cr.reserva_id, cr.nombre, cr.identificacion, r.codigo_reserva,
                       r.hora_desde, r.hora_hasta, v.color_value as color
                FROM clientes_reserva cr
                INNER JOIN reservas r ON cr.reserva_id = r.id
                LEFT JOIN ventas v ON v.reserva_id = r.id
                WHERE cr.pulsera = ?
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pulsera);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            // Obtener la fecha y hora actual (cuando se escanea la pulsera)
            $fechaEscaneo  = date('Y-m-d H:i:s'); 
            $clienteId     = $row['cliente_id'];
            $reservaId     = $row['reserva_id'];
            $nombreCl      = $row['nombre'];
            $identiCl      = $row['identificacion'];
            $codigoReserva = $row['codigo_reserva'];
            // Valor de color; si no es válido se asigna un predeterminado
            $color = isset($row['color']) ? trim($row['color']) : '';
            if(!$color || strtolower($color) === 'sincolor') {
                $color = '#ccc';
            }
            // Calcular la duración contratada en segundos (basada en hora_hasta y hora_desde)
            $durationSeconds = strtotime($row['hora_hasta']) - strtotime($row['hora_desde']);
            // Calcular la nueva hora de fin a partir del escaneo
            $newHoraFin = date('H:i:s', strtotime($fechaEscaneo) + $durationSeconds);

            // Insertar en la tabla monitore con estado='en_juego'
            $insertSql = "INSERT INTO monitore 
                (pulsera, cliente_id, reserva_id, codigo_reserva, nombre_cliente, identificacion_cliente, 
                 color, fecha_escaneo, hora_fin, estado) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'en_juego')";
            $stmtInsert = $conn->prepare($insertSql);
            $stmtInsert->bind_param("siissssss", 
                $pulsera, 
                $clienteId, 
                $reservaId, 
                $codigoReserva,
                $nombreCl, 
                $identiCl, 
                $color, 
                $fechaEscaneo, 
                $newHoraFin
            );
            $stmtInsert->execute();

            echo json_encode([
                'success' => true,
                'msg' => 'Pulsera registrada: ' . $pulsera
            ]);
            exit;

        } else {
            // Pulsera no encontrada en clientes_reserva
            echo json_encode([
                'success' => false,
                'msg' => 'Pulsera no encontrada en clientes_reserva'
            ]);
            exit;
        }
    }
}

// Listar sólo los que estén "en_juego"
if (isset($_POST['action']) && $_POST['action'] === 'listar') {
    $sql = "SELECT id, pulsera, nombre_cliente, identificacion_cliente, color, fecha_escaneo, hora_fin
            FROM monitore
            WHERE estado = 'en_juego'
            ORDER BY fecha_escaneo DESC";
    $result = $conn->query($sql);

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Monitoreo de Clientes en Juego</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Fuente digital (Orbitron) desde Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">

  <style>
    /* Reset y tipografía básica */
    html, body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      font-size: 24px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      background: #fff;
    }

    /* Contenedor principal */
    #main-container {
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;
      padding: 1rem;
    }

    /* Caja con borde fucsia */
    .fucsia-box {
      width: 100%;
      border: 4px solid fuchsia;
      padding: 1rem;
      box-sizing: border-box;
      border-radius: 8px;
      color: #000;
    }

    /* Encabezado: título y reloj */
    .header-container {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-wrap: wrap;
      gap: 1rem;
      margin-bottom: 1rem;
    }
    .header-container h1 {
      margin: 0;
      font-size: 1.5rem;
    }
    #clock {
      font-family: 'Orbitron', sans-serif;
      font-size: 3rem;
      color: #0f0;
      font-weight: bold;
      min-width: 130px;
      text-align: center;
      text-shadow: 0 0 10px #0f0;
    }

    /* Campo de escaneo */
    .scan-input {
      display: block;
      margin: 0 auto 1rem auto;
      font-size: 1.2rem;
      padding: 0.5rem;
      width: 80%;
      max-width: 400px;
      text-align: center;
      box-sizing: border-box;
    }

    /* Tabla */
    #listado {
      width: 100%;
      box-sizing: border-box;
      padding: 1rem 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      color: #000;
      table-layout: auto;
      font-size: 1.2rem;
    }
    th, td {
      border-bottom: 1px solid #000;
      padding: 0.75rem;
      vertical-align: middle;
    }
    th {
      text-align: left;
    }
    .color-box {
      display: inline-block;
      width: 20px;
      height: 20px;
      margin-right: 4px;
      vertical-align: middle;
      border: 1px solid #ccc;
    }

    /* Estilos para animaciones según tiempo restante */
    .verde {
      background-color: #ccffcc; /* Verde claro */
    }
    .blinking-orange {
      animation: blinkOrange 1s infinite alternate;
    }
    @keyframes blinkOrange {
      0% { background-color: #ffcc99; color: black; }
      100% { background-color: orange; color: black; }
    }
    .blinking-red {
      animation: blinkRed 1s infinite alternate;
    }
    @keyframes blinkRed {
      0% { background-color: #ffcccc; color: black; }
      100% { background-color: red; color: black; }
    }

    /* ---------------- Modal de Error ----------------- */
    .modal {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.5);
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }
    .modal.show {
      display: flex;
    }
    .modal-content {
      background: white;
      padding: 2rem;
      max-width: 400px;
      width: 80%;
      text-align: center;
      border-radius: 6px;
      font-size: 1.2rem;
      color: red;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>
  <div id="main-container">
    <div class="fucsia-box">
      
      <!-- Encabezado: título y reloj -->
      <div class="header-container">
        <h1>Monitoreo de Clientes en Juego</h1>
        <div id="clock"></div>
      </div>

      <!-- Input de pulsera -->
      <input 
        type="text" 
        id="pulsera" 
        class="scan-input"
        placeholder="Escanea la pulsera..."
        autofocus
      />

      <!-- Tabla de clientes -->
      <div id="listado"></div>
    </div>
  </div>

  <!-- Modal de error -->
  <div id="modal-error" class="modal">
    <div class="modal-content" id="modal-message">
      <!-- Se inyecta el mensaje de error -->
    </div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script>
    // -------- Variables Globales ----------
    let allData = [];         // Array con clientes en juego
    const clockEl    = document.getElementById('clock');
    const pulseraEl  = document.getElementById('pulsera');
    const listadoEl  = document.getElementById('listado');
    const modalError = document.getElementById('modal-error');
    const modalMsg   = document.getElementById('modal-message');

    // --------- Función para mostrar error en un modal -----
    function showModalError(msg) {
      modalMsg.textContent = msg;
      modalError.classList.add('show');
      setTimeout(() => {
        modalError.classList.remove('show');
      }, 3000);
    }

    // --------- Función para escanear Pulsera (Ajax) ---------
    function escanearPulsera(codigoPulsera) {
      $.ajax({
        url: 'monitoreo.php',
        type: 'POST',
        dataType: 'json',
        data: {
          action: 'scan',
          pulsera: codigoPulsera
        },
        success: function(resp) {
          if (resp.success) {
            listarMonitore();
          } else {
            showModalError(resp.msg);
          }
        },
        error: function() {
          showModalError('Error de comunicación con el servidor.');
        }
      });
    }

    // --------- Función para listar clientes "en juego" -------------
    function listarMonitore() {
      $.ajax({
        url: 'monitoreo.php',
        type: 'POST',
        dataType: 'json',
        data: {
          action: 'listar'
        },
        success: function(rows) {
          // Convertimos hora_fin a Date y lo guardamos en r.endDate
          allData = parseData(rows);
          renderTabla(allData);
        },
        error: function() {
          showModalError('Error al listar los clientes en juego.');
        }
      });
    }

    // Convierte hora_fin en formato HH:MM:SS a objeto Date (para hoy) y lo guarda en r.endDate
    function parseData(rows) {
      let now = new Date();
      rows.forEach(r => {
        if (r.hora_fin) {
          let [hh, mm, ss] = r.hora_fin.split(':');
          // Se crea una fecha con hoy y la hora_fin
          r.endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(),
                               parseInt(hh) || 0, parseInt(mm) || 0, parseInt(ss) || 0);
        } else {
          r.endDate = null;
        }
      });
      return rows;
    }

    // Dibuja la tabla con todos los clientes en juego
    function renderTabla(data) {
      if (!data || data.length === 0) {
        listadoEl.innerHTML = '<p>No hay clientes en juego.</p>';
        return;
      }

      let now = new Date();
      let html = `
        <table>
          <thead>
            <tr>
              <th>Pulsera</th>
              <th>Nombre</th>
              <th>Identificación</th>
              <th>Color</th>
              <th>Ingreso</th>
              <th>Tiempo Restante</th>
            </tr>
          </thead>
          <tbody>
      `;

      data.forEach(item => {
        let pulsera = item.pulsera || '';
        let nombre  = item.nombre_cliente || '';
        let identi  = item.identificacion_cliente || '';
        let color   = item.color || 'transparent';
        let fechaE  = item.fecha_escaneo || '';
        // Extraer sólo la hora de fecha_escaneo (asume formato "YYYY-MM-DD HH:MM:SS")
        if (fechaE.indexOf(' ') > -1) {
          fechaE = fechaE.split(' ')[1];
        }

        // Calcular tiempo restante en milisegundos
        let tiempoRestante = '---';
        let rowClass = '';
        if (item.endDate) {
          let diffMs = item.endDate - now;
          if (diffMs > 5 * 60 * 1000) { // Más de 5 minutos restantes
            let diffMins = Math.floor(diffMs / 60000);
            let diffSecs = Math.floor((diffMs % 60000) / 1000);
            tiempoRestante = `${diffMins}m ${diffSecs}s`;
            rowClass = 'verde';
          } else if (diffMs > 0) { // Entre 0 y 5 minutos
            let diffMins = Math.floor(diffMs / 60000);
            let diffSecs = Math.floor((diffMs % 60000) / 1000);
            tiempoRestante = `${diffMins}m ${diffSecs}s`;
            rowClass = 'blinking-orange';
          } else { // Tiempo agotado o negativo
            tiempoRestante = 'Finalizado';
            rowClass = 'blinking-red';
          }
        }

        html += `
          <tr class="${rowClass}">
            <td>${pulsera}</td>
            <td>${nombre}</td>
            <td>${identi}</td>
            <td><div class="color-box" style="background-color: ${color}"></div></td>
            <td>${fechaE}</td>
            <td>${tiempoRestante}</td>
          </tr>
        `;
      });

      html += '</tbody></table>';
      listadoEl.innerHTML = html;
    }

    // ----------------- EVENTOS ---------------------

    // Al presionar Enter en el input de pulsera
    pulseraEl.addEventListener('keypress', function(e) {
      if (e.key === 'Enter' && this.value.trim() !== '') {
        escanearPulsera(this.value.trim());
        this.value = '';
      }
    });

    // ----------------- RELOJ DIGITAL ----------------
    function updateClock() {
      let now = new Date();
      let h = now.getHours();
      let m = now.getMinutes();
      let s = now.getSeconds();
      if (m < 10) m = "0" + m;
      if (s < 10) s = "0" + s;
      clockEl.textContent = h + ":" + m + ":" + s;
    }
    setInterval(updateClock, 1000);

    // ----------------- ACTUALIZAR TIEMPO RESTANTE ----------------
    function updateTiempos() {
      renderTabla(allData);
    }
    setInterval(updateTiempos, 1000);

    // Inicializar listados al cargar la página
    listarMonitore();
  </script>
</body>
</html>
