<?php
include_once "conexion.php";

if (isset($_GET['query'])) {
    $term = $_GET['query'];
    $registros_por_pagina = 10; // Número de registros por página
    $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
    $inicio = ($pagina - 1) * $registros_por_pagina;

    if (empty($term)) {
        // Mostrar todos los clientes con paginación
        $sql_total = "SELECT COUNT(*) as total FROM clientes";
        $stmt_total = $conn->prepare($sql_total);
        $stmt_total->execute();
        $result_total = $stmt_total->get_result();
        $total_registros = $result_total->fetch_assoc()['total'];

        $sql = "SELECT id, nombre, documento, telefono 
                FROM clientes 
                ORDER BY nombre ASC 
                LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $inicio, $registros_por_pagina);
    } else {
        // Buscar por nombre o documento con paginación
        $sql_total = "SELECT COUNT(*) as total FROM clientes WHERE nombre LIKE ? OR documento LIKE ?";
        $stmt_total = $conn->prepare($sql_total);
        $likeTerm = "%" . $term . "%";
        $stmt_total->bind_param("ss", $likeTerm, $likeTerm);
        $stmt_total->execute();
        $result_total = $stmt_total->get_result();
        $total_registros = $result_total->fetch_assoc()['total'];

        $sql = "SELECT id, nombre, documento, telefono 
                FROM clientes 
                WHERE nombre LIKE ? OR documento LIKE ? 
                ORDER BY nombre ASC 
                LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssii", $likeTerm, $likeTerm, $inicio, $registros_por_pagina);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $clientes = [];
    while ($row = $result->fetch_assoc()) {
        $clientes[] = [
            'id' => $row['id'],
            'nombre' => $row['nombre'],
            'documento' => $row['documento'],
            'telefono' => $row['telefono']
        ];
    }

    $total_paginas = ceil($total_registros / $registros_por_pagina);

    echo json_encode([
        'clientes' => $clientes,
        'total_paginas' => $total_paginas
    ]);
}
?>
