<?php
if (!function_exists('ImageCreate')) {
    function ImageCreate($width, $height) {
        return imagecreatetruecolor($width, $height);
    }
}
require 'phpqrcode/phpqrcode.php'; // Librería para generar el código QR
require 'conexion.php'; // Archivo de conexión a la base de datos

// Recibir el ID de la venta desde la URL
if (isset($_GET['id'])) {
    $venta_id = intval($_GET['id']); // Convertimos el parámetro a entero para mayor seguridad
} else {
    die("Error: ID de la venta no definido.");
}

// Validar que la venta exista y obtener datos relacionados
$venta_stmt = $conn->prepare("SELECT v.id, v.total, v.fecha AS fecha_venta, 
                                     r.codigo_reserva, r.actividad, r.fecha_reserva, 
                                     r.hora_desde, r.hora_hasta, r.cantidad_clientes
                              FROM ventas v
                              LEFT JOIN reservas r ON v.reserva_id = r.id
                              WHERE v.id = ?");
$venta_stmt->bind_param("i", $venta_id);
$venta_stmt->execute();
$venta = $venta_stmt->get_result()->fetch_assoc();

if (!$venta) {
    die("Error: No se encontró la venta con ID $venta_id.");
}

// Generar el contenido del código QR
$qrContent = 'ID Venta: ' . $venta_id;
$qrFilePath = 'qrs/venta_' . $venta_id . '.png';

// Verificar si la carpeta `qrs/` existe; si no, crearla
if (!is_dir('qrs')) {
    mkdir('qrs', 0777, true); // Crear la carpeta con permisos de escritura
}

// Generar el archivo del código QR
try {
    QRcode::png($qrContent, $qrFilePath, QR_ECLEVEL_L, 4);
} catch (Exception $e) {
    die("Error al generar el código QR: " . $e->getMessage());
}

// Obtener los productos asociados a la venta
$productos_stmt = $conn->prepare("SELECT dv.*, p.nombre 
                                  FROM detalle_ventas dv
                                  LEFT JOIN productos p ON dv.producto_id = p.id
                                  WHERE dv.venta_id = ?");
$productos_stmt->bind_param("i", $venta_id);
$productos_stmt->execute();
$productos = $productos_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket de Venta</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"> <!-- Archivo local de Bootstrap -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .ticket {
            width: 250px;
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            margin: auto;
        }
        .ticket-logo {
            width: 150px;
            height: auto;
            margin-bottom: 10px;
        }
        .ticket-details {
            margin-bottom: 10px;
            font-size: 0.8rem;
        }
        .ticket-total {
            font-size: 1rem;
            font-weight: bold;
            margin-top: 10px;
        }
        .qr-code {
            margin-top: 10px;
        }
        .qr-code img {
            width: 130px;
            height: 130px;
        }
        .table td, .table th {
            padding: 2px;
            font-size: 0.7rem;
        }
        .table th {
            text-align: center;
        }
        .table td {
            text-align: right;
        }
        @media print {
            .ticket {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="ticket">
    <!-- Logo de la empresa -->
    <img src="img/tekopark.png" alt="Logo Teko" class="ticket-logo">

    <!-- Detalles de la venta -->
    <div class="ticket-details">
        <p>ID Vta: <?php echo htmlspecialchars($venta_id); ?></p>
        <p>Código Reserva: <?php echo htmlspecialchars($venta['codigo_reserva'] ?? 'Sin reserva'); ?></p>
        <p>Actividad: <?php echo htmlspecialchars($venta['actividad'] ?? 'Sin actividad'); ?></p>
        <p>Fecha: <?php echo htmlspecialchars($venta['fecha_reserva'] ?? ''); ?> 
            (<?php echo htmlspecialchars($venta['hora_desde'] ?? ''); ?> - <?php echo htmlspecialchars($venta['hora_hasta'] ?? ''); ?>)
        </p>
        <p>Cant. Clientes: <?php echo htmlspecialchars($venta['cantidad_clientes'] ?? ''); ?></p>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cant.</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($producto = $productos->fetch_assoc()) { ?>
                <tr>
                    <td style="text-align: left;"><?php echo htmlspecialchars($producto['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($producto['cantidad']); ?></td>
                    <td>$<?php echo number_format($producto['total'], 2); ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <div class="ticket-total">
            Total: $<?php echo number_format($venta['total'] ?? 0, 2); ?>
        </div>
    </div>

    <!-- Código QR -->
    <div class="qr-code">
        <img src="<?php echo htmlspecialchars($qrFilePath); ?>" alt="Código QR">
    </div>
</div>

<!-- Script para impresión automática -->
<script>
    window.print();
    window.onafterprint = function() {
        window.location.href = "ventas.php"; // Redirigir después de imprimir
    };
</script>
</body>
</html>
