<?php
$contenido = '<div class="row mx-0 text-center">
    <div class="col-12 mb-4">
        <h3 style="color: #ff5722;">Gestión de Movimientos de Caja</h3>
        <h5>Administre aquí los movimientos de caja.</h5>
    </div>
</div>';
include 'encabezado.php';
include_once 'conexion.php';

// Obtenemos el ID y rol del usuario logueado
$user_id = $_SESSION['usuario']['id'];
$rol = $_SESSION['usuario']['rol'];

// Variables de búsqueda y paginación
$busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;
$searchParam = "%$busqueda%";

// Si el usuario es admin, puede filtrar por caja de otro usuario
if ($rol === 'admin') {
    $usuario_filter = isset($_GET['usuario']) ? (int)$_GET['usuario'] : 0;
} else {
    $usuario_filter = $user_id;
}

// Modificamos la consulta para buscar en la descripción o en la fecha (formateada como dd-mm-yyyy)
if ($rol === 'admin') {
    if ($usuario_filter > 0) {
        $sql = "SELECT * FROM movimientos_caja 
                WHERE usuario_id = ? 
                AND (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)
                ORDER BY fecha DESC LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issii", $usuario_filter, $searchParam, $searchParam, $inicio, $registros_por_pagina);

        $total_sql = "SELECT COUNT(*) as total FROM movimientos_caja 
                      WHERE usuario_id = ? 
                      AND (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)";
        $total_stmt = $conn->prepare($total_sql);
        $total_stmt->bind_param("iss", $usuario_filter, $searchParam, $searchParam);
    } else {
        // Si el filtro es 0, mostramos todos los movimientos sin filtrar por usuario
        $sql = "SELECT * FROM movimientos_caja 
                WHERE (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)
                ORDER BY fecha DESC LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssii", $searchParam, $searchParam, $inicio, $registros_por_pagina);

        $total_sql = "SELECT COUNT(*) as total FROM movimientos_caja 
                      WHERE (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)";
        $total_stmt = $conn->prepare($total_sql);
        $total_stmt->bind_param("ss", $searchParam, $searchParam);
    }
} else {
    // Para otros roles, filtramos automáticamente por el usuario logueado
    $sql = "SELECT * FROM movimientos_caja 
            WHERE usuario_id = ? 
            AND (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)
            ORDER BY fecha DESC LIMIT ?, ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issii", $user_id, $searchParam, $searchParam, $inicio, $registros_por_pagina);

    $total_sql = "SELECT COUNT(*) as total FROM movimientos_caja 
                  WHERE usuario_id = ? 
                  AND (descripcion LIKE ? OR DATE_FORMAT(fecha, '%d-%m-%Y') LIKE ?)";
    $total_stmt = $conn->prepare($total_sql);
    $total_stmt->bind_param("iss", $user_id, $searchParam, $searchParam);
}
$stmt->execute();
$result = $stmt->get_result();

$total_stmt->execute();
$total_result = $total_stmt->get_result();
$total_movimientos = $total_result->fetch_assoc()['total'];

$total_paginas = ceil($total_movimientos / $registros_por_pagina);

// Si el usuario es admin, obtenemos la lista de usuarios para el filtro
if ($rol === 'admin') {
    $users_sql = "SELECT id, nombre FROM usuarios";
    $users_result = $conn->query($users_sql);
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="add_movimiento_caja.php" class="btn btn-success btn-sm">Agregar Movimiento</a>
                <form id="buscador-form" class="d-flex" action="movimientos_caja.php" method="get">
                    <?php if ($rol === 'admin'): ?>
                        <select name="usuario" class="form-select form-select-sm me-2" style="max-width:200px;" onchange="this.form.submit();">
                            <option value="0"<?php echo ($usuario_filter === 0 ? " selected" : ""); ?>>Todos los usuarios</option>
                            <?php while ($user = $users_result->fetch_assoc()) { ?>
                                <option value="<?php echo $user['id']; ?>"<?php echo ($usuario_filter === (int)$user['id'] ? " selected" : ""); ?>>
                                    <?php echo htmlspecialchars($user['nombre']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    <?php endif; ?>
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar en descripción o fecha (dd-mm-yyyy)" value="<?php echo htmlspecialchars($busqueda); ?>">
                    <button type="submit" class="btn btn-primary btn-sm">Buscar</button>
                </form>
            </div>

            <!-- Tabla de movimientos -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Crédito</th>
                            <th>Débito</th>
                            <th>Descripción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) { 
                                // Formateamos la fecha a dd-mm-yyyy H:i:s
                                $formatted_fecha = date("d-m-Y H:i:s", strtotime($row["fecha"]));
                                // Formateamos los números: separador de miles (punto) y sin decimales
                                $formatted_credito = number_format($row["credito"], 0, ',', '.');
                                $formatted_debito = number_format($row["debito"], 0, ',', '.');
                        ?>
                                <tr>
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo $formatted_fecha; ?></td>
                                    <td><?php echo $formatted_credito; ?></td>
                                    <td><?php echo $formatted_debito; ?></td>
                                    <td><?php echo $row["descripcion"]; ?></td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="5" class="text-center">No se encontraron resultados.</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center">
                    <?php for ($i = 1; $i <= $total_paginas; $i++) { ?>
                        <li class="page-item <?php echo $pagina_actual === $i ? 'active' : ''; ?>">
                            <?php 
                                $query = "pagina=$i&busqueda=" . urlencode($busqueda);
                                if ($rol === 'admin') {
                                    $query .= "&usuario=" . $usuario_filter;
                                }
                            ?>
                            <a class="page-link" href="?<?php echo $query; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
