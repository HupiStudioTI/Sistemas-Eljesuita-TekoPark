<?php
// monitoreo.php
include_once "conexion.php";

// Establecer la zona horaria a Buenos Aires
date_default_timezone_set('America/Argentina/Buenos_Aires');

// ---------------------
// 1. Procesar Ajax
// ---------------------

// Escanear la pulsera
if (isset($_POST['action']) && $_POST['action'] === 'scan') {
    $pulsera = trim($_POST['pulsera']);

    // Buscar el último registro de esa pulsera en monitore
    $sqlCheck = "SELECT *
                 FROM monitore
                 WHERE pulsera = ?
                 ORDER BY id DESC
                 LIMIT 1";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $pulsera);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck && $resCheck->num_rows > 0) {
        // Hay al menos un registro previo
        $lastRow = $resCheck->fetch_assoc();

        if ($lastRow['estado'] === 'en_juego') {
            // Finalizamos el turno actual
            $updateSql = "UPDATE monitore SET estado = 'finalizado' WHERE id = ?";
            $stmtUpd = $conn->prepare($updateSql);
            $stmtUpd->bind_param("i", $lastRow['id']);
            $stmtUpd->execute();

            echo json_encode([
                'success'    => true,
                'msg'        => 'Pulsera finalizada: ' . $pulsera,
                'finalizado' => true
            ]);
            exit;
        } else {
            // Si ya fue finalizada no se permite reingreso
            echo json_encode([
                'success' => false,
                'msg'     => 'Pulsera ya fue finalizada, no se permite reingreso.'
            ]);
            exit;
        }
    } else {
        // No hay registros anteriores en monitore → buscamos en clientes_reserva
        $sql = "SELECT cr.cliente_id, cr.reserva_id, cr.nombre, cr.identificacion, r.codigo_reserva,
                       r.hora_desde, r.hora_hasta, v.color_value AS color
                FROM clientes_reserva cr
                INNER JOIN reservas r ON cr.reserva_id = r.id
                LEFT JOIN ventas v ON v.reserva_id = r.id
                WHERE cr.pulsera = ?
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pulsera);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Obtener la fecha y hora actual (cuando se escanea la pulsera)
            $fechaEscaneo  = date('Y-m-d H:i:s');
            $clienteId     = $row['cliente_id'];
            $reservaId     = $row['reserva_id'];
            $nombreCl      = $row['nombre'];
            $identiCl      = $row['identificacion'];
            $codigoReserva = $row['codigo_reserva'];

            // Valor de color; si no es válido se asigna un predeterminado
            $color = trim($row['color'] ?: '');
            if (!$color || strtolower($color) === 'sincolor') {
                $color = '#ccc';
            }
            // Calcular la duración contratada en segundos (basada en hora_hasta y hora_desde)
            $durationSeconds = strtotime($row['hora_hasta']) - strtotime($row['hora_desde']);
            // Calcular la nueva fecha y hora de fin a partir del escaneo
            $newHoraFin = date('Y-m-d H:i:s', strtotime($fechaEscaneo) + $durationSeconds);

            // Insertar en la tabla monitore con estado='en_juego'
            $insertSql = "INSERT INTO monitore 
                (pulsera, cliente_id, reserva_id, codigo_reserva, nombre_cliente, identificacion_cliente, 
                 color, fecha_escaneo, hora_fin, estado) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'en_juego')";
            $stmtInsert = $conn->prepare($insertSql);
            $stmtInsert->bind_param("siissssss", 
                $pulsera, 
                $clienteId, 
                $reservaId, 
                $codigoReserva,
                $nombreCl, 
                $identiCl, 
                $color, 
                $fechaEscaneo, 
                $newHoraFin
            );
            $stmtInsert->execute();

            echo json_encode([
                'success' => true,
                'msg'     => 'Pulsera registrada: ' . $pulsera
            ]);
            exit;
        } else {
            // Pulsera no encontrada en clientes_reserva
            echo json_encode([
                'success' => false,
                'msg'     => 'Pulsera no encontrada en clientes_reserva'
            ]);
            exit;
        }
    }
}

// Listar sólo los que estén "en_juego", orden ascendente por fecha_escaneo
if (isset($_POST['action']) && $_POST['action'] === 'listar') {
    $sql = "SELECT id, pulsera, nombre_cliente, identificacion_cliente, color, fecha_escaneo, hora_fin
            FROM monitore
            WHERE estado = 'en_juego'
            ORDER BY fecha_escaneo ASC";
    $result = $conn->query($sql);

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Monitoreo de Clientes en Juego</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Fuente digital (Orbitron) desde Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">

  <style>
    /* Reset y tipografía básica */
    html, body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      font-size: 16px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      background: #fff;
    }

    /* Contenedor principal */
    #main-container {
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;
      padding: 1rem;
    }

    /* Caja con borde fucsia */
    .fucsia-box {
      position: relative;
      width: 100%;
      border: 4px solid fuchsia;
      padding: 2rem 1rem 1rem; /* espacio superior para el reloj */
      box-sizing: border-box;
      border-radius: 8px;
      color: #000;
    }

    /* Reloj en la esquina superior derecha dentro del recuadro fucsia */
    #clock {
      font-family: 'Orbitron', monospace;
      font-size: 3rem;
      color: #0f0;
      font-weight: bold;
      position: absolute;
      top: 0.5rem;
      right: 1rem;
      text-shadow: 0 0 5px #0f0;
    }

    /* Ajustar contenedor para el título y resto */
    .header-container {
      margin-bottom: 1rem;
      text-align: center;
    }
    .header-container h1 {
      margin: 0;
      font-size: 1.2rem;
    }

    /* Campo de escaneo */
    .scan-input {
      display: block;
      margin: 0 auto 1rem auto;
      font-size: 1rem;
      padding: 0.5rem;
      width: 80%;
      max-width: 400px;
      text-align: center;
      box-sizing: border-box;
    }

    /* Tabla */
    #listado {
      width: 100%;
      box-sizing: border-box;
      padding: 1rem 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      color: #000;
      table-layout: auto;
      font-size: 0.9rem;
    }
    th, td {
      border-bottom: 1px solid #000;
      padding: 0.5rem;
      vertical-align: middle;
    }
    th {
      text-align: left;
    }
    .color-box {
      display: inline-block;
      width: 16px;
      height: 16px;
      margin-right: 4px;
      vertical-align: middle;
      border: 1px solid #ccc;
    }

    /* 1) Letra negra por defecto */
    /* 2) ≤ 5 minutos restantes → letra naranja */
    .warning-time {
      color: orange;
    }

    /* 3) Finalizado → letra parpadeante roja */
    @keyframes blinkRed {
      0%   { color: red; }
      50%  { color: transparent; }
      100% { color: red; }
    }
    .blinking-red {
      animation: blinkRed 1s infinite;
    }

    /* Paginación */
    .pagination {
      text-align: center;
      margin-top: 1rem;
    }
    .pagination button {
      margin: 0 0.25rem;
      padding: 0.4rem 0.8rem;
      font-size: 0.9rem;
      border: 1px solid #000;
      background: #fff;
      cursor: pointer;
      border-radius: 4px;
    }
    .pagination button.active {
      background: fuchsia;
      color: #fff;
      font-weight: bold;
    }
    .pagination button:hover {
      background: #eee;
    }

    /* Modal de Error */
    .modal {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.5);
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }
    .modal.show {
      display: flex;
    }
    .modal-content {
      background: white;
      padding: 1.5rem;
      max-width: 350px;
      width: 80%;
      text-align: center;
      border-radius: 6px;
      font-size: 1rem;
      color: red;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>
  <div id="main-container">
    <div class="fucsia-box">
      <div id="clock">--:--:--</div>

      <!-- Título centrado -->
      <div class="header-container">
        <h1>Monitoreo de Clientes en Juego</h1>
      </div>

      <!-- Input de pulsera -->
      <input 
        type="text" 
        id="pulsera" 
        class="scan-input"
        placeholder="Escanea la pulsera..."
        autofocus
      />

      <!-- Tabla de clientes -->
      <div id="listado"></div>

      <!-- Controles de paginación -->
      <div class="pagination" id="pagination"></div>
    </div>
  </div>

  <!-- Modal de error -->
  <div id="modal-error" class="modal">
    <div class="modal-content" id="modal-message"></div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script>
    // ------- Variables globales -------
    let allData     = [];
    let currentPage = 0;              // página actual (0-based)
    const pageSize = 10;              // 10 filas por página

    const clockEl   = document.getElementById('clock');
    const pulseraEl = document.getElementById('pulsera');
    const listadoEl = document.getElementById('listado');
    const paginationEl = document.getElementById('pagination');
    const modalErr  = document.getElementById('modal-error');
    const modalMsg  = document.getElementById('modal-message');

    // ------- Mostrar error en modal -------
    function showModalError(msg) {
      modalMsg.textContent = msg;
      modalErr.classList.add('show');
      setTimeout(() => modalErr.classList.remove('show'), 3000);
    }

    // ------- Escanear pulsera (Ajax) -------
    function escanearPulsera(code) {
      $.ajax({
        url: 'monitoreo.php',
        type: 'POST',
        data: { action: 'scan', pulsera: code },
        dataType: 'json',
        success: function(r) {
          if (r.success) {
            listarMonitore();
          } else {
            showModalError(r.msg);
          }
        },
        error: function() {
          showModalError('Error de comunicación con el servidor.');
        }
      });
    }

    // ------- Listar datos (Ajax) -------
    function listarMonitore() {
      $.ajax({
        url: 'monitoreo.php',
        type: 'POST',
        data: { action: 'listar' },
        dataType: 'json',
        success: function(rows) {
          allData = parseData(rows);
          currentPage = 0;
          renderTabla();
          renderPagination();
        },
        error: function() {
          showModalError('Error al listar los clientes en juego.');
        }
      });
    }

    // Convertir hora_fin a Date
    function parseData(rows) {
      rows.forEach(r => {
        if (r.hora_fin) {
          // Reemplazar espacio por 'T' para que JS lo entienda
          r.endDate = new Date(r.hora_fin.replace(' ', 'T'));
        } else {
          r.endDate = null;
        }
      });
      return rows;
    }

    // ------- Renderizar tabla para la página actual -------
    function renderTabla() {
      if (!allData || allData.length === 0) {
        listadoEl.innerHTML = '<p>No hay clientes en juego.</p>';
        return;
      }

      const now = new Date();
      const startIdx = currentPage * pageSize;
      const endIdx   = startIdx + pageSize;
      const view = allData.slice(startIdx, endIdx);

      let html = `
        <table>
          <thead>
            <tr>
              <th>Pulsera</th>
              <th>Nombre</th>
              <th>Identificación</th>
              <th>Color</th>
              <th>Ingreso</th>
              <th>Tiempo Restante</th>
            </tr>
          </thead>
          <tbody>
      `;

      view.forEach(item => {
        let pulsera = item.pulsera || '';
        let nombre  = item.nombre_cliente || '';
        let identi  = item.identificacion_cliente || '';
        let color   = item.color || 'transparent';
        let fechaE  = item.fecha_escaneo || '';
        if (fechaE.indexOf(' ') > -1) {
          fechaE = fechaE.split(' ')[1];
        }

        let tiempoRestante = '---';
        let rowClass       = '';
        if (item.endDate) {
          let diffMs = item.endDate - now;
          if (diffMs > 5 * 60 * 1000) {
            // > 5 min → letra negra
            let diffMins = Math.floor(diffMs / 60000);
            let diffSecs = Math.floor((diffMs % 60000) / 1000);
            tiempoRestante = `${diffMins}m ${diffSecs}s`;
          } else if (diffMs > 0) {
            // ≤ 5 min → letra naranja
            let diffMins = Math.floor(diffMs / 60000);
            let diffSecs = Math.floor((diffMs % 60000) / 1000);
            tiempoRestante = `${diffMins}m ${diffSecs}s`;
            rowClass = 'warning-time';
          } else {
            // expirado → letra roja parpadeante
            tiempoRestante = 'Finalizado';
            rowClass = 'blinking-red';
          }
        }

        html += `
          <tr class="${rowClass}">
            <td>${pulsera}</td>
            <td>${nombre}</td>
            <td>${identi}</td>
            <td><div class="color-box" style="background:${color}"></div></td>
            <td>${fechaE}</td>
            <td>${tiempoRestante}</td>
          </tr>
        `;
      });

      html += `
          </tbody>
        </table>
      `;
      listadoEl.innerHTML = html;
    }

    // ------- Renderizar controles de paginación -------
    function renderPagination() {
      if (!allData || allData.length <= pageSize) {
        paginationEl.innerHTML = '';
        return;
      }
      const totalPages = Math.ceil(allData.length / pageSize);
      let html = '';
      for (let i = 0; i < totalPages; i++) {
        html += `<button class="${i === currentPage ? 'active' : ''}" data-page="${i}">${i+1}</button>`;
      }
      paginationEl.innerHTML = html;

      // Asociar evento a cada botón
      Array.from(paginationEl.children).forEach(btn => {
        btn.addEventListener('click', () => {
          currentPage = parseInt(btn.getAttribute('data-page'), 10);
          renderTabla();
          renderPagination();
        });
      });
    }

    // ------- Eventos -------
    pulseraEl.addEventListener('keypress', function(e) {
      if (e.key === 'Enter' && this.value.trim() !== '') {
        escanearPulsera(this.value.trim());
        this.value = '';
      }
    });

    // ------- Reloj -------
    function updateClock() {
      const n = new Date();
      const hh = String(n.getHours()).padStart(2, '0');
      const mm = String(n.getMinutes()).padStart(2, '0');
      const ss = String(n.getSeconds()).padStart(2, '0');
      clockEl.textContent = `${hh}:${mm}:${ss}`;
    }
    setInterval(updateClock, 1000);

    // ------- Refrescar tiempos cada segundo -------
    function updateTiempos() {
      renderTabla();
    }
    setInterval(updateTiempos, 1000);

    // ------- Inicializar -------
    listarMonitore();
  </script>
</body>
</html>
