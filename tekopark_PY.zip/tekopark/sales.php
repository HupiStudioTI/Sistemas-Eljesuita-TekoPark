<?php
include_once "conexion.php";

// Función para obtener el precio de un producto por nombre
function obtenerPrecioPorNombre($nombre) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, precio FROM productos WHERE nombre = ?");
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Función para obtener el descuento de bonificación
function obtenerBonificacion($bonificacion_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT descuento FROM bonificaciones WHERE id = ?");
    $stmt->bind_param("i", $bonificacion_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc()['descuento'] ?? 0;
}

// Verificar si la reserva ya tiene una venta registrada
if (isset($_POST['action']) && $_POST['action'] === 'verificar_reserva') {
    $reserva_id = $_POST['reserva_id'];
    $stmt = $conn->prepare("SELECT id FROM ventas WHERE reserva_id = ?");
    $stmt->bind_param("i", $reserva_id);
    $stmt->execute();
    $result = $stmt->get_result();
    echo json_encode(['exists' => $result->num_rows > 0]);
    exit;
}

// Verificar si se recibe una solicitud AJAX para obtener el precio de un producto
if (isset($_POST['action']) && $_POST['action'] === 'obtener_precio_producto') {
    $nombre = $_POST['nombre'];
    $producto = obtenerPrecioPorNombre($nombre);
    echo json_encode($producto);
    exit;
}

// Verificar si se recibe una solicitud AJAX para obtener las reservas pendientes
if (isset($_POST['action']) && $_POST['action'] === 'obtener_reservas') {
    $busqueda = $_POST['busqueda'] . '%';
    $stmt = $conn->prepare("SELECT id, codigo_reserva FROM reservas WHERE codigo_reserva LIKE ? AND estado = 'pendiente'");
    $stmt->bind_param("s", $busqueda);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservas = [];
    while ($row = $result->fetch_assoc()) {
        $reservas[] = $row;
    }
    echo json_encode($reservas);
    exit;
}

// Guardar venta en la base de datos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_venta'])) {
    // Mapeo de nombres de colores a valores HEX
    $colores = [
        "Blanco" => "#FFFFFF",
        "Plata" => "#C0C0C0",
        "Verde" => "#008000",
        "Rojo" => "#FF0000",
        "Azul" => "#0000FF",
        "Dorado" => "#FFD700",
        "Amarillo" => "#FFFF00",
        "Naranja" => "#FFA500",
        "Violeta" => "#EE82EE"
    ];
    $reserva_id = $_POST['reserva_id'];
    $colaborador_id = $_POST['colaborador'];
    $productos = json_decode($_POST['productos'], true);
    $bonificacion_id = $_POST['bonificacion'];
    $modo_pago = $_POST['modo_pago'];
    $color = $_POST['color'];  // El color seleccionado
    $color_value = $colores[$color] ?? "#FFFFFF"; // Valor HEX, por defecto blanco
    
    // Validar datos esenciales
    if (empty($reserva_id) || empty($colaborador_id) || empty($modo_pago)) {
        error_log("Faltan datos: reserva_id: $reserva_id, colaborador_id: $colaborador_id, modo_pago: $modo_pago");
        echo json_encode(['success' => false, 'error' => 'Faltan datos']);
        exit;
    }
    // Obtener codigo_reserva de la tabla reservas
    $sqlCodigo = "SELECT codigo_reserva FROM reservas WHERE id = ? LIMIT 1";
    $stmtCodigo = $conn->prepare($sqlCodigo);
    $stmtCodigo->bind_param("i", $reserva_id);
    $stmtCodigo->execute();
    $resultCodigoReserva = $stmtCodigo->get_result();
    $rowCodigoReserva = $resultCodigoReserva->fetch_assoc();
    $codigo_reserva = $rowCodigoReserva ? $rowCodigoReserva['codigo_reserva'] : "";
    // Calcular total de la venta (productos)
    $total_productos = 0;
    foreach ($productos as $producto) {
        $total_productos += $producto['cantidad'] * $producto['precio_unitario'];
    }
    // Obtener subtotal de la tarifa (enviado desde el formulario)
    $subtotal_tarifa = $_POST['subtotal_tarifa'];
    // Sumar ambos para obtener el total de la venta
    $total_venta = $total_productos + $subtotal_tarifa;
    // Aplicar bonificación si está seleccionada, sobre el subtotal de la tarifa
    $bonificacion_importe = 0;
    if ($bonificacion_id) {
        $bonificacion = obtenerBonificacion($bonificacion_id);
        $bonificacion_importe = ($subtotal_tarifa * ($bonificacion / 100));
        $total_venta -= $bonificacion_importe;
    }
    // Insertar en la tabla ventas (incluyendo las nuevas columnas totaltarifas y totalproductos)
    // CORRECCIÓN: cambiar la secuencia de tipos para que el modo de pago sea un string ('s')
    $stmt = $conn->prepare("INSERT INTO ventas (
        reserva_id, 
        codigo_reserva, 
        colaborador_id, 
        bonificacion_id, 
        bonificacion, 
        totaltarifas,
        totalproductos,
        total, 
        modo_pago, 
        color, 
        color_value
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param("isiiddddsss", 
        $reserva_id, 
        $codigo_reserva,
        $colaborador_id, 
        $bonificacion_id, 
        $bonificacion_importe, 
        $subtotal_tarifa,
        $total_productos,
        $total_venta, 
        $modo_pago, 
        $color, 
        $color_value
    );
    
    if ($stmt->execute()) {
        $venta_id = $stmt->insert_id;
        // Insertar detalle de la venta (productos)
        if (!empty($productos)) {
            foreach ($productos as $producto) {
                $producto_id = $producto['id'];
                $cantidad = $producto['cantidad'];
                $precio_unitario = $producto['precio_unitario'];
                $total_producto = $cantidad * $precio_unitario;
                
                $stmtDetalle = $conn->prepare("INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario, total) VALUES (?, ?, ?, ?, ?)");
                $stmtDetalle->bind_param("iiddd", $venta_id, $producto_id, $cantidad, $precio_unitario, $total_producto);
                if (!$stmtDetalle->execute()) {
                    error_log("Error al insertar detalle de venta: " . $stmtDetalle->error);
                }
            }
        }
        // Calcular comisión del colaborador sobre el subtotal de tarifa
        $comision_porcentaje = 0.05; // Ejemplo: 5%
        $comision = $subtotal_tarifa * $comision_porcentaje;
        $stmtComision = $conn->prepare("INSERT INTO comisiones (colaborador_id, venta_id, comision) VALUES (?, ?, ?)");
        $stmtComision->bind_param("iid", $colaborador_id, $venta_id, $comision);
        $stmtComision->execute();
        // Actualizar el estado de la reserva a 'pagada'
        $stmtReserva = $conn->prepare("UPDATE reservas SET estado = 'pagada' WHERE id = ?");
        $stmtReserva->bind_param("i", $reserva_id);
        $stmtReserva->execute();
        echo json_encode(['success' => true]);
    } else {
        error_log("Error al insertar la venta: " . $stmt->error);
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Venta</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="js/jquery-ui.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        /* Estilos personalizados para la interfaz */
        .total-box {
            font-size: 0.9rem;
            padding: 5px;
            border: 2px solid #ced4da;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
            text-align: center;
        }
        .heading-title {
            font-size: 1.1rem;
            color: green;
        }
        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            flex-wrap: wrap;
        }
        .color-box {
            display: inline-block;
            width: 20px;
            height: 20px;
            margin-right: 10px;
            vertical-align: middle;
            border: 1px solid #ccc;
        }
        .table-custom-sm th, .table-custom-sm td {
            font-size: 0.8rem;
            padding: 0.25rem;
            vertical-align: middle;
        }
        .table-custom-sm .btn {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        .modal-custom-sm .modal-body {
            font-size: 0.85rem;
        }
        @media (max-width: 768px) {
            .heading-title { font-size: 1rem; }
            .total-box { font-size: 0.8rem; padding: 5px; }
            .button-group { justify-content: center; }
        }
        .ui-autocomplete {
            background-color: #fff;
            border: 1px solid #ccc;
            z-index: 9999;
            max-height: 200px;
            overflow-y: auto;
            width: auto !important;
            min-width: 150px !important;
            max-width: 250px !important;
        }
        .ui-menu .ui-menu-item {
            font-size: 0.9rem;
            padding: 5px;
            cursor: pointer;
            background-color: transparent;
        }
        .ui-state-active, .ui-menu .ui-menu-item:hover {
            background-color: orange !important;
            color: #fff !important;
        }
    </style>
</head>
<body>
<div class="container mt-3">
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="heading-title">Nueva Venta</h1>
        <a href="formulario_reserva.php" class="btn btn-primary btn-sm">Nueva Reserva</a>
    </div>
    <div class="card mb-3">
        <div class="card-body">
            <form id="ventaForm">
                <input type="hidden" name="guardar_venta" value="1">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label for="reserva_id" class="form-label">Seleccionar Reserva</label>
                        <input type="text" id="busqueda_reserva" class="form-control form-control-sm" placeholder="Escribe para buscar una reserva...">
                        <select name="reserva_id" id="reserva_id" class="form-select form-select-sm mt-2" required>
                            <option value="">Seleccione una reserva</option>
                            <?php
                            // Llenar el select con reservas pendientes
                            $reservas = $conn->query("SELECT id, codigo_reserva, fecha_reserva FROM reservas WHERE estado = 'pendiente' ORDER BY fecha_reserva DESC");
                            while ($row = $reservas->fetch_assoc()) {
                                echo "<option value=\"{$row['id']}\">{$row['codigo_reserva']} - {$row['fecha_reserva']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6 mt-3 mt-md-0">
                        <div class="row">
                            <div class="col-6">
                                <label for="colaborador" class="form-label">Vendedor</label>
                                <select name="colaborador" id="colaborador" class="form-select form-select-sm" required>
                                    <option value="">Seleccione un vendedor</option>
                                    <?php
                                    $colaboradores = $conn->query("SELECT id, nombre FROM colaboradores");
                                    while ($row = $colaboradores->fetch_assoc()) {
                                        $selected = (strtolower($row['nombre']) === 'tekopark') ? 'selected' : '';
                                        echo "<option value=\"{$row['id']}\" $selected>{$row['nombre']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-6">
                                <label for="color" class="form-label">Color</label>
                                <select id="color" name="color" class="form-select form-select-sm" required>
                                    <option value="">Seleccione un color</option>
                                    <?php
                                    $colores = [
                                        "Blanco" => "#FFFFFF",
                                        "Plata" => "#C0C0C0",
                                        "Verde" => "#008000",
                                        "Rojo" => "#FF0000",
                                        "Azul" => "#0000FF",
                                        "Dorado" => "#FFD700",
                                        "Amarillo" => "#FFFF00",
                                        "Naranja" => "#FFA500",
                                        "Violeta" => "#EE82EE"
                                    ];
                                    foreach ($colores as $nombre => $hex) {
                                        echo "<option value='$nombre' style='background-color: $hex; color: black;'>$nombre</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Tarifa y Cantidad de Clientes -->
                <div class="row mt-3">
                    <div class="col-12 col-md-6">
                        <label for="tarifa" class="form-label">Tarifa</label>
                        <input type="text" id="tarifa" class="form-control form-control-sm" readonly>
                    </div>
                    <div class="col-12 col-md-6 mt-3 mt-md-0">
                        <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
                        <input type="number" id="cantidad_clientes" class="form-control form-control-sm" readonly>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header">Productos</div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="producto" class="form-label">Buscar Producto</label>
                    <input type="text" id="producto" class="form-control form-control-sm" placeholder="Escribe para buscar un producto...">
                </div>
                <div class="col-md-4 mt-3 mt-md-0">
                    <label for="cantidad_producto" class="form-label">Cantidad</label>
                    <input type="number" id="cantidad_producto" class="form-control form-control-sm" value="1" min="1">
                </div>
            </div>
            <button type="button" id="agregar-producto" class="btn btn-primary btn-sm">Agregar Producto</button>
            <div class="table-responsive mt-3">
                <table class="table table-sm table-striped table-bordered table-custom-sm">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario ($)</th>
                            <th>Total ($)</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="productos-list">
                        <!-- Se agregarán los productos -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <div class="total-box">
                <h5>Subtotal de la Reserva: $<span id="subtotal-tarifa">0.00</span></h5>
            </div>
            <div class="total-box">
                <h5>Total de la Venta: $<span id="total-venta">0.00</span></h5>
            </div>
            <div class="row mt-3">
                <div class="col-md-6">
                    <label for="bonificacion" class="form-label">Seleccionar Bonificación</label>
                    <select id="bonificacion" name="bonificacion" class="form-select form-select-sm">
                        <?php
                        $bonificaciones = $conn->query("SELECT id, nombre, descuento FROM bonificaciones");
                        while ($row = $bonificaciones->fetch_assoc()) {
                            $selected = (strtoupper($row['nombre']) === 'NINGUNA') ? 'selected' : '';
                            echo "<option value=\"{$row['id']}\" data-descuento=\"{$row['descuento']}\" $selected>{$row['nombre']} ({$row['descuento']}%)</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-6 mt-3 mt-md-0">
                    <label for="modo_pago" class="form-label">Modo de Pago</label>
                    <select id="modo_pago" name="modo_pago" class="form-select form-select-sm" required>
                        <option value="EFECTIVO" selected>Efectivo</option>
                        <option value="TARJETA">Tarjeta</option>
                        <option value="QR">QR</option>
                        <option value="MERCADOPAGO">MercadoPago</option>
                        <option value="CANJE">Canje</option>
                        <option value="OTROS">Otros</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="button-group">
        <button type="submit" form="ventaForm" class="btn btn-success btn-sm">Guardar Venta</button>
        <a href="ventas.php" class="btn btn-secondary btn-sm">Salir</a>
    </div>
</div>

<!-- Modal para detalles de la venta (opcional) -->
<div class="modal fade modal-custom-sm" id="ventaModal" tabindex="-1" aria-labelledby="ventaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ventaModalLabel">Detalles de la Venta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body" id="ventaDetalle">
                <!-- Se cargarán los detalles de la venta -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script>
$(function() {
    // Autocompletar producto
    $("#producto").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "buscar_producto_por_nombre.php",
                type: "POST",
                data: { nombre: request.term },
                success: function(data) {
                    response(JSON.parse(data));
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            $("#producto").val(ui.item.label);
            return false;
        }
    }).autocomplete("instance")._renderItem = function(ul, item) {
        return $("<li>")
            .append("<div>" + item.label + " - $" + parseFloat(item.precio).toFixed(2) + "</div>")
            .appendTo(ul);
    };

    // Autocompletar reserva
    $("#busqueda_reserva").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: '',
                type: "POST",
                data: { action: 'obtener_reservas', busqueda: request.term },
                success: function(data) {
                    response($.map(JSON.parse(data), function(item) {
                        return {
                            label: item.codigo_reserva,
                            value: item.id
                        };
                    }));
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            $("#reserva_id").val(ui.item.value);
            verificarReserva(ui.item.value);
        }
    });

    // Verificar si la reserva ya está registrada en ventas
    $("#reserva_id").change(function() {
        var reserva_id = $(this).val();
        verificarReserva(reserva_id);
    });

    function verificarReserva(reserva_id) {
        if (reserva_id === "") return;
        $.ajax({
            url: '',
            type: "POST",
            data: { action: 'verificar_reserva', reserva_id: reserva_id },
            success: function(response) {
                var result = JSON.parse(response);
                if (result.exists) {
                    alert('La reserva ya está registrada en una venta.');
                    $("#reserva_id").val('');
                    $("#tarifa").val('');
                    $("#cantidad_clientes").val('');
                    $("#subtotal-tarifa").text('0.00');
                    $("#total-venta").text('0.00');
                } else {
                    cargarDatosReserva(reserva_id);
                }
            }
        });
    }

    function cargarDatosReserva(reserva_id) {
        $.ajax({
            url: "obtener_datos_reserva.php",
            type: "POST",
            data: { id: reserva_id },
            success: function(data) {
                var reserva = JSON.parse(data);
                var tarifa = parseFloat(reserva.precio);
                var cantidadClientes = parseInt(reserva.cantidad_clientes);
                $("#tarifa").val(tarifa.toFixed(2));
                $("#cantidad_clientes").val(cantidadClientes);
                var totalTarifa = tarifa * cantidadClientes;
                $("#subtotal-tarifa").text(totalTarifa.toFixed(2));
                calcularTotal();
            },
            error: function() {
                alert('Error al cargar los datos de la reserva.');
            }
        });
    }

    // Agregar producto al listado
    $("#agregar-producto").click(function() {
        var nombre = $("#producto").val().trim();
        var cantidad = parseInt($('#cantidad_producto').val());
        if (nombre && cantidad > 0) {
            obtenerPrecioPorNombre(nombre, function(precio, id) {
                if (precio && id) {
                    var totalProducto = precio * cantidad;
                    var existe = false;
                    $('#productos-list tr').each(function() {
                        var productoId = $(this).data('id');
                        if (productoId == id) {
                            var nuevaCantidad = parseInt($(this).find('td:nth-child(2)').text()) + cantidad;
                            var nuevoTotal = nuevaCantidad * precio;
                            $(this).find('td:nth-child(2)').text(nuevaCantidad);
                            $(this).find('.total-producto').text('$' + nuevoTotal.toFixed(2));
                            existe = true;
                            calcularTotal();
                            return false;
                        }
                    });
                    if (!existe) {
                        $('#productos-list').append(`
                            <tr data-id="${id}">
                                <td>${nombre}</td>
                                <td>${cantidad}</td>
                                <td class="precio-unitario">${precio.toFixed(2)}</td>
                                <td class="total-producto">$${totalProducto.toFixed(2)}</td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm eliminar-producto">Eliminar</button>
                                </td>
                            </tr>
                        `);
                        calcularTotal();
                    }
                    $("#producto").val('');
                    $("#cantidad_producto").val(1);
                } else {
                    alert("Producto no encontrado.");
                }
            });
        } else {
            alert("Por favor, selecciona un producto válido y cantidad.");
        }
    });

    // Eliminar producto del listado
    $(document).on('click', '.eliminar-producto', function() {
        $(this).closest('tr').remove();
        calcularTotal();
    });

    // Guardar venta mediante AJAX
    $('#ventaForm').on('submit', function(e) {
        e.preventDefault();
        var productos = [];
        $('#productos-list tr').each(function() {
            var id = $(this).data('id');
            var nombre = $(this).find('td:first').text();
            var cantidad = parseInt($(this).find('td:nth-child(2)').text());
            var precio_unitario = parseFloat($(this).find('.precio-unitario').text());
            productos.push({ id: id, nombre: nombre, cantidad: cantidad, precio_unitario: precio_unitario });
        });
        if (productos.length === 0) {
            var totalTarifa = parseFloat($("#subtotal-tarifa").text()) || 0;
            if (totalTarifa === 0) {
                alert("Agrega al menos un producto o verifica la tarifa de la reserva.");
                return;
            }
        }
        var formData = $(this).serializeArray();
        formData.push({ name: 'productos', value: JSON.stringify(productos) });
        formData.push({ name: 'subtotal_tarifa', value: parseFloat($("#subtotal-tarifa").text()) });
        formData.push({ name: 'bonificacion', value: $("#bonificacion").val() });
        formData.push({ name: 'modo_pago', value: $("#modo_pago").val() });
        $.ajax({
            url: '',
            type: 'POST',
            data: formData,
            success: function(response) {
                var result = JSON.parse(response);
                if (result.success) {
                    alert('Venta guardada exitosamente.');
                    window.location.href="ventas.php";
                } else {
                    alert('Error al guardar la venta: ' + result.error);
                }
            },
            error: function() {
                alert('Error al procesar la solicitud.');
            }
        });
    });

    function obtenerPrecioPorNombre(nombre, callback) {
        $.ajax({
            url: '',
            type: 'POST',
            data: { action: 'obtener_precio_producto', nombre: nombre },
            success: function(data) {
                var producto = JSON.parse(data);
                callback(producto ? parseFloat(producto.precio) : null, producto ? producto.id : null);
            },
            error: function() {
                callback(null, null);
            }
        });
    }

    $("#bonificacion").change(function() {
        calcularTotal();
    });

    function calcularTotal() {
        var totalVenta = 0;
        $('#productos-list tr').each(function() {
            var totalProducto = parseFloat($(this).find('.total-producto').text().replace('$', ''));
            totalVenta += totalProducto;
        });
        var totalTarifa = parseFloat($("#subtotal-tarifa").text()) || 0;
        var bonificacion = parseFloat($("#bonificacion").find(":selected").data("descuento")) || 0;
        var totalTarifaConDescuento = totalTarifa - (totalTarifa * (bonificacion / 100));
        var totalGeneral = totalTarifaConDescuento + totalVenta;
        $('#total-venta').text(totalGeneral.toFixed(2));
    }
});
</script>
</body>
</html>
