<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Bonificación</h3>
    <h5>Complete los detalles de la nueva bonificación.</h5>
</div>
</div>';
include 'encabezado.php';
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form id="bonificacion-form" action="guardar_bonificacion.php" method="post">
                <div class="row">
                    <!-- Nombre de la bonificación -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input required type="text" class="form-control form-control-sm" name="nombre" id="nombre" placeholder="Ejemplo: Descuento Estudiantil">
                    </div>
                    <!-- Porcentaje de descuento -->
                    <div class="col-md-6 mb-3">
                        <label for="descuento" class="form-label" style="font-size: 0.9rem;">Descuento (%)</label>
                        <input required type="number" class="form-control form-control-sm" name="descuento" id="descuento" min="0" max="100" placeholder="Ejemplo: 15">
                    </div>
                </div>
                <!-- Botón de guardar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar Bonificación</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    // Validar el campo de descuento para asegurar que sea entre 0 y 100
    $('#descuento').on('input', function() {
        let value = parseInt($(this).val(), 10);
        if (value < 0) $(this).val(0);
        if (value > 100) $(this).val(100);
    });
});
</script>
<?php include 'footer.php'; ?>