<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
<div class="container mt-5">
    <h1>Registrar Venta</h1>
    <div class="card mb-3">
        <div class="card-body">
            <form id="ventaForm">
                <div class="row">
                    <div class="col-md-6">
                        <label for="reserva_id" class="form-label">Seleccionar Reserva</label>
                        <select name="reserva_id" id="reserva_id" class="form-select" required>
                            <?php
                            include_once "funciones.php";
                            $conn = obtenerbd();
                            $reservas = $conn->query("SELECT id, codigo_reserva FROM reservas WHERE estado = 'pendiente'");
                            while ($row = $reservas->fetch(PDO::FETCH_ASSOC)) {
                                echo "<option value=\"{$row['id']}\">{$row['codigo_reserva']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-6">
                        <label for="tarifa" class="form-label">Tarifa</label>
                        <input type="text" id="tarifa" class="form-control" readonly>
                    </div>
                    <div class="col-md-6">
                        <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
                        <input type="number" id="cantidad_clientes" class="form-control" readonly>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header">Productos</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Total</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="productos-list">
                        <!-- Aquí se añadirán los productos -->
                    </tbody>
                </table>
            </div>
            <input type="text" id="producto-buscar" class="form-control" placeholder="Buscar Producto">
            <button type="button" id="agregar-producto" class="btn btn-primary mt-2">Agregar Producto</button>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <h4>Total de la Venta: $<span id="total-venta">0.00</span></h4>
        </div>
    </div>

    <button type="submit" form="ventaForm" class="btn btn-success">Guardar Venta</button>
</div>

<script>
    // Obtener datos de la reserva al seleccionar
    $('#reserva_id').on('change', function () {
        var reservaId = $(this).val();
        
        $('#tarifa').val('');
        $('#cantidad_clientes').val('');

        $.ajax({
            url: 'obtener_datos_reserva.php',
            type: 'POST',
            data: {reserva_id: reservaId},
            success: function (response) {
                var datos = JSON.parse(response);
                $('#tarifa').val(datos.precio); // Asegúrate que el nombre de la columna es correcto
                $('#cantidad_clientes').val(datos.cantidad_clientes);
                calcularTotal(); // Llama a la función para actualizar el total
            }
        });
    });

    // Función para calcular el total de la venta
    function calcularTotal() {
        var tarifa = parseFloat($('#tarifa').val());
        var cantidadClientes = parseInt($('#cantidad_clientes').val());
        var totalProductos = calcularTotalProductos();
        var totalVenta = (tarifa * cantidadClientes) + totalProductos;
        $('#total-venta').text(totalVenta.toFixed(2));
    }

    // Función para calcular el total de productos
    function calcularTotalProductos() {
        var total = 0;
        $('#productos-list tr').each(function () {
            var precio = parseFloat($(this).find('.precio-unitario').text());
            var cantidad = parseInt($(this).find('.cantidad-producto').val());
            total += precio * cantidad;
        });
        return total;
    }

    // Autocompletar para productos
    $('#producto-buscar').autocomplete({
        source: function (request, response) {
            $.ajax({
                url: 'buscar_productos.php', // Ruta al script PHP que trae los datos de productos
                type: 'GET',
                data: {term: request.term},
                success: function (data) {
                    response(data);
                }
            });
        },
        minLength: 1,
        select: function (event, ui) {
            agregarProducto(ui.item);
        }
    });

    // Agregar producto dinámicamente
    function agregarProducto(producto) {
        var nuevoProducto = `
            <tr>
                <td>${producto.nombre}</td>
                <td><input type="number" class="form-control cantidad-producto" value="1" required></td>
                <td class="precio-unitario">${producto.precio}</td>
                <td class="total-producto">$${producto.precio}</td>
                <td><button type="button" class="btn btn-danger eliminar-producto">Eliminar</button></td>
            </tr>
        `;
        $('#productos-list').append(nuevoProducto);
        calcularTotal();
    }

    // Agregar producto con botón
    $('#agregar-producto').on('click', function () {
        var nombreProducto = $('#producto-buscar').val();
        if (nombreProducto) {
            // Realizar la búsqueda en la base de datos
            $.ajax({
                url: 'buscar_producto_por_nombre.php',
                type: 'POST',
                data: {nombre: nombreProducto},
                success: function (response) {
                    var producto = JSON.parse(response);
                    agregarProducto(producto);
                }
            });
        }
    });

    // Eliminar producto
    $(document).on('click', '.eliminar-producto', function () {
        $(this).closest('tr').remove();
        calcularTotal();
    });

    // Recalcular total cuando se cambia la cantidad
    $(document).on('input', '.cantidad-producto', function () {
        calcularTotal();
    });
</script>

</body>
</html>
