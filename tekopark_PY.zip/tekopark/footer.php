<?php
//
?>
<footer class="footer text-center">
    <div class="container">
        <a href="https://www.hupistudio.net">www.hupistudio.net</a> | &copy; <?php echo date('Y'); ?> el autor no se responsabiliza por el uso indhebido del sistemas, para uso de: TekoPark  |
        <a href="https://hupistudio.net/contact.html">Ayuda/Contacto</a> |
    </div>
</footer>
<!-- Scripts de Bootstrap y jQuery -->
<script src="./js/jquery.min.js"></script>
<script src="./js/