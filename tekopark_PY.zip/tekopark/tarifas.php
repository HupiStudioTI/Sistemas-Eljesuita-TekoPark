<?php
/**
 * tarifas.php – Listado, búsqueda y paginación de tarifas
 * ------------------------------------------------------------------
 * NOTA: asegurate de haber ejecutado el ALTER TABLE para que la
 * columna `dias` sea un SET(…).
 */
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color:#ff5722;">Gestión de Tarifas</h3>
    <h5>Administre las tarifas de actividades y servicios aquí.</h5>
</div>
</div>';
include_once "encabezado.php";
include_once "conexion.php";

/* ---------- util ---------- */
function traducirDias($cadena) {
    if (empty($cadena)) return '';
    $map = ['lun'=>'Lun','mar'=>'Mar','mie'=>'Mié','jue'=>'Jue',
            'vie'=>'Vie','sab'=>'Sáb','dom'=>'Dom'];
    $out = [];
    foreach (explode(',', $cadena) as $c) {
        $out[] = $map[$c] ?? $c;
    }
    return implode(', ', $out);
}

/* ---------- paginación ---------- */
$limit  = 10;
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page-1) * $limit;

$total        = $conn->query("SELECT COUNT(*) AS total FROM tarifas")
                     ->fetch_assoc()['total'];
$total_pages  = ceil($total / $limit);
$result       = $conn->query("SELECT * FROM tarifas LIMIT $limit OFFSET $offset");
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="add_tarifa.php" class="btn btn-success btn-sm">Agregar</a>
                <form id="buscador-form" class="d-flex">
                    <input id="busqueda" name="busqueda"
                           class="form-control form-control-sm me-2"
                           type="text" placeholder="Buscar por actividad o tarifa">
                </form>
            </div>

            <!-- Tabla -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Actividad</th>
                            <th>Tarifa</th>
                            <th>Días</th>
                            <th>Duración</th>
                            <th>Precio</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-tarifas">
                    <?php if ($result->num_rows): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= $row['actividad'] ?></td>
                                <td><?= $row['nombretarifa'] ?></td>
                                <td><?= traducirDias($row['dias']) ?></td>
                                <td><?= $row['duracion'] ?></td>
                                <td><?= $row['precio'] ?></td>
                                <td>
                                    <a href="edit_tarifa.php?id=<?= $row['id'] ?>"
                                       class="btn btn-warning btn-sm">Editar</a>
                                    <a href="delete_tarifa.php?id=<?= $row['id'] ?>"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">No se encontraron tarifas.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center" id="paginacion">
                    <?php for ($i=1;$i<=$total_pages;$i++): ?>
                        <li class="page-item <?= $i===$page?'active':'' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<script>
/* ---------- util JS ---------- */
function traducirDiasJS(str) {
    if (!str) return '';
    const map = {lun:'Lun',mar:'Mar',mie:'Mié',jue:'Jue',
                 vie:'Vie',sab:'Sáb',dom:'Dom'};
    return str.split(',').map(c=>map[c] ?? c).join(', ');
}

/* ---------- carga AJAX ---------- */
function cargarTarifas(query='', pagina=1) {
    fetch(`buscar_tarifa.php?query=${encodeURIComponent(query)}&pagina=${pagina}`)
        .then(r => r.json())
        .then(data => {
            const tabla   = document.getElementById('tabla-tarifas');
            const nav     = document.getElementById('paginacion');
            tabla.innerHTML = '';
            nav.innerHTML   = '';

            if (data.tarifas.length) {
                data.tarifas.forEach(t => {
                    tabla.innerHTML += `
                    <tr>
                        <td>${t.id}</td>
                        <td>${t.actividad}</td>
                        <td>${t.nombretarifa}</td>
                        <td>${traducirDiasJS(t.dias)}</td>
                        <td>${t.duracion}</td>
                        <td>${t.precio}</td>
                        <td>
                            <a href="edit_tarifa.php?id=${t.id}" class="btn btn-warning btn-sm">Editar</a>
                            <a href="delete_tarifa.php?id=${t.id}" class="btn btn-danger btn-sm"
                               onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                        </td>
                    </tr>`;
                });
            } else {
                tabla.innerHTML = `<tr><td colspan="7" class="text-center">No se encontraron resultados.</td></tr>`;
            }

            /* -- construir navegación -- */
            const total = data.total_paginas;
            if (total > 1) {
                const disabled = pagina===1 ? 'disabled' : '';
                nav.innerHTML += `<li class="page-item ${disabled}">
                    <button class="page-link btn-sm" onclick="cargarTarifas('${query}',1)">Inicio</button></li>`;
                nav.innerHTML += `<li class="page-item ${disabled}">
                    <button class="page-link btn-sm" onclick="cargarTarifas('${query}',${pagina-1})">Anterior</button></li>`;

                const disabledFin = pagina===total ? 'disabled' : '';
                nav.innerHTML += `<li class="page-item ${disabledFin}">
                    <button class="page-link btn-sm" onclick="cargarTarifas('${query}',${pagina+1})">Siguiente</button></li>`;
                nav.innerHTML += `<li class="page-item ${disabledFin}">
                    <button class="page-link btn-sm" onclick="cargarTarifas('${query}',${total})">Fin</button></li>`;
            }
        })
        .catch(err => console.error(err));
}

/* ---------- init ---------- */
document.addEventListener('DOMContentLoaded', () => cargarTarifas());
document.getElementById('busqueda')
        .addEventListener('input', e => cargarTarifas(e.target.value));
</script>
<?php include 'footer.php'; ?>
