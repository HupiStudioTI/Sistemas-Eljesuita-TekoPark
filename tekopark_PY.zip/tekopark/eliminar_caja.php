<?php
include 'header.php';
include 'funciones.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    if (eliminarCaja($id)) {
        header('Location: cajas.php');
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar la caja.</div>";
    }
} else {
    echo "<div class='alert alert-warning'>ID de caja no proporcionado.</div>";
}

include 'footer.php';
?>
