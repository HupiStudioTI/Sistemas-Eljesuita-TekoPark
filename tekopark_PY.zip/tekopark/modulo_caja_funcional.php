<?php
require_once 'tcpdf/tcpdf.php'; // Incluye la librería TCPDF
include_once "funciones.php"; // Asumiendo que obtenerbd() está en funciones.php

// Obtener las fechas del formulario
$fecha_inicio = isset($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : null;
$fecha_fin = isset($_POST['fecha_fin']) ? $_POST['fecha_fin'] : null;
$formas_de_pago = ['efectivo', 'tarjeta', 'qr', 'mercadopago', 'canje', 'otros'];

// Inicializar totales
$datos = array_fill_keys($formas_de_pago, 0);

// Solo si se han enviado las fechas
if ($fecha_inicio && $fecha_fin) {
    $pdo = obtenerbd();
    $sql = "SELECT SUM(total) as total, modo_pago FROM ventas WHERE fecha BETWEEN :fecha_inicio AND :fecha_fin GROUP BY modo_pago";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':fecha_inicio' => $fecha_inicio, ':fecha_fin' => $fecha_fin]);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $modo_pago = strtolower($row['modo_pago']);
        if (isset($datos[$modo_pago])) {
            $datos[$modo_pago] = $row['total'];
        }
    }
}

// Función para generar PDF en formato ticket con líneas
if (isset($_POST['generar_pdf'])) {
    $pdf = new TCPDF('P', 'mm', [80, 200]); // Ancho ajustado a 80 mm para ticket
    $pdf->SetMargins(5, 5, 5); // Márgenes reducidos para aprovechar el espacio
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 10);
    
    // Título del PDF
    $pdf->Cell(0, 5, 'Informe de Caja', 0, 1, 'C');
    $pdf->Ln(5);
    
    // Agregar las fechas al informe
    $pdf->Cell(0, 5, 'Desde: ' . date('d/m/Y H:i', strtotime($fecha_inicio)), 0, 1, 'L');
    $pdf->Cell(0, 5, 'Hasta: ' . date('d/m/Y H:i', strtotime($fecha_fin)), 0, 1, 'L');
    $pdf->Ln(5);
    
    // Cuerpo del informe en formato de líneas
    foreach ($formas_de_pago as $forma_pago) {
        $pdf->Cell(0, 5, ucfirst(strtolower($forma_pago)) . ': $' . (isset($datos[$forma_pago]) ? number_format($datos[$forma_pago], 2) : '0.00'), 0, 1, 'L');
    }
    
    // Total General
    $pdf->Ln(5);
    $pdf->Cell(0, 5, 'Total General: $' . number_format(array_sum($datos), 2), 0, 1, 'L');
    
    // Output PDF
    $pdf->Output('informe_caja_ticket.pdf', 'I');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Módulo de Caja</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Informe de Caja</h1>
    
    <div class="card">
        <div class="card-body">
            <form method="POST" action="modulo_caja.php">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="fecha_inicio" class="form-label">Fecha y Hora Inicio</label>
                        <input type="datetime-local" name="fecha_inicio" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="fecha_fin" class="form-label">Fecha y Hora Fin</label>
                        <input type="datetime-local" name="fecha_fin" class="form-control" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary no-print">Generar Informe</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if (!empty($datos)): ?>
        <div class="card mt-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Forma de Pago</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($formas_de_pago as $forma_pago): ?>
                                <tr>
                                    <td><?php echo ucfirst(strtolower($forma_pago)); ?></td>
                                    <td><?php echo isset($datos[$forma_pago]) ? '$' . number_format($datos[$forma_pago], 2) : '$0.00'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr>
                                <td><strong>Total General</strong></td>
                                <td><strong>$<?php echo number_format(array_sum($datos), 2); ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                    <form method="POST" action="modulo_caja.php" class="mt-4">
                        <!-- Mantener las fechas ingresadas para imprimir -->
                        <input type="hidden" name="fecha_inicio" value="<?php echo $fecha_inicio; ?>">
                        <input type="hidden" name="fecha_fin" value="<?php echo $fecha_fin; ?>">
                        <button type="submit" name="generar_pdf" class="btn btn-secondary">Imprimir Informe en Ticket</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
