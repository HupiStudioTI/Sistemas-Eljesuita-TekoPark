<?php
// edit_reservas.php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Reservas</h3>
    <h5>Edicion de Reservas.</h5>
</div>
</div>';
// edit_reserva.php

// Incluir encabezado y funciones
include_once "encabezado.php";
include_once "funciones.php";

// Habilitar la visualización de errores (para depuración)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$mensaje = "";

// Obtener el ID de la reserva a editar desde la URL
$reserva_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Verificar si la reserva existe
if ($reserva_id <= 0 || !($reserva = obtenerReservaPorId($reserva_id))) {
    die("Reserva no encontrada.");
}

// Manejar la lógica de actualizar reserva
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y sanitizar los datos del formulario
    $codigo_reserva = isset($_POST["codigo_reserva"]) ? trim($_POST["codigo_reserva"]) : '';
    $actividad = isset($_POST["actividad"]) ? trim($_POST["actividad"]) : '';
    $tarifa_id = isset($_POST["tarifa_id"]) ? intval($_POST["tarifa_id"]) : 0;
    $fecha_reserva = isset($_POST["fecha_reserva"]) ? trim($_POST["fecha_reserva"]) : date("Y-m-d");
    $hora_desde = isset($_POST["hora_desde"]) ? trim($_POST["hora_desde"]) : date("H:i");
    $hora_hasta = isset($_POST["hora_hasta"]) ? trim($_POST["hora_hasta"]) : '';
    $cantidad_clientes = isset($_POST["cantidad_clientes"]) ? intval($_POST["cantidad_clientes"]) : 0;
    $estado = isset($_POST["estado"]) ? trim($_POST["estado"]) : 'pendiente';
    
    // Obtener clientes, IDs, identificaciones y pulseras
    $clientes = isset($_POST['clientes']) ? $_POST['clientes'] : [];
    $cliente_ids = isset($_POST['cliente_ids']) ? $_POST['cliente_ids'] : [];
    $identificaciones = isset($_POST['identificaciones']) ? $_POST['identificaciones'] : [];
    $pulseras = isset($_POST['pulseras']) ? $_POST['pulseras'] : [];
    
    // Validaciones básicas
    $errores = [];
    if (empty($codigo_reserva)) $errores[] = "El código de reserva es obligatorio.";
    if (empty($actividad)) $errores[] = "La actividad es obligatoria.";
    if ($tarifa_id <= 0) $errores[] = "La tarifa es obligatoria.";
    if (empty($fecha_reserva)) $errores[] = "La fecha de reserva es obligatoria.";
    if (empty($hora_desde)) $errores[] = "La hora desde es obligatoria.";
    if ($cantidad_clientes <= 0) $errores[] = "La cantidad de clientes debe ser al menos 1.";
    if (count($clientes) != $cantidad_clientes || count($identificaciones) != $cantidad_clientes || count($pulseras) != $cantidad_clientes || count($cliente_ids) != $cantidad_clientes) {
        $errores[] = "Número de clientes, identificaciones, pulseras o IDs no coincide con la cantidad especificada.";
    }
    
    // Validar que todos los cliente_ids existan en la tabla clientes
    foreach ($cliente_ids as $cliente_id) {
        if (!clienteExiste($cliente_id)) { // Asegúrate de tener esta función definida
            $errores[] = "El cliente con ID {$cliente_id} no existe.";
            break;
        }
    }
    
    // Verificar que el código de reserva sea único (excluyendo la reserva actual)
    if (codigoReservaExisteExcluyendo($codigo_reserva, $reserva_id)) { // Define esta función
        $errores[] = "El código de reserva '{$codigo_reserva}' ya existe. Por favor, genere uno único.";
    }
    
    if (empty($errores)) {
        try {
            // Iniciar transacción
            $bd = obtenerBD(); // Asegúrate de tener esta función definida para obtener la conexión a la BD
            $bd->beginTransaction();
            
            // Actualizar reserva
            actualizarReserva($reserva_id, $codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado); // Define esta función
            
            // Eliminar asociaciones previas de clientes
            eliminarClientesReserva($reserva_id); // Define esta función
            
            // Asociar nuevos clientes a la reserva
            asociarClientesReserva($reserva_id, $cliente_ids, $identificaciones, $pulseras); // Define esta función
            
            // Confirmar transacción
            $bd->commit();
            
            // Mostrar mensaje de éxito y redirigir
            $mensaje = "<div class='alert alert-success'>
                        <strong>Reserva actualizada con éxito.</strong><br>
                        <strong>Código de Reserva:</strong> " . htmlspecialchars($codigo_reserva) . "<br>
                        Redirigiendo a Reservas...
                      </div>";
            echo $mensaje;
            echo "<script>
                    setTimeout(function() {
                        window.location.href = 'reservas.php';
                    }, 3000); // Redirige después de 3 segundos
                  </script>";
            exit(); // Terminar el script después de redirigir
        } catch (Exception $e) {
            // Revertir transacción en caso de error
            $bd->rollBack();
            $mensaje = "<div class='alert alert-danger'>Error al actualizar la reserva: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    } else {
        // Mostrar errores
        $mensaje = "<div class='alert alert-danger'><ul>";
        foreach ($errores as $error) {
            $mensaje .= "<li>" . htmlspecialchars($error) . "</li>";
        }
        $mensaje .= "</ul></div>";
    }
}

/**
 * Verifica si un código de reserva ya existe en la base de datos, excluyendo una reserva específica.
 *
 * @param string $codigo_reserva Código de reserva a verificar.
 * @param int $excluir_id ID de la reserva a excluir de la verificación.
 * @return bool Verdadero si el código existe, falso en caso contrario.
 */
function codigoReservaExisteExcluyendo($codigo_reserva, $excluir_id) {
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total FROM reservas WHERE codigo_reserva = :codigo_reserva AND id != :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':codigo_reserva' => $codigo_reserva, ':id' => $excluir_id]);
    $result = $stmt->fetch(PDO::FETCH_OBJ);
    return $result->total > 0;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Reserva</title>
    <!-- Incluye tus archivos CSS locales aquí -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <!-- Font Awesome CSS Local -->
    <link rel="stylesheet" href="css/all.min.css"> <!-- Reemplaza con la ruta correcta -->
    <style>
        /* Recuadro alrededor de los campos de entrada y selección */
        .input-bordered {
            border: 2px solid #ff5722; /* Color del borde */
            border-radius: 5px;
            padding: 5px;
        }
        /* Reducir el ancho de los inputs específicos */
        #cantidad_clientes {
            width: 100px; /* Ajusta este valor según tus preferencias */
        }
        #estado {
            width: 150px; /* Ajusta este valor según tus preferencias */
        }
        /* Estilos personalizados para el menú de autocomplete */
        .ui-autocomplete {
            background-color: #ffffff; /* Fondo blanco */
            border: 1px solid #ced4da; /* Borde similar a Bootstrap */
            max-height: 200px;
            overflow-y: auto;
            /* Evitar que el menú se muestre debajo de otros elementos */
            z-index: 1050;
        }
        
        .ui-menu-item-wrapper {
            padding: 8px 12px;
            cursor: pointer;
        }
        
        /* Resaltar el elemento activo */
        .ui-menu-item-wrapper.ui-state-active {
            background-color: #ff5722; /* Color de fondo al pasar el mouse o al seleccionar con teclado */
            color: #ffffff; /* Color del texto cuando está activo */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <?php if (!empty($mensaje)) echo $mensaje; ?>

    <form action="edit_reserva.php?id=<?php echo htmlspecialchars($reserva_id); ?>" method="POST">
        <!-- Primera Fila: Código de Reserva y Actividad -->
        <div class="row mb-3">
            <div class="col-md-4">
                <label for="codigo_reserva" class="form-label">Código de Reserva</label>
                <input type="text" name="codigo_reserva" class="form-control form-control-sm input-bordered" id="codigo_reserva" maxlength="20" 
                value="<?php 
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        echo isset($_POST['codigo_reserva']) ? htmlspecialchars($_POST['codigo_reserva']) : '';
                    } else {
                        echo htmlspecialchars($reserva->codigo_reserva);
                    }
                ?>" placeholder="Ejemplo: CR240125100900" required>
            </div>
            <div class="col-md-4">
                <label for="actividad" class="form-label">Actividad</label>
                <select id="actividad" name="actividad" class="form-select form-select-sm input-bordered" required>
                    <option value="">Seleccione una actividad</option>
                    <?php
                    $actividades = obtenerDepartamentos(); // Asegúrate de que esta función retorna las actividades
                    foreach ($actividades as $act) {
                        $selected = (isset($_POST['actividad']) && $_POST['actividad'] === $act) ? 'selected' : ((isset($reserva->actividad) && $reserva->actividad === $act) ? 'selected' : '');
                        echo "<option value=\"" . htmlspecialchars($act) . "\" {$selected}>" . htmlspecialchars($act) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        
        <!-- Segunda Fila: Tarifa -->
        <div class="row mb-3">
            <div class="col-md-8">
                <label for="tarifa_id" class="form-label">Tarifa</label>
                <select id="tarifa_id" name="tarifa_id" class="form-select form-select-sm input-bordered" required>
                    <option value="">Seleccione una tarifa</option>
                    <?php
                    $tarifas = obtenerTarifas();
                    foreach ($tarifas as $tarifa) {
                        $selected = (isset($_POST['tarifa_id']) && $_POST['tarifa_id'] == $tarifa->id) ? 'selected' : ((isset($reserva->tarifa_id) && $reserva->tarifa_id == $tarifa->id) ? 'selected' : '');
                        echo "<option value=\"" . htmlspecialchars($tarifa->id) . "\" data-duracion=\"" . htmlspecialchars($tarifa->duracion) . "\" {$selected}>" . htmlspecialchars("{$tarifa->actividad} - {$tarifa->nombretarifa} ({$tarifa->dias}) - {$tarifa->duracion} min - \${$tarifa->precio}") . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        
        <!-- Tercera Fila: Fecha de Reserva, Hora Desde, Hora Hasta -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="fecha_reserva" class="form-label">Fecha de Reserva</label>
                <input type="date" name="fecha_reserva" class="form-control form-control-sm input-bordered" id="fecha_reserva" 
                value="<?php 
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        echo isset($_POST['fecha_reserva']) ? htmlspecialchars($_POST['fecha_reserva']) : '';
                    } else {
                        echo htmlspecialchars($reserva->fecha_reserva);
                    }
                ?>" required>
            </div>
            <div class="col-md-3">
                <label for="hora_desde" class="form-label">Hora Desde</label>
                <input type="time" name="hora_desde" class="form-control form-control-sm input-bordered" id="hora_desde" 
                value="<?php 
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        echo isset($_POST['hora_desde']) ? htmlspecialchars($_POST['hora_desde']) : '';
                    } else {
                        echo htmlspecialchars($reserva->hora_desde);
                    }
                ?>" required>
            </div>
            <div class="col-md-3">
                <label for="hora_hasta" class="form-label">Hora Hasta</label>
                <input type="time" name="hora_hasta" class="form-control form-control-sm input-bordered" id="hora_hasta" 
                value="<?php 
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        echo isset($_POST['hora_hasta']) ? htmlspecialchars($_POST['hora_hasta']) : '';
                    } else {
                        echo htmlspecialchars($reserva->hora_hasta);
                    }
                ?>">
            </div>
        </div>
        
        <!-- Cuarta Fila: Cantidad de Clientes y Estado -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
                <input type="number" name="cantidad_clientes" class="form-control form-control-sm input-bordered" id="cantidad_clientes" 
                value="<?php 
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        echo isset($_POST['cantidad_clientes']) ? htmlspecialchars($_POST['cantidad_clientes']) : '';
                    } else {
                        echo htmlspecialchars($reserva->cantidad_clientes);
                    }
                ?>" min="1" required>
            </div>
            <div class="col-md-3">
                <label for="estado" class="form-label">Estado</label>
                <select id="estado" name="estado" class="form-select form-select-sm input-bordered" required>
                    <?php
                    $estados = ['pendiente', 'pagada', 'cancelada'];
                    foreach ($estados as $estado_option) {
                        $selected = (isset($_POST['estado']) && $_POST['estado'] === $estado_option) ? 'selected' : ((isset($reserva->estado) && $reserva->estado === $estado_option) ? 'selected' : '');
                        echo "<option value=\"" . htmlspecialchars($estado_option) . "\" {$selected}>" . ucfirst(htmlspecialchars($estado_option)) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        
        <!-- Quinta Fila: Clientes Asociados -->
        <div id="clientes_container">
            <?php
            // Si se ha enviado el formulario y hay clientes, cargarlos
            if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['clientes'])) {
                foreach ($_POST['clientes'] as $index => $cliente) {
                    $identificacion = isset($_POST['identificaciones'][$index]) ? htmlspecialchars($_POST['identificaciones'][$index]) : '';
                    $pulsera = isset($_POST['pulseras'][$index]) ? htmlspecialchars($_POST['pulseras'][$index]) : '';
                    $cliente_valor = htmlspecialchars($cliente);
                    $cliente_id = isset($_POST['cliente_ids'][$index]) ? htmlspecialchars($_POST['cliente_ids'][$index]) : '';
                    echo "<div class='row mb-3'>
                            <div class='col-md-4'>
                                <label for='cliente_" . ($index + 1) . "' class='form-label'>Cliente " . ($index + 1) . "</label>
                                <input type='text' name='clientes[]' class='form-control form-control-sm input-bordered cliente_search' id='cliente_" . ($index + 1) . "' value='{$cliente_valor}' placeholder='Buscar cliente por nombre, teléfono, etc.' required>
                                <input type='hidden' name='cliente_ids[]' class='cliente_id' value='{$cliente_id}'>
                            </div>
                            <div class='col-md-3'>
                                <label for='identificacion_" . ($index + 1) . "' class='form-label'>Identificación del Cliente " . ($index + 1) . "</label>
                                <input type='text' name='identificaciones[]' class='form-control form-control-sm input-bordered' id='identificacion_" . ($index + 1) . "' value='{$identificacion}' placeholder='Ejemplo: FLACO, MOROCHO, CON SOMBRERO' required>
                            </div>
                            <div class='col-md-2'>
                                <label for='pulsera_" . ($index + 1) . "' class='form-label'>Pulsera del Cliente " . ($index + 1) . "</label>
                                <input type='text' name='pulseras[]' class='form-control form-control-sm input-bordered' id='pulsera_" . ($index + 1) . "' value='{$pulsera}' placeholder='Ejemplo: A123' required>
                            </div>
                          </div>";
                }
            } else {
                // Si no se ha enviado el formulario, cargar los clientes asociados existentes
                if (!empty($reserva->clientes)) {
                    foreach ($reserva->clientes as $index => $cliente_assoc) {
                        $cliente_id = htmlspecialchars($cliente_assoc->cliente_id);
                        $cliente_nombre = htmlspecialchars(obtenerNombreCliente($cliente_id));
                        $identificacion = htmlspecialchars($cliente_assoc->identificacion);
                        // Solucionar el acceso a 'pulsera' aquí
                        $pulsera = isset($cliente_assoc->pulsera) ? htmlspecialchars($cliente_assoc->pulsera) : '';
                        echo "<div class='row mb-3'>
                                <div class='col-md-4'>
                                    <label for='cliente_" . ($index + 1) . "' class='form-label'>Cliente " . ($index + 1) . "</label>
                                    <input type='text' name='clientes[]' class='form-control form-control-sm input-bordered cliente_search' id='cliente_" . ($index + 1) . "' value='{$cliente_nombre}' placeholder='Buscar cliente por nombre, teléfono, etc.' required>
                                    <input type='hidden' name='cliente_ids[]' class='cliente_id' value='{$cliente_id}'>
                                </div>
                                <div class='col-md-3'>
                                    <label for='identificacion_" . ($index + 1) . "' class='form-label'>Identificación del Cliente " . ($index + 1) . "</label>
                                    <input type='text' name='identificaciones[]' class='form-control form-control-sm input-bordered' id='identificacion_" . ($index + 1) . "' value='{$identificacion}' placeholder='Ejemplo: FLACO, MOROCHO, CON SOMBRERO' required>
                                </div>
                                <div class='col-md-2'>
                                    <label for='pulsera_" . ($index + 1) . "' class='form-label'>Pulsera del Cliente " . ($index + 1) . "</label>
                                    <input type='text' name='pulseras[]' class='form-control form-control-sm input-bordered' id='pulsera_" . ($index + 1) . "' value='{$pulsera}' placeholder='Ejemplo: A123' required>
                                </div>
                              </div>";
                    }
                }
            }
            ?>
        </div>
        
        <!-- Botón de Envío -->
        <button type="submit" class="btn btn-primary btn-sm">Actualizar Reserva</button>
        
        <!-- Espaciado Extra -->
        <br><br><br>
    </form>
</div>

<?php include_once "footer.php"; ?>

<!-- Incluye tus archivos JS locales aquí -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script>
    $(document).ready(function() {
        /**
         * Función para calcular la "Hora Hasta" basada en la tarifa y la "Hora Desde"
         */
        function calcularHoraHasta() {
            const duracionTarifa = $('#tarifa_id').find(':selected').data('duracion'); // Duración en minutos
            const horaDesde = $('#hora_desde').val(); // Obtener la "Hora Desde"
            if (duracionTarifa && horaDesde) {
                let [hours, minutes] = horaDesde.split(':');
                let horaDesdeDate = new Date();
                horaDesdeDate.setHours(parseInt(hours), parseInt(minutes), 0);
                // Añadir la duración en minutos a la "Hora Desde"
                horaDesdeDate.setMinutes(horaDesdeDate.getMinutes() + parseInt(duracionTarifa));
                // Obtener la "Hora Hasta" en formato HH:mm
                let horaHasta = horaDesdeDate.toTimeString().split(':').slice(0, 2).join(':');
                $('#hora_hasta').val(horaHasta);
            } else {
                // Si no hay duración o "Hora Desde", limpiar el campo "Hora Hasta"
                $('#hora_hasta').val('');
            }
        }

        /**
         * Evento de cambio en la tarifa seleccionada o en la "Hora Desde"
         */
        $('#tarifa_id, #hora_desde').on('change', function() {
            calcularHoraHasta();
        });

        // Si al cargar la página ya hay una tarifa seleccionada, calcular la "Hora Hasta"
        if ($('#tarifa_id').val() && $('#hora_desde').val()) {
            calcularHoraHasta();
        }

        /**
         * Evento de cambio en la cantidad de clientes
         */
        $('#cantidad_clientes').on('input', function() {
            let cantidad = parseInt($(this).val());
            let container = $('#clientes_container');
            container.empty();
            if (!isNaN(cantidad) && cantidad > 0) {
                for (let i = 1; i <= cantidad; i++) {
                    container.append(`
                        <div class='row mb-3'>
                            <div class='col-md-4'>
                                <label for='cliente_${i}' class='form-label'>Cliente ${i}</label>
                                <input type='text' name='clientes[]' class='form-control form-control-sm input-bordered cliente_search' id='cliente_${i}' placeholder='Buscar cliente por nombre, teléfono, etc.' required>
                                <input type='hidden' name='cliente_ids[]' class='cliente_id' value=''>
                            </div>
                            <div class='col-md-3'>
                                <label for='identificacion_${i}' class='form-label'>Identificación del Cliente ${i}</label>
                                <input type='text' name='identificaciones[]' class='form-control form-control-sm input-bordered' id='identificacion_${i}' placeholder='Ejemplo: FLACO, MOROCHO, CON SOMBRERO' required>
                            </div>
                            <div class='col-md-2'>
                                <label for='pulsera_${i}' class='form-label'>Pulsera del Cliente ${i}</label>
                                <input type='text' name='pulseras[]' class='form-control form-control-sm input-bordered' id='pulsera_${i}' placeholder='Ejemplo: A123' required>
                            </div>
                        </div>
                    `);
                    // Inicializar autocomplete para cada campo de cliente
                    $(`#cliente_${i}`).autocomplete({
                        source: function(request, response) {
                            $.ajax({
                                url: "buscar_clientes_reservas.php",
                                method: "GET",
                                dataType: "json",
                                data: { query: request.term },
                                success: function(data) {
                                    response($.map(data, function(item) {
                                        return {
                                            label: item.label, // Nombre del cliente
                                            value: item.value // ID del cliente
                                        };
                                    }));
                                },
                                error: function() {
                                    response([]);
                                }
                            });
                        },
                        minLength: 2,
                        select: function(event, ui) {
                            $(this).val(ui.item.label); // Mostrar solo el nombre
                            // Almacenar el ID del cliente en el campo oculto
                            $(this).siblings('.cliente_id').val(ui.item.value);
                            return false;
                        }
                    }).autocomplete("instance")._renderItem = function(ul, item) {
                        return $("<li>")
                            .append("<div>" + item.label + "</div>") // Mostrar solo el nombre
                            .appendTo(ul);
                    };
                }
            }
        });

        /**
         * Inicializar los clientes existentes al cargar la página
         */
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['clientes'])): ?>
            $('#cantidad_clientes').trigger('input');
        <?php endif; ?>
    });
</script>
</body>
</html>
