<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Tarifa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script>
        // Función para calcular la hora de fin automáticamente
        function calcularHoraFin() {
            const horaInicio = document.getElementById('hora_inicio').value;
            const duracion = document.getElementById('duracion').value;
            
            if (horaInicio) {
                const [horas, minutos] = horaInicio.split(':').map(Number);
                const duracionHoras = duracion === '1h' ? 1 : 1.5;

                const fecha = new Date();
                fecha.setHours(horas);
                fecha.setMinutes(minutos);

                fecha.setMinutes(fecha.getMinutes() + duracionHoras * 60);

                const horasFin = String(fecha.getHours()).padStart(2, '0');
                const minutosFin = String(fecha.getMinutes()).padStart(2, '0');
                document.getElementById('hora_fin').value = `${horasFin}:${minutosFin}`;
            }
        }
    </script>
</head>
<body>
<?php include_once "encabezado.php"; ?>
<div class="container mt-5">
    <h1>Agregar Tarifa</h1>
    <form action="guardar_tarifa.php" method="POST">
        <div class="mb-3">
            <label for="actividad" class="form-label">Actividad</label>
            <input type="text" name="actividad" class="form-control" id="actividad" required>
        </div>
        <div class="mb-3">
            <label for="dia_semana" class="form-label">Día de la semana</label>
            <select name="dia_semana" class="form-select" id="dia_semana" required>
                <option value="Lunes">Lunes</option>
                <option value="Martes">Martes</option>
                <option value="Miércoles">Miércoles</option>
                <option value="Jueves">Jueves</option>
                <option value="Viernes">Viernes</option>
                <option value="Sábado">Sábado</option>
                <option value="Domingo">Domingo</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="hora_inicio" class="form-label">Hora de inicio</label>
            <input type="time" name="hora_inicio" class="form-control" id="hora_inicio" oninput="calcularHoraFin()" required>
        </div>
        <div class="mb-3">
            <label for="duracion" class="form-label">Duración</label>
            <select name="duracion" class="form-select" id="duracion" oninput="calcularHoraFin()" required>
                <option value="1h">1 Hora</option>
                <option value="1.5h">1 Hora y Media</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="hora_fin" class="form-label">Hora de fin</label>
            <input type="time" name="hora_fin" class="form-control" id="hora_fin" readonly>
        </div>
        <div class="mb-3">
            <label for="precio" class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" class="form-control" id="precio" required>
        </div>
        <button type="submit" class="btn btn-success">Guardar Tarifa</button>
    </form>
</div>
<?php include_once "pie.php"; ?>
</body>
</html>
