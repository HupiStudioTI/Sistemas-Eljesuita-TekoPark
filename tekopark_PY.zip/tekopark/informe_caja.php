<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informe de Caja</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 30px;
        }
        h1, h2 {
            color: #343a40;
        }
        h1 {
            font-size: 1.8rem;
        }
        h2 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .table-responsive {
            margin-top: 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        @media (max-width: 768px) {
            h1 {
                font-size: 1.5rem;
            }
            .form-label {
                font-size: 0.9rem;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mb-4">Informe de Caja</h1>
    
    <!-- Formulario para seleccionar el rango de fechas -->
    <div class="card">
        <div class="card-body">
            <form method="POST" action="modulo_caja.php">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="fecha_inicio" class="form-label">Fecha y Hora Inicio</label>
                        <input type="datetime-local" name="fecha_inicio" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label for="fecha_fin" class="form-label">Fecha y Hora Fin</label>
                        <input type="datetime-local" name="fecha_fin" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Generar Reporte</button>
            </form>
        </div>
    </div>

    <!-- Sección para mostrar ventas por tarifas (sin incluir productos) -->
    <?php if (!empty($ventasTarifas)): ?>
        <div class="card mt-4">
            <div class="card-body">
                <h2>Ventas por Tarifas</h2>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Tarifa</th>
                                <th>Cantidad Vendida</th>
                                <th>Importe</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ventasTarifas as $tarifa): ?>
                                <tr>
                                    <td><?php echo $tarifa['nombre_tarifa']; ?></td>
                                    <td><?php echo $tarifa['cantidad_vendida']; ?></td>
                                    <td><?php echo '$' . number_format($tarifa['importe_total'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Sección para mostrar los productos vendidos -->
    <?php if (!empty($productosAgrupados)): ?>
        <div class="card mt-4">
            <div class="card-body">
                <h2>Productos Vendidos</h2>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Producto</th>
                                <th>Cantidad Vendida</th>
                                <th>Importe</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($productosAgrupados as $producto): ?>
                                <tr>
                                    <td><?php echo $producto['nombre_producto']; ?></td>
                                    <td><?php echo $producto['cantidad_vendida']; ?></td>
                                    <td><?php echo '$' . number_format($producto['importe_total'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
