<?php
session_start();
require 'conexion.php'; // Asegúrate de que este archivo establezca la conexión en la variable $conn

// Solo los administradores pueden acceder al ABM de usuarios
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'nuevo') {
    // Alta de nuevo usuario
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre = trim($_POST['nombre']);
        $clave  = trim($_POST['clave']);
        $rol    = $_POST['rol'];
        
        // Hasheamos la contraseña
        $claveHasheada = password_hash($clave, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, clave, rol) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nombre, $claveHasheada, $rol);
        $stmt->execute();
        header("Location: abm_usuarios.php");
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Nuevo Usuario</title>
      <link href="./css/bootstrap.min.css" rel="stylesheet">
      <link href="./css/all.min.css" rel="stylesheet">
    </head>
    <body>
      <div class="container mt-5">
          <div class="card">
              <div class="card-header bg-primary text-white">
                  Nuevo Usuario
              </div>
              <div class="card-body">
                  <form method="post" action="">
                      <div class="mb-3">
                          <label class="form-label">Nombre:</label>
                          <input type="text" name="nombre" class="form-control" required>
                      </div>
                      <div class="mb-3">
                          <label class="form-label">Clave:</label>
                          <input type="password" name="clave" class="form-control" required>
                      </div>
                      <div class="mb-3">
                          <label class="form-label">Rol:</label>
                          <select name="rol" class="form-select">
                              <option value="admin">Admin</option>
                              <option value="ventas">Ventas</option>
                              <option value="monitoreo">Monitoreo</option>
                          </select>
                      </div>
                      <button type="submit" class="btn btn-success">Crear Usuario</button>
                      <a href="abm_usuarios.php" class="btn btn-secondary">Volver</a>
                  </form>
              </div>
          </div>
      </div>
      <script src="./js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
    exit();
}

if ($action == 'editar') {
    $id = $_GET['id'];
    // Obtenemos los datos del usuario
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();
    
    if (!$usuario) {
        echo "Usuario no encontrado.";
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre = trim($_POST['nombre']);
        $rol    = $_POST['rol'];
        // Si se ingresa una nueva clave, se actualiza; si no, se mantiene la anterior
        if (!empty($_POST['clave'])) {
            $clave = password_hash($_POST['clave'], PASSWORD_DEFAULT);
            $stmtUpdate = $conn->prepare("UPDATE usuarios SET nombre = ?, clave = ?, rol = ? WHERE id = ?");
            $stmtUpdate->bind_param("sssi", $nombre, $clave, $rol, $id);
        } else {
            $stmtUpdate = $conn->prepare("UPDATE usuarios SET nombre = ?, rol = ? WHERE id = ?");
            $stmtUpdate->bind_param("ssi", $nombre, $rol, $id);
        }
        $stmtUpdate->execute();
        header("Location: abm_usuarios.php");
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Editar Usuario</title>
      <link href="./css/bootstrap.min.css" rel="stylesheet">
      <link href="./css/all.min.css" rel="stylesheet">
    </head>
    <body>
      <div class="container mt-5">
          <div class="card">
              <div class="card-header bg-warning">
                  Editar Usuario
              </div>
              <div class="card-body">
                  <form method="post" action="">
                      <div class="mb-3">
                          <label class="form-label">Nombre:</label>
                          <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>
                      </div>
                      <div class="mb-3">
                          <label class="form-label">Clave (dejar en blanco para no cambiar):</label>
                          <input type="password" name="clave" class="form-control">
                      </div>
                      <div class="mb-3">
                          <label class="form-label">Rol:</label>
                          <select name="rol" class="form-select">
                              <option value="admin" <?php if($usuario['rol'] == 'admin') echo 'selected'; ?>>Admin</option>
                              <option value="ventas" <?php if($usuario['rol'] == 'ventas') echo 'selected'; ?>>Ventas</option>
                              <option value="monitoreo" <?php if($usuario['rol'] == 'monitoreo') echo 'selected'; ?>>Monitoreo</option>
                          </select>
                      </div>
                      <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
                      <a href="abm_usuarios.php" class="btn btn-secondary">Volver</a>
                  </form>
              </div>
          </div>
      </div>
      <script src="./js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
    exit();
}

if ($action == 'eliminar') {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: abm_usuarios.php");
    exit();
}

// Por defecto, se listan los usuarios
$result = $conn->query("SELECT * FROM usuarios");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ABM Usuarios</title>
  <link href="./css/bootstrap.min.css" rel="stylesheet">
  <link href="./css/all.min.css" rel="stylesheet">
  <style>
      body {
          background-color: #f4f4f9;
      }
  </style>
</head>
<body>
  <div class="container mt-5">
      <div class="d-flex justify-content-between align-items-center mb-3">
          <h1>Gestión de Usuarios</h1>
          <a href="abm_usuarios.php?action=nuevo" class="btn btn-success">Nuevo Usuario</a>
      </div>
      <div class="table-responsive">
          <table class="table table-bordered table-striped">
              <thead class="table-dark">
                  <tr>
                      <th>ID</th>
                      <th>Nombre</th>
                      <th>Rol</th>
                      <th>Acciones</th>
                  </tr>
              </thead>
              <tbody>
                  <?php while($row = $result->fetch_assoc()){ ?>
                  <tr>
                      <td><?php echo $row['id']; ?></td>
                      <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                      <td><?php echo $row['rol']; ?></td>
                      <td>
                          <a href="abm_usuarios.php?action=editar&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                          <a href="abm_usuarios.php?action=eliminar&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro de eliminar?')">Eliminar</a>
                      </td>
                  </tr>
                  <?php } ?>
              </tbody>
          </table>
      </div>
      <a href="index.php" class="btn btn-secondary mt-3">Volver al inicio</a>
  </div>
  <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>
