<?php
include_once "conexion.php";

$query = isset($_GET['query']) ? $_GET['query'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 5; // Cambiar según necesidad
$inicio = ($pagina - 1) * $registros_por_pagina;

// Contar total de registros
$total_sql = $conn->prepare("SELECT COUNT(*) as total FROM colaboradores WHERE nombre LIKE ?");
$total_sql->bind_param("s", $like_query);
$like_query = "%$query%";
$total_sql->execute();
$total_result = $total_sql->get_result();
$total_registros = $total_result->fetch_assoc()['total'];

// Obtener registros paginados
$sql = $conn->prepare("SELECT * FROM colaboradores WHERE nombre LIKE ? LIMIT ?, ?");
$sql->bind_param("sii", $like_query, $inicio, $registros_por_pagina);
$sql->execute();
$result = $sql->get_result();

$colaboradores = [];
while ($row = $result->fetch_assoc()) {
    $colaboradores[] = $row;
}

echo json_encode([
    'colaboradores' => $colaboradores,
    'total_paginas' => ceil($total_registros / $registros_por_pagina),
]);
