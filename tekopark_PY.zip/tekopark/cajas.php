<?php
include 'header.php';
include 'funciones.php';
require_once('tcpdf/tcpdf.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha_desde = $_POST['fecha_desde'];
    $fecha_hasta = $_POST['fecha_hasta'];
    $cajas = obtenerInformeCajas($fecha_desde, $fecha_hasta);

    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 10);

    $html = '<h2>Informe de Cajas</h2>';
    $html .= '<p>Desde: ' . $fecha_desde . ' Hasta: ' . $fecha_hasta . '</p>';
    $html .= '<table border="1" cellspacing="0" cellpadding="5">
                <tr>
                    <th>Fecha</th>
                    <th>Colaborador</th>
                    <th>Forma de Pago</th>
                    <th>Crédito</th>
                    <th>Débito</th>
                    <th>Descripción</th>
                </tr>';

    foreach ($cajas as $caja) {
        $html .= '<tr>
                    <td>' . $caja['fecha'] . '</td>
                    <td>' . $caja['colaborador'] . '</td>
                    <td>' . ucfirst($caja['forma_pago']) . '</td>
                    <td>' . number_format($caja['credito'], 2, ',', '.') . '</td>
                    <td>' . number_format($caja['debito'], 2, ',', '.') . '</td>
                    <td>' . $caja['descripcion'] . '</td>
                  </tr>';
    }

    $html .= '</table>';
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('informe_cajas.pdf', 'I');
    exit;
}
?>

<div class="container mt-4">
    <h2>Generar Informe de Cajas</h2>
    <form method="POST" action="">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Fecha Desde</label>
                <input type="date" name="fecha_desde" class="form-control" required>
            </div>
            <div class="col-md-6 mb-3">
                <label>Fecha Hasta</label>
                <input type="date" name="fecha_hasta" class="form-control" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Generar PDF</button>
        <a href="cajas.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php include 'footer.php'; ?>
