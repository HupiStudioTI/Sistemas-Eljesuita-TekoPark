<?php
require_once __DIR__ . '/tcpdf/tcpdf.php';
require_once "conexion.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

/* ▸ validar id */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) die("ID inválido.");

$enc = $conn->prepare("SELECT * FROM facturas WHERE id = ?");
$enc->bind_param('i', $id);
$enc->execute();
$F = $enc->get_result()->fetch_assoc() or die("Factura no encontrada.");

$det = $conn->prepare("SELECT * FROM factura_items WHERE factura_id = ?");
$det->bind_param('i', $id);
$det->execute();
$items = $det->get_result()->fetch_all(MYSQLI_ASSOC);

/* ▸ crear PDF */
$pdf = new TCPDF('P', 'mm', 'A4');
$pdf->setPrintHeader(false);   // ← desactiva la línea de cabecera
$pdf->setPrintFooter(false);   // quita la de pie de página

$pdf->SetMargins(0, 0, 0);
$pdf->SetAutoPageBreak(false);
$pdf->AddPage();

/**
 * Función que imprime Original  /  Duplicado
 *
 * @param TCPDF $pdf
 * @param array $F
 * @param array $items
 * @param int   $off  Desplazamiento vertical en mm
 */
function pintarCopia($pdf, $F, $items, $off = 0) {
    /* === cabecera === */
    $pdf->SetFont('helvetica', '', 9);
    // Fecha
    $pdf->SetXY(45, 41 + $off);
    $pdf->Cell(40, 5, date('d/m/Y', strtotime($F['fecha'])), 0, 0);
    // Condición de venta
    $pdf->SetXY(145, 41 + $off);
    $pdf->Cell(40, 5, strtoupper($F['tipo_pago']), 0, 0);
    // Razón social (subida 2 mm)
    $pdf->SetXY(55, 46 + $off);
    $pdf->Cell(120, 5, $F['nombre'], 0, 0);
    // RUC (subido 2 mm)
    $pdf->SetXY(160, 46 + $off);
    $pdf->Cell(40, 5, $F['ruc'], 0, 0);
    // Dirección (subida 1 mm)
    $pdf->SetXY(30, 53 + $off);
    $pdf->Cell(120, 5, $F['direccion'], 0, 0);

    /* === detalle de ítems === */
    $y = 68 + $off;
    $h = 6;
    foreach ($items as $k => $it) {
        if ($k == 15) break;
        $pdf->SetXY(12, $y);
        $pdf->Cell(15, 5, $it['cantidad'], 0, 0, 'L');
        $pdf->SetXY(30, $y);
        $pdf->Cell(78, 5, substr($it['descripcion'], 0, 40), 0, 0, 'L');
        $pdf->SetXY(113, $y);
        $pdf->Cell(28, 5, number_format($it['importe_unitario'], 0, ',', '.'), 0, 0, 'R');
        $pdf->SetXY(165, $y);
        $pdf->Cell(28, 5, number_format($it['subtotal'], 0, ',', '.'), 0, 0, 'R');
        $y += $h;
    }

    /* === pie solicitado === */
    $pdf->SetFont('helvetica', '', 9);
    // Importe neto  (subido 2 mm)
    $pdf->SetXY(40, 118 + $off);
    $pdf->Cell(30, 5, number_format($F['importe_neto'], 0, ',', '.'), 0, 0, 'R');
    // Importe total (subido 2 mm)
    $pdf->SetXY(40, 123 + $off);
    $pdf->Cell(30, 5, number_format($F['importe_total'], 0, ',', '.'), 0, 0, 'R');
    // Impuesto (subido 2 mm)
    $pdf->SetXY(90, 133 + $off);
    $pdf->Cell(25, 5, number_format($F['impuesto'], 0, ',', '.'), 0, 0, 'R');
    $pdf->SetXY(140, 133 + $off);
    $pdf->Cell(25, 5, number_format($F['impuesto'], 0, ',', '.'), 0, 0, 'R');
}

// Original (offset 0 mm) + Duplicado (offset 150 mm)
pintarCopia($pdf, $F, $items, 0);
pintarCopia($pdf, $F, $items, 150);

$pdf->Output("Factura_{$F['nro_comprobante']}.pdf", 'I');
?>
