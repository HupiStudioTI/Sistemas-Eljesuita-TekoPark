<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php
include_once "encabezado.php";
include_once "conexion.php"; // Archivo de conexión a la base de datos

// Recibir el término de búsqueda
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';

// Definir la cantidad de registros por página
$registros_por_pagina = 10;
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Consulta con búsqueda y paginación
$sql = "SELECT v.id, v.fecha, v.total, v.modo_pago, r.codigo_reserva 
        FROM ventas v
        LEFT JOIN reservas r ON v.reserva_id = r.id
        WHERE v.fecha LIKE '%$buscar%'
        OR v.id LIKE '%$buscar%'
        OR r.codigo_reserva LIKE '%$buscar%'
        ORDER BY v.fecha DESC 
        LIMIT $inicio, $registros_por_pagina";

$result = $conn->query($sql);

// Contar el total de ventas para la paginación
$total_ventas = $conn->query("SELECT COUNT(DISTINCT v.id) as total 
    FROM ventas v
    LEFT JOIN reservas r ON v.reserva_id = r.id
    WHERE v.fecha LIKE '%$buscar%'
    OR v.id LIKE '%$buscar%'
    OR r.codigo_reserva LIKE '%$buscar%'")->fetch_assoc()['total'];

$total_paginas = ceil($total_ventas / $registros_por_pagina);
?>
<div class="container mt-5">
    <h1>Ventas</h1>
    <a href="sales.php" class="btn btn-success mb-3">Registrar Venta</a>
    <!-- Buscador -->
    <form method="GET" action="ventas.php" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por ID de venta, código de reserva o fecha." value="<?php echo htmlspecialchars($buscar); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>ID Venta</th>
                <th>Código Reserva</th>
                <th>Fecha</th>
                <th>Total $</th>
                <th>Modo de Pago</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row["id"]; ?></td>
                        <td><?php echo $row["codigo_reserva"] ? $row["codigo_reserva"] : 'Sin reserva'; ?></td>
                        <td><?php echo $row["fecha"]; ?></td>
                        <td><?php echo $row["total"]; ?></td>
                        <td><?php echo $row["modo_pago"]; ?></td>
                        <td>
                            <button class="btn btn-info btn-sm" onclick="verVenta(<?php echo $row['id']; ?>)">Ver</button>
                            <a href="imprimir_ticket.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">Imprimir Ticket</a>
                            <a href="eliminar_venta.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                        </td>
                    </tr>
                <?php }
            } else { ?>
                <tr><td colspan="6">No se encontraron ventas.</td></tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <nav>
        <ul class="pagination pagination-sm justify-content-center">
            <!-- Botón Inicio -->
            <li class="page-item <?php echo $pagina_actual == 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=1&buscar=<?php echo urlencode($buscar); ?>">Inicio</a>
            </li>
            <!-- Botón Anterior -->
            <li class="page-item <?php echo $pagina_actual == 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo $pagina_actual - 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Anterior</a>
            </li>
            <!-- Botón Siguiente -->
            <li class="page-item <?php echo $pagina_actual == $total_paginas ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo $pagina_actual + 1; ?>&buscar=<?php echo urlencode($buscar); ?>">Siguiente</a>
            </li>
            <!-- Botón Fin -->
            <li class="page-item <?php echo $pagina_actual == $total_paginas ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo $total_paginas; ?>&buscar=<?php echo urlencode($buscar); ?>">Fin</a>
            </li>
        </ul>
    </nav>
</div>

<!-- Modal para mostrar detalles de la venta -->
<div class="modal fade" id="ventaModal" tabindex="-1" aria-labelledby="ventaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ventaModalLabel">Detalles de la Venta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="ventaDetalle">
                <!-- Aquí se cargarán los detalles de la venta -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<script>
    function verVenta(idVenta) {
        $.ajax({
            url: 'ver_detalle_venta.php', // Archivo PHP que recupera los detalles de la venta
            type: 'POST',
            data: { id: idVenta },
            success: function(response) {
                $('#ventaDetalle').html(response); // Cargar los detalles en el modal
                $('#ventaModal').modal('show'); // Mostrar el modal
            },
            error: function() {
                alert('Error al cargar detalles de la venta.');
            }
        });
    }
</script>
<?php include_once "pie.php"; ?>
</body>
</html>
