<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Proveedor</h3>
    <h5>Complete los detalles para agregar un nuevo proveedor.</h5>
</div>
</div>';
include 'encabezado.php';
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form id="proveedor-form" action="guardar_proveedor.php" method="post">
                <div class="row">
                    <!-- Nombre del Proveedor -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input required type="text" class="form-control form-control-sm" name="nombre" id="nombre" placeholder="Ejemplo: Proveedor XYZ">
                    </div>
                    <!-- Nombre Fantasía -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre_fantasia" class="form-label" style="font-size: 0.9rem;">Nombre Fantasía</label>
                        <input type="text" class="form-control form-control-sm" name="nombre_fantasia" id="nombre_fantasia" placeholder="Ejemplo: Proveedor XYZ">
                    </div>
                </div>
                <div class="row">
                    <!-- Dirección -->
                    <div class="col-md-6 mb-3">
                        <label for="direccion" class="form-label" style="font-size: 0.9rem;">Dirección</label>
                        <input type="text" class="form-control form-control-sm" name="direccion" id="direccion" placeholder="Ejemplo: Calle Falsa 123">
                    </div>
                    <!-- Ciudad -->
                    <div class="col-md-6 mb-3">
                        <label for="ciudad" class="form-label" style="font-size: 0.9rem;">Ciudad</label>
                        <input type="text" class="form-control form-control-sm" name="ciudad" id="ciudad" placeholder="Ejemplo: Buenos Aires">
                    </div>
                </div>
                <div class="row">
                    <!-- Teléfono -->
                    <div class="col-md-4 mb-3">
                        <label for="telefono" class="form-label" style="font-size: 0.9rem;">Teléfono</label>
                        <input type="text" class="form-control form-control-sm" name="telefono" id="telefono" placeholder="Ejemplo: 01112345678">
                    </div>
                    <!-- Email -->
                    <div class="col-md-4 mb-3">
                        <label for="email" class="form-label" style="font-size: 0.9rem;">Email</label>
                        <input type="email" class="form-control form-control-sm" name="email" id="email" placeholder="Ejemplo: info@proveedor.com">
                    </div>
                    <!-- Número de Documento -->
                    <div class="col-md-4 mb-3">
                        <label for="nrodocumento" class="form-label" style="font-size: 0.9rem;">Nro de Documento</label>
                        <input type="text" class="form-control form-control-sm" name="nrodocumento" id="nrodocumento" placeholder="Ejemplo: 30-12345678-9">
                    </div>
                </div>
                <!-- Botón de Guardar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar Proveedor</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    // Aquí puedes agregar validaciones o comportamientos adicionales si lo necesitas.
});
</script>
<?php include 'footer.php'; ?>
