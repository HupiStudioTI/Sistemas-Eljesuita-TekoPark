<?php
include_once "conexion.php";

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$descuento = $_POST['descuento'];

$stmt = $conn->prepare("UPDATE bonificaciones SET nombre = ?, descuento = ? WHERE id = ?");
$stmt->bind_param("sdi", $nombre, $descuento, $id);

if ($stmt->execute()) {
    header("Location: bonificaciones.php");
} else {
    echo "Error: " . $stmt->error;
}
$stmt->close();
$conn->close();
?>
