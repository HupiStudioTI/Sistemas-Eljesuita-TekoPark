<?php
require 'fpdf.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha_hora_desde = $_POST['fecha_hora_desde'];
    $fecha_hora_hasta = $_POST['fecha_hora_hasta'];
    $resultados = json_decode($_POST['resultados'], true); // Decodificar el JSON recibido

    // Crear una instancia de FPDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Configurar la fuente
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Informe de Ventas', 0, 1, 'C');

    // Mostrar el rango de fechas
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, "Rango de Fechas: $fecha_hora_desde - $fecha_hora_hasta", 0, 1);

    // Añadir la tabla de resultados
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(40, 10, 'Dia', 1);
    $pdf->Cell(50, 10, 'Actividad', 1);
    $pdf->Cell(30, 10, 'Hora', 1);
    $pdf->Cell(30, 10, 'Clientes', 1);
    $pdf->Cell(40, 10, 'Ventas', 1);
    $pdf->Ln();

    $pdf->SetFont('Arial', '', 12);
    foreach ($resultados as $row) {
        $pdf->Cell(40, 10, $row['dia'], 1);
        $pdf->Cell(50, 10, $row['actividad'], 1);
        $pdf->Cell(30, 10, $row['hora'], 1);
        $pdf->Cell(30, 10, $row['total_clientes'], 1);
        $pdf->Cell(40, 10, "$" . number_format($row['total_ventas'], 2), 1);
        $pdf->Ln();
    }

    // Generar el archivo PDF
    $pdfFileName = 'informe_ventas.pdf';
    $pdf->Output('F', $pdfFileName);

    // Enviar la respuesta con la URL del PDF
    echo json_encode(['url' => $pdfFileName]);
}
?>
