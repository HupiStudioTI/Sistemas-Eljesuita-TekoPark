<?php
require_once "conexion.php";
require_once "funciones.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recoger datos de la cabecera de compra
    $proveedor_id = $_POST["proveedor_id"] ?? '';
    $nro_factura  = trim($_POST["nro_factura"] ?? '');
    $fecha_compra = $_POST["fecha_compra"] ?? '';
    
    // Recoger arrays de productos, cantidades y costos
    $productos_ids = $_POST["productos"] ?? [];
    $cantidades    = $_POST["cantidades"] ?? [];
    $costos        = $_POST["costos"] ?? [];
    
    // Verificar que los arrays tengan la misma cantidad de elementos
    if (count($productos_ids) !== count($cantidades) || count($productos_ids) !== count($costos)) {
         die("Error: los datos de los productos no son consistentes.");
    }
    
    // Combinar los datos en un array de productos
    $productosArray = [];
    for ($i = 0; $i < count($productos_ids); $i++) {
        // Omitir filas vacías (por ejemplo, si no se seleccionó un producto en alguna fila clonada)
        if (empty($productos_ids[$i])) {
            continue;
        }
        $productosArray[] = [
            "producto_id"    => $productos_ids[$i],
            "cantidad"       => $cantidades[$i],
            "costo_unitario" => $costos[$i]
        ];
    }
    
    // Validar que se hayan recibido los datos básicos
    if (empty($proveedor_id) || empty($nro_factura) || empty($fecha_compra) || empty($productosArray)) {
         die("Faltan datos requeridos.");
    }
    
    $pdo = obtenerBD();
    try {
        $pdo->beginTransaction();
        
        // Insertar la cabecera de la compra
        $stmt = $pdo->prepare("INSERT INTO compras (proveedor_id, nro_factura, fecha_compra) VALUES (?, ?, ?)");
        $stmt->execute([$proveedor_id, $nro_factura, $fecha_compra]);
        $compra_id = $pdo->lastInsertId();
        
        // Procesar cada producto de la compra
        foreach ($productosArray as $producto) {
            $producto_id    = $producto["producto_id"];
            $cantidad       = $producto["cantidad"];
            $costo_unitario = $producto["costo_unitario"];
            $subtotal       = $cantidad * $costo_unitario;
            
            // Insertar detalle en detalle_compras
            $stmt = $pdo->prepare("INSERT INTO detalle_compras (compra_id, producto_id, cantidad, costo_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$compra_id, $producto_id, $cantidad, $costo_unitario, $subtotal]);
            
            // Actualizar stock y actualizar costo en productos\n
            $stmt = $pdo->prepare("UPDATE productos SET stock = stock + ?, costo = ? WHERE id = ?");
            $stmt->execute([$cantidad, $costo_unitario, $producto_id]);
            
            // Registrar movimiento de stock con tipo COMPRA\n
            $stmt = $pdo->prepare("INSERT INTO movimientos_stock (producto_id, cantidad, tipo_movimiento, fecha) VALUES (?, ?, 'COMPRA', ?)");
            $stmt->execute([$producto_id, $cantidad, $fecha_compra]);
        }
        
        $pdo->commit();
        header("Location: compras.php?guardado=1");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Error al guardar la compra: " . $e->getMessage());
    }
} else {
    die("Acceso no permitido.");
}
?>
