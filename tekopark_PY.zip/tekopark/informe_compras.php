<?php
require_once 'conexion.php';
require_once 'funciones.php';
require_once 'tcpdf/tcpdf.php';

$errores = [];
$agrupado = [];

// Procesar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $desde = $_POST['desde'] ?? '';
    $hasta = $_POST['hasta'] ?? '';
    $proveedor_id = $_POST['proveedor_id'] ?? 'todos';
    $producto_id = $_POST['producto_id'] ?? 'todos';

    if (empty($desde) || empty($hasta)) {
        $errores[] = "Debe completar el rango de fechas.";
    }

    if (empty($errores)) {
        $sql = "SELECT c.id, c.fecha_compra, p.nombre AS producto, pr.nombre AS proveedor, dc.cantidad, dc.costo_unitario,
                       pr.id AS proveedor_id, p.id AS producto_id
                FROM compras c
                JOIN detalle_compras dc ON c.id = dc.compra_id
                JOIN productos p ON dc.producto_id = p.id
                JOIN proveedores pr ON c.proveedor_id = pr.id
                WHERE c.fecha_compra BETWEEN ? AND ?";

        $parametros = [$desde, $hasta];

        if ($proveedor_id !== 'todos') {
            $sql .= " AND pr.id = ?";
            $parametros[] = $proveedor_id;
        }

        if ($producto_id !== 'todos') {
            $sql .= " AND p.id = ?";
            $parametros[] = $producto_id;
        }

        $sql .= " ORDER BY c.fecha_compra, pr.nombre, p.nombre";

        // Se asume que $conn es la conexión (usando mysqli)
        $stmt = $conn->prepare($sql);
        $tipos = str_repeat('s', count($parametros));
        $stmt->bind_param($tipos, ...$parametros);
        $stmt->execute();
        $resultado = $stmt->get_result();

        // Reorganizar los datos en una estructura anidada: Fecha -> Proveedor -> Producto
        while ($fila = $resultado->fetch_assoc()) {
            $fecha = $fila['fecha_compra'];
            $proveedor = $fila['proveedor'];
            $producto = $fila['producto'];
            $agrupado[$fecha][$proveedor][$producto][] = $fila;
        }

        // GENERAR PDF con TCPDF
        $pdf = new TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('dejavusans', '', 10);

        $pdf->Write(0, 'Informe de Compras', '', 0, 'C', true, 0, false, false, 0);
        $pdf->Ln(5);

        // Recorrer la estructura anidada y escribir el contenido
        foreach ($agrupado as $fecha => $proveedores) {
            $pdf->SetFont('', 'B');
            $pdf->Write(0, 'Fecha: ' . $fecha, '', 0, 'L', true, 0, false, false, 0);
            foreach ($proveedores as $proveedor => $productos) {
                $pdf->SetFont('', 'B');
                $pdf->Write(0, 'Proveedor: ' . $proveedor, '', 0, 'L', true, 0, false, false, 0);
                foreach ($productos as $producto => $compras) {
                    $pdf->SetFont('', 'B');
                    $pdf->Write(0, 'Producto: ' . $producto, '', 0, 'L', true, 0, false, false, 0);
                    $totalProducto = 0;
                    // Encabezado simple para el detalle
                    $pdf->SetFont('', '');
                    $pdf->Write(0, 'Detalle:', '', 0, 'L', true, 0, false, false, 0);
                    foreach ($compras as $compra) {
                        $total = $compra['cantidad'] * $compra['costo_unitario'];
                        $totalProducto += $total;
                        $linea = '  - Fecha: ' . $compra['fecha_compra'] .
                                  ' | Cantidad: ' . number_format($compra['cantidad'], 2, ',', '.') .
                                  ' | Costo Unitario: $' . number_format($compra['costo_unitario'], 2, ',', '.') .
                                  ' | Total: $' . number_format($total, 2, ',', '.');
                        $pdf->Write(0, $linea, '', 0, 'L', true, 0, false, false, 0);
                    }
                    $pdf->SetFont('', 'B');
                    $pdf->Write(0, 'Subtotal ' . $producto . ': $' . number_format($totalProducto, 2, ',', '.'), '', 0, 'L', true, 0, false, false, 0);
                    $pdf->Ln(3);
                }
                $pdf->Ln(5);
            }
            $pdf->Ln(8);
        }

        ob_end_clean();
        $pdf->Output('informe_compras.pdf', 'I');
        exit;
    }
}

// FORMULARIO
$proveedores = obtenerProveedores();
$productos = obtenerProductos();
?>
<?php include 'encabezado.php'; ?>
<div class="container mt-5">
    <h4 class="mb-4" style="color: #ff5722;">Informe de Compras</h4>

    <?php if (!empty($errores)) {
        echo '<div class="alert alert-danger">' . implode('<br>', $errores) . '</div>';
    } ?>

    <form method="POST" class="row g-3">
        <div class="col-md-3">
            <label for="desde" class="form-label">Desde</label>
            <input type="date" name="desde" id="desde" class="form-control form-control-sm" required>
        </div>

        <div class="col-md-3">
            <label for="hasta" class="form-label">Hasta</label>
            <input type="date" name="hasta" id="hasta" class="form-control form-control-sm" required>
        </div>

        <div class="col-md-3">
            <label for="proveedor_id" class="form-label">Proveedor</label>
            <select name="proveedor_id" id="proveedor_id" class="form-select form-select-sm">
                <option value="todos">Todos</option>
                <?php foreach ($proveedores as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= $p['nombre'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <label for="producto_id" class="form-label">Producto</label>
            <select name="producto_id" id="producto_id" class="form-select form-select-sm">
                <option value="todos">Todos</option>
                <?php foreach ($productos as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= $p['nombre'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 text-end">
            <button type="submit" class="btn btn-primary btn-sm">Generar PDF</button>
        </div>
    </form>
</div>

<?php include 'footer.php'; ?>
