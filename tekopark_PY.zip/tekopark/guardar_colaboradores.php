<?php
include_once "conexion.php";
    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];
    $empresa = $_POST["empresa"];
    $direccion = $_POST["direccion"];
    $comision = $_POST["comision"];
    $stmt = $conn->prepare("INSERT INTO colaboradores (nombre, telefono, email, empresa, direccion, comision) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssd", $nombre, $telefono, $email, $empresa, $direccion, $comision);
        if ($stmt->execute()) {
        header("Location: colaboradores.php");
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
?>