<?php
session_start();

// Verificamos si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Obtenemos el rol del usuario
$rol = $_SESSION['usuario']['rol'];
$contenido = '
<div class="row mx-0">
    <div class="col-12 text-center mb-2">
        <h3 style="color: #ff5722;">Sistema de Gestión</h3>
        <h5>Elija una opción del menú para comenzar</h5>
    </div>
</div>
<div class="row mx-0">
    <!-- Carrusel Principal -->
    <div class="col-12 mb-4 px-0">
        <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/teko1.jpg" class="d-block w-100" alt="TekoPark 1">
                </div>
                <div class="carousel-item">
                    <img src="img/teko2.jpg" class="d-block w-100" alt="TekoPark 2">
                </div>
                <div class="carousel-item">
                    <img src="img/teko3.jpg" class="d-block w-100" alt="TekoPark 3">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Anterior</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Siguiente</span>
            </button>
        </div>
    </div>
</div>
<div class="row mx-0">
    <!-- Galería Inferior -->
    <div class="col-12 px-0">
        <div class="d-flex thumbnail-slider mt-4">
            <img src="img/destacados_bowling.jpg" alt="Bowling">
            <img src="img/destacados_comunidad.jpg" alt="Comunidad">
            <img src="img/destacados_futbol.jpg" alt="Fútbol">
            <img src="img/destacados_games.jpg" alt="Games">
            <img src="img/destacados_jump.jpg" alt="Jump">
            <img src="img/destacados_kids.jpg" alt="Kids">
            <img src="img/destacados_snack bar.jpg" alt="Snack Bar">
        </div>
    </div>
</div>';
include_once "encabezado.php";
include_once "footer.php";
?>
