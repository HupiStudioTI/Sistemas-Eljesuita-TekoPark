<?php
include_once "conexion.php";

// Obtener el ID de la venta
$venta_id = $_POST['id'];

// Obtener la página actual de productos y clientes
$pagina_productos = isset($_POST['pagina_productos']) ? (int)$_POST['pagina_productos'] : 1;
$pagina_clientes = isset($_POST['pagina_clientes']) ? (int)$_POST['pagina_clientes'] : 1;
$items_por_pagina = 10;  // Cambiar esto para ajustar el número de elementos por página
$inicio_productos = ($pagina_productos - 1) * $items_por_pagina;
$inicio_clientes = ($pagina_clientes - 1) * $items_por_pagina;

// Obtener los detalles de la venta
$query_venta = $conn->prepare("SELECT v.*, c.nombre as colaborador, c.comision as comision_colaborador, b.nombre as bonificacion, b.descuento
                                FROM ventas v
                                LEFT JOIN colaboradores c ON v.colaborador_id = c.id
                                LEFT JOIN bonificaciones b ON v.bonificacion_id = b.id
                                WHERE v.id = ?");
$query_venta->bind_param("i", $venta_id);
$query_venta->execute();
$result_venta = $query_venta->get_result();
$venta = $result_venta->fetch_assoc();

// Estilo del total resaltado
$estilo_total = "font-size: 1.5rem; font-weight: bold; color: #ff5722;";

// Mostrar datos generales de la venta
echo "<h5>Detalles de la Venta</h5>";
echo "<p><strong>ID Venta:</strong> {$venta['id']} <span style='margin-left: 20px;'><strong>Fecha:</strong> {$venta['fecha']}</span></p>";
echo "<p><strong>Bonificación:</strong> {$venta['bonificacion']} ({$venta['descuento']}%)</p>";
echo "<p><strong>Colaborador:</strong> {$venta['colaborador']} (Comisión: {$venta['comision_colaborador']}%) <span style='margin-left: 20px;'><strong>Color:</strong> <span style='color: {$venta['color']};'>{$venta['color']}</span></span></p>";
echo "<p style='$estilo_total'><strong>Total:</strong> {$venta['total']} <span style='margin-left: 20px;'><strong>Forma de Pago:</strong> {$venta['modo_pago']}</span></p>";

// Paginación de clientes
$query_clientes = $conn->prepare("SELECT c.nombre, cr.identificacion 
                                  FROM clientes_reserva cr 
                                  LEFT JOIN clientes c ON cr.cliente_id = c.id 
                                  WHERE cr.reserva_id = (SELECT reserva_id FROM ventas WHERE id = ?)
                                  LIMIT ?, ?");
$query_clientes->bind_param("iii", $venta_id, $inicio_clientes, $items_por_pagina);
$query_clientes->execute();
$result_clientes = $query_clientes->get_result();

// Total de clientes para la paginación
$query_total_clientes = $conn->prepare("SELECT COUNT(*) as total_clientes FROM clientes_reserva WHERE reserva_id = (SELECT reserva_id FROM ventas WHERE id = ?)");
$query_total_clientes->bind_param("i", $venta_id);
$query_total_clientes->execute();
$result_total_clientes = $query_total_clientes->get_result();
$total_clientes = $result_total_clientes->fetch_assoc()['total_clientes'];
$total_paginas_clientes = ceil($total_clientes / $items_por_pagina);

// Paginación de productos
$query_productos = $conn->prepare("SELECT p.nombre, dv.cantidad, dv.precio_unitario, dv.total
                                   FROM detalle_ventas dv
                                   LEFT JOIN productos p ON dv.producto_id = p.id
                                   WHERE dv.venta_id = ?
                                   LIMIT ?, ?");
$query_productos->bind_param("iii", $venta_id, $inicio_productos, $items_por_pagina);
$query_productos->execute();
$result_productos = $query_productos->get_result();

// Total de productos para la paginación
$query_total_productos = $conn->prepare("SELECT COUNT(*) as total_productos FROM detalle_ventas WHERE venta_id = ?");
$query_total_productos->bind_param("i", $venta_id);
$query_total_productos->execute();
$result_total_productos = $query_total_productos->get_result();
$total_productos = $result_total_productos->fetch_assoc()['total_productos'];
$total_paginas_productos = ceil($total_productos / $items_por_pagina);

// Mostrar grid de clientes con paginación (primero)
echo "<div class='card mb-3'>";
echo "<div class='card-header'><h5>Clientes</h5></div>";
if ($result_clientes->num_rows > 0) {
    echo "<div class='table-responsive'>";
    echo "<table class='table table-striped'>";
    echo "<thead><tr><th>Nombre</th><th>Identificación</th></tr></thead><tbody>";
    while ($cliente = $result_clientes->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$cliente['nombre']}</td>";
        echo "<td>{$cliente['identificacion']}</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
    echo "</div>";
} else {
    echo "<p>No se encontraron clientes asociados a esta venta.</p>";
}
echo "<nav><ul class='pagination'>";
for ($i = 1; $i <= $total_paginas_clientes; $i++) {
    echo "<li class='page-item " . ($i == $pagina_clientes ? 'active' : '') . "'>";
    echo "<a class='page-link' href='#' onclick='cargarClientes({$venta_id}, {$i});'>{$i}</a>";
    echo "</li>";
}
echo "</ul></nav>";
echo "</div>";

// Mostrar grid de productos con paginación (después de los clientes)
echo "<div class='card mb-3'>";
echo "<div class='card-header'><h5>Productos</h5></div>";
if ($result_productos->num_rows > 0) {
    echo "<div class='table-responsive'>";
    echo "<table class='table table-striped'>";
    echo "<thead><tr><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th>Total</th></tr></thead><tbody>";
    while ($producto = $result_productos->fetch_assoc()) {
        $nombre_producto = $producto['nombre'] ?? 'Producto no encontrado'; // Evitar productos nulos
        echo "<tr>";
        echo "<td>{$nombre_producto}</td>";
        echo "<td>{$producto['cantidad']}</td>";
        echo "<td>{$producto['precio_unitario']}</td>";
        echo "<td>{$producto['total']}</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
    echo "</div>";
} else {
    echo "<p>No se encontraron productos en esta venta.</p>";
}
echo "<nav><ul class='pagination'>";
for ($i = 1; $i <= $total_paginas_productos; $i++) {
    echo "<li class='page-item " . ($i == $pagina_productos ? 'active' : '') . "'>";
    echo "<a class='page-link' href='#' onclick='cargarProductos({$venta_id}, {$i});'>{$i}</a>";
    echo "</li>";
}
echo "</ul></nav>";
echo "</div>";

// Scripts para cargar productos y clientes con paginación
echo "<script>
    function cargarProductos(venta_id, pagina_productos) {
        $.ajax({
            url: 'ver_detalle_venta.php',
            type: 'POST',
            data: { id: venta_id, pagina_productos: pagina_productos },
            success: function(response) {
                $('#ventaDetalle').html(response);
            }
        });
    }

    function cargarClientes(venta_id, pagina_clientes) {
        $.ajax({
            url: 'ver_detalle_venta.php',
            type: 'POST',
            data: { id: venta_id, pagina_clientes: pagina_clientes },
            success: function(response) {
                $('#ventaDetalle').html(response);
            }
        });
    }
</script>";
?>
