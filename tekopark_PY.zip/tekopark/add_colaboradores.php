<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Colaborador</h3>
    <h5>Complete el formulario para registrar un nuevo colaborador.</h5>
</div>
</div>';
include 'encabezado.php';
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="guardar_colaboradores.php" method="post">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input required type="text" class="form-control form-control-sm" name="nombre" id="nombre" placeholder="Nombre">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="telefono" class="form-label" style="font-size: 0.9rem;">Teléfono</label>
                        <input required type="text" class="form-control form-control-sm" name="telefono" id="telefono" placeholder="Teléfono">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="email" class="form-label" style="font-size: 0.9rem;">Email</label>
                        <input required type="email" class="form-control form-control-sm" name="email" id="email" placeholder="Correo electrónico">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="empresa" class="form-label" style="font-size: 0.9rem;">Empresa</label>
                        <input required type="text" class="form-control form-control-sm" name="empresa" id="empresa" placeholder="Empresa">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="direccion" class="form-label" style="font-size: 0.9rem;">Dirección</label>
                        <input required type="text" class="form-control form-control-sm" name="direccion" id="direccion" placeholder="Dirección">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="comision" class="form-label" style="font-size: 0.9rem;">Comisión (%)</label>
                        <input required type="number" step="0.01" class="form-control form-control-sm" name="comision" id="comision" placeholder="Porcentaje de comisión">
                    </div>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
