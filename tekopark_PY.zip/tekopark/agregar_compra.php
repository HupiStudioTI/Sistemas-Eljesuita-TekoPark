<?php
$contenido = '<div class="row mx-0 text-center">
    <div class="col-12 mb-4">
        <h3 style="color: #ff5722;">Registrar Nueva Compra</h3>
        <h5>Complete los datos de la factura y los productos comprados.</h5>
    </div>
</div>';
include 'encabezado.php';
include_once 'conexion.php';
include_once 'funciones.php';

$mensaje = "";
// Obtener lista de proveedores y productos
$proveedores = obtenerProveedores();
$productos = obtenerProductos(); // Cada producto debe tener la propiedad "unidad_medida"
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Compra</title>
    <!-- Carga de librerías locales -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        /* Estilo adicional (opcional) */
        .d-none { display: none; }
    </style>
</head>
<body>
<div class="container mt-5">
    <?php if (!empty($mensaje)) echo $mensaje; ?>

    <a href="compras.php" class="btn btn-secondary mb-3">Volver a Compras</a>

    <form action="guardar_compra.php" method="POST" id="formCompra">
        <!-- Datos generales de la compra -->
        <div class="row mb-3">
            <div class="col-md-4">
                <label for="proveedor_id" class="form-label">Proveedor</label>
                <select name="proveedor_id" id="proveedor_id" class="form-select form-select-sm" required>
                    <option value="">Seleccione</option>
                    <?php foreach ($proveedores as $prov): ?>
                        <option value="<?= $prov['id'] ?>"><?= $prov['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="fecha_compra" class="form-label">Fecha de Compra</label>
                <input type="date" name="fecha_compra" id="fecha_compra" class="form-control form-control-sm" required value="<?= date('Y-m-d') ?>">
            </div>
            <div class="col-md-4">
                <label for="nro_factura" class="form-label">Nro. de Factura</label>
                <input type="text" name="nro_factura" id="nro_factura" class="form-control form-control-sm" required>
            </div>
        </div>

        <hr>

        <!-- Sección para seleccionar y agregar productos -->
        <h5 class="mb-3">Agregar Producto</h5>
        <div class="row g-2 align-items-end">
            <div class="col-md-6">
                <label for="selectProducto" class="form-label">Producto</label>
                <select id="selectProducto" class="form-select form-select-sm">
                    <option value="">Seleccione un producto</option>
                    <?php foreach ($productos as $prod): ?>
                        <!-- Se utiliza data-unidad para almacenar la unidad de medida -->
                        <option value="<?= $prod['id'] ?>" data-unidad="<?= $prod['unidad_medida'] ?>">
                            <?= $prod['nombre'] ?> (<?= $prod['unidad_medida'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="cantidadProducto" class="form-label">Cantidad</label>
                <input type="number" id="cantidadProducto" class="form-control form-control-sm" step="0.001">
            </div>
            <div class="col-md-2">
                <label for="costoProducto" class="form-label">Costo Unitario</label>
                <input type="number" id="costoProducto" class="form-control form-control-sm">
            </div>
            <div class="col-md-2">
                <button type="button" id="btnAgregarProducto" class="btn btn-primary btn-sm">Agregar</button>
            </div>
        </div>

        <hr>

        <!-- Tabla dinámica con los productos agregados -->
        <h5 class="mb-3">Productos Agregados</h5>
        <div class="table-responsive">
            <table id="dtProductos" class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>Producto</th>
                        <th>Unidad</th>
                        <th>Cantidad</th>
                        <th>Costo Unitario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Se agregarán las filas dinámicamente -->
                </tbody>
            </table>
        </div>

        <div class="text-center mt-3">
            <button type="submit" class="btn btn-success btn-sm">Guardar Compra</button>
        </div>
    </form>
</div>

<script>
$(document).ready(function(){
    // Al cambiar la selección del producto, se consulta el costo mediante AJAX
    $('#selectProducto').on('change', function(){
        var prodId = $(this).val();
        if(prodId){
            fetch('obtener_detalle_producto.php?id=' + prodId)
            .then(response => response.json())
            .then(data => {
                console.log('Detalles del producto:', data);
                if(data && data.costo){
                    $('#costoProducto').val(data.costo);
                } else {
                    $('#costoProducto').val('');
                }
            })
            .catch(error => {
                console.error('Error al obtener detalles:', error);
                $('#costoProducto').val('');
            });
        } else {
            $('#costoProducto').val('');
        }
    });

    // Agregar producto a la tabla dinámica
    $('#btnAgregarProducto').on('click', function(){
        var prodId = $('#selectProducto').val();
        if(!prodId){
            alert('Seleccione un producto.');
            return;
        }
        var prodText = $('#selectProducto option:selected').text();
        var unidad = $('#selectProducto option:selected').data('unidad');
        var cantidad = $('#cantidadProducto').val();
        var costo = $('#costoProducto').val();
        if(!cantidad || !costo){
            alert('Complete cantidad y costo unitario.');
            return;
        }
        // Crear la fila con inputs ocultos para enviar la información en el formulario
        var row = '<tr data-prod-id="'+prodId+'">'+
                    '<td>'+prodText+'</td>'+
                    '<td>'+unidad+'</td>'+
                    '<td>'+cantidad+'</td>'+
                    '<td>'+costo+'</td>'+
                    '<td>'+
                        '<button type="button" class="btn btn-danger btn-sm btn-delete-product">Eliminar</button>'+
                        '<div class="d-none">'+
                            '<input type="hidden" name="productos[]" value="'+prodId+'">'+
                            '<input type="hidden" name="cantidades[]" value="'+cantidad+'">'+
                            '<input type="hidden" name="costos[]" value="'+costo+'">'+
                        '</div>'+
                    '</td>'+
                  '</tr>';
        $('#dtProductos tbody').append(row);
        // Limpiar los campos para agregar otro producto
        $('#selectProducto').val('');
        $('#cantidadProducto').val('');
        $('#costoProducto').val('');
    });

    // Eliminar fila de producto
    $('#dtProductos').on('click', '.btn-delete-product', function(){
        $(this).closest('tr').remove();
    });
});
</script>
</body>
</html>
<?php include_once "footer.php"; ?>
