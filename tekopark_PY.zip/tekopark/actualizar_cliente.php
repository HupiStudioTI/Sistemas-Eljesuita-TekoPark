<?php
include_once "funciones.php";
$ok = actualizarCliente($_POST["nombre"], $_POST["documento"], $_POST["fechanac"], $_POST["edad"], $_POST["sexo"], $_POST["ciudad"], $_POST["departamento"], $_POST["tel"], $_POST["email"], $_POST["padre"], $_POST["docpadre"], $_POST["telpadre"], $_POST["obs"], $_POST["id"]);
if (!$ok) {
    echo "Error actualizando.";
} else {
    header("Location: clientes.php");
}
