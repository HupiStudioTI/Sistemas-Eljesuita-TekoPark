document.addEventListener('DOMContentLoaded', function () {
    const fechanacInput = document.getElementById('fechanac');
    const edadSpan = document.getElementById('edad');
    const hiddenEdadInput = document.getElementById('hiddenEdad');

    fechanacInput.addEventListener('change', function () {
        const fechanacValue = fechanacInput.value;
        if (fechanacValue) {
            const fechanac = new Date(fechanacValue);
            const today = new Date();
            let edad = today.getFullYear() - fechanac.getFullYear();
            const monthDifference = today.getMonth() - fechanac.getMonth();

            // Ajustar la edad si el cumpleaños no ha pasado este año
            if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < fechanac.getDate())) {
                edad--;
            }

            edadSpan.textContent = edad;
            hiddenEdadInput.value = edad;  // Actualiza el campo oculto
        } else {
            edadSpan.textContent = '0';
            hiddenEdadInput.value = '0';  // Actualiza el campo oculto
        }
    });
});
