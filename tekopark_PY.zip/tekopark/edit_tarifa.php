<?php
include_once 'funciones.php';
if (!isset($_GET['id'])) { die('ID de tarifa no proporcionado.'); }

$id   = (int)$_GET['id'];
$conn = obtenerBD();
$stmt = $conn->prepare("SELECT * FROM tarifas WHERE id = :id");
$stmt->execute([':id'=>$id]);
$tarifa = $stmt->fetch(PDO::FETCH_ASSOC) ?: die('Tarifa no encontrada.');

$dias = ['lun'=>'Lunes','mar'=>'Martes','mie'=>'Miércoles','jue'=>'Jueves','vie'=>'Viernes','sab'=>'Sábado','dom'=>'Domingo'];
$seleccionados = explode(',', $tarifa['dias']);   // array
?>
<!DOCTYPE html><html lang="es"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tarifa</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head><body>
<?php
$contenido = '<div class="row mx-0 text-center"><div class="col-12 mb-4"><h3 style="color:#ff5722;">Editar Tarifa</h3></div></div>';
include_once "encabezado.php";
?>
<div class="container mt-5">
<form action="actualizar_tarifa.php" method="POST">
    <input type="hidden" name="id" value="<?= $tarifa['id']; ?>">
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="actividad" class="form-label fw-bold">Actividad</label>
            <input type="text" name="actividad" id="actividad" class="form-control form-control-sm"
                   value="<?= htmlspecialchars($tarifa['actividad']); ?>" required>
        </div>
        <div class="col-md-6 mb-3">
            <label for="nombretarifa" class="form-label fw-bold">Nombre de la Tarifa</label>
            <input type="text" name="nombretarifa" id="nombretarifa" class="form-control form-control-sm"
                   value="<?= htmlspecialchars($tarifa['nombretarifa']); ?>" required>
        </div>
    </div>

    <!-- DÍAS -->
    <div class="row">
        <div class="col-md-12 mb-3">
            <label class="form-label fw-bold d-block">Días activos</label>
            <?php foreach ($dias as $code=>$nombre): ?>
                <label class="me-2">
                    <input type="checkbox" name="dias[]" value="<?= $code ?>"
                           <?= in_array($code,$seleccionados)?'checked':''; ?>> <?= $nombre ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="duracion" class="form-label fw-bold">Duración</label>
            <select name="duracion" id="duracion" class="form-select form-select-sm" required>
                <?php foreach ([30=>'30 Minutos',60=>'1 Hora',90=>'1 Hora y Media',120=>'2 Horas'] as $val=>$txt): ?>
                    <option value="<?= $val ?>" <?= $tarifa['duracion']==$val?'selected':''; ?>><?= $txt ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label for="precio" class="form-label fw-bold">Precio</label>
            <input type="number" step="1" name="precio" id="precio"
                   class="form-control form-control-sm" value="<?= $tarifa['precio']; ?>" required>
        </div>
    </div>

    <div class="text-center">
        <button type="submit" class="btn btn-success btn-sm">Guardar Tarifa</button>
    </div>
</form>
</div>
<?php include_once "footer.php"; ?>
<script src="./js/bootstrap.bundle.min.js"></script>
</body></html>
