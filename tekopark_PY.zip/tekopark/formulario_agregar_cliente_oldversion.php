<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cliente</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</head>
<?php
include_once "encabezado.php";
include_once "funciones.php";
$departamentos = obtenerDepartamentos();
?>
<div class="row">
    <div class="col-12">
        <h1>Agregar cliente</h1>
        <form id="cliente-form" action="guardar_cliente.php" method="post">
        <!--<form action="guardar_cliente.php" method="post">-->
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input required type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre">
            </div>
            <div class="form-group">
                <label for="documento">Nº Documento</label>
                <input required type="text" class="form-control" name="documento" id="documento" placeholder="Numero de Documento">
            </div>
            <div class="form-group">
                <label for="fechanac">Fecha de Nacimiento</label>
                <input required type="date" class="form-control" name="fechanac" id="fechanac">
            </div>
            <script src="js/calcula_edad.js"></script>
            <div class="form-group">
                <label for="edad">Edad</label>
                <label for="edad">Edad:</label>
                <span name="edad" id="edad">0</span>
                <input type="hidden" name="edad" id="hiddenEdad" value="0">
            </div>
            <div class="form-group">
               <label for="sexo">Sexo/Género:</label>
               <select name="sexo" id="sexo" class="form-control">
                    <option value="mujer">Mujer</option>
                    <option value="hombre">Hombre</option>
                    <option value="no-binario">No binario</option>
                    <option value="transgenero">Transgénero</option>
                    <option value="intersex">Intersex</option>
                    <option value="prefiero-no-decir">Prefiero no decir</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            <div class="form-group">
                <label for="departamento">Actividad</label>
                <select class="form-control" name="departamento" id="departamento">
                    <?php foreach ($departamentos as $departamento) { ?>
                        <option value="<?php echo $departamento ?>"><?php echo $departamento ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label for="ciudad">Ciudad</label>
                <input required type="text" class="form-control" name="ciudad" id="ciudad" placeholder="Ciudad">
            </div>
            <div class="form-group">
                <label for="tel">Tel. / Whatsapp</label>
                <input required type="text" class="form-control" name="tel" id="tel" placeholder="nº de tel, Whatsapp">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" id="email" placeholder="correo electrónico">
            </div>
            <div class="form-group">
                <label for="padre">Padre o Tutor</label>
                <input  type="text" class="form-control" name="padre" id="padre" placeholder="Nombre del Padre o Tutor">
            </div>
            <div class="form-group">
                <label for="docpadre">Nº Documento Padre/Tutor</label>
                <input  type="text" class="form-control" name="docpadre" id="docpadre" placeholder="Doc. del Padre o Tutor">
            </div>
            <div class="form-group">
                <label for="telpadre">Tel. / Whatsapp Padre o Tutor</label>
                <input  type="text" class="form-control" name="telpadre" id="telpadre" placeholder="nº de tel, Whatsapp padre o tutor">
            </div>
            <div class="form-group">
                <label for="obs">Observaciones</label>
                <input type="text" class="form-control" name="obs" id="obs" placeholder="cualquier observacion que desee ingresar">
            </div>
            <div class="form-group">
                <button class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php include_once "pie.php" ?>


        <!-- Modal para mostrar errores -->
        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">Verificación</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        El número de documento o email ya existe.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        $(document).ready(function() {
            function verificarExistencia() {
                var documento = $('#documento').val();
                var email = $('#email').val();

                $.ajax({
                    url: 'verificar.php',
                    type: 'POST',
                    data: { documento: documento, email: email },
                    dataType: 'json',
                    success: function(response) {
                        if (response.exists) {
                            $('#errorModal').modal('show');
                            $('#cliente-form').find('button[type="submit"]').prop('disabled', true);
                        } else {
                            $('#cliente-form').find('button[type="submit"]').prop('disabled', false);
                        }
                    }
                });
            }
            $('#documento, #email').on('input', function() {
                verificarExistencia();
            });
        });
    </script>
