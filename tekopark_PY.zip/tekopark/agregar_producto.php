<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Producto</h3>
    <h5>Complete los detalles para agregar un nuevo producto al sistema.</h5>
</div>
</div>';
include_once "encabezado.php";
include_once "funciones.php";

$mensaje = "";

// Manejar la lógica de agregar producto
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre        = $_POST["nombre"]        ?? "";
    $precio        = $_POST["precio"]        ?? 0;
    $costo         = $_POST["costo"]         ?? 0;
    $unidad_medida = $_POST["unidad_medida"] ?? "UN";
    $stock         = $_POST["stock"]         ?? 0;

    try {
        $pdo = obtenerBD();
        $sql = "INSERT INTO productos (nombre, precio, costo, stock, unidad_medida)
                VALUES (:nombre, :precio, :costo, :stock, :unidad_medida)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nombre',        $nombre);
        $stmt->bindParam(':precio',        $precio);
        $stmt->bindParam(':costo',         $costo);
        $stmt->bindParam(':stock',         $stock);
        $stmt->bindParam(':unidad_medida', $unidad_medida);

        if ($stmt->execute()) {
            $mensaje = "<div class='alert alert-success'>Producto agregado con éxito.</div>";
            // Limpiar los campos para que el formulario aparezca vacío
            $_POST["nombre"]        = "";
            $_POST["precio"]        = "";
            $_POST["costo"]         = "";
            $_POST["stock"]         = "";
            $_POST["unidad_medida"] = "UN"; 
        } else {
            $mensaje = "<div class='alert alert-danger'>Error al agregar el producto.</div>";
        }
    } catch (PDOException $e) {
        $mensaje = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<div class="container mt-5">
    <?php if (!empty($mensaje)) echo $mensaje; ?>

    <a href="productos.php" class="btn btn-secondary mb-3">Volver a Productos</a>

    <form action="agregar_producto.php" method="POST" id="form-agregar-producto">
        <!-- Nombre del producto -->
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre del Producto</label>
            <input 
                type="text" 
                name="nombre" 
                class="form-control form-control-sm" 
                id="nombre" 
                value="<?php echo htmlspecialchars($_POST['nombre'] ?? '', ENT_QUOTES); ?>" 
                required
            >
        </div>

        <!-- Unidad de Medida -->
        <div class="mb-3">
            <label for="unidad_medida" class="form-label">Unidad de Medida</label>
            <select 
                name="unidad_medida" 
                id="unidad_medida" 
                class="form-select form-select-sm"
            >
                <option value="UN" <?php echo (($_POST['unidad_medida'] ?? '') === 'UN') ? 'selected' : ''; ?>>
                    UN (Unidad)
                </option>
                <option value="KG" <?php echo (($_POST['unidad_medida'] ?? '') === 'KG') ? 'selected' : ''; ?>>
                    KG (Kilogramo)
                </option>
                <option value="LT" <?php echo (($_POST['unidad_medida'] ?? '') === 'LT') ? 'selected' : ''; ?>>
                    LT (Litro)
                </option>
                <option value="PZ" <?php echo (($_POST['unidad_medida'] ?? '') === 'PZ') ? 'selected' : ''; ?>>
                    PZ (Pieza)
                </option>
            </select>
        </div>

        <!-- Stock -->
        <div class="mb-3">
            <label for="stock" class="form-label">Stock Inicial</label>
            <input 
                type="number" 
                name="stock" 
                class="form-control form-control-sm" 
                id="stock"
                step="1"
                value="<?php echo htmlspecialchars($_POST['stock'] ?? '', ENT_QUOTES); ?>"
                required
            >
        </div>

        <!-- Costo -->
        <div class="mb-3">
            <label for="costo" class="form-label">Costo</label>
            <input 
                type="number" 
                name="costo" 
                class="form-control form-control-sm" 
                id="costo" 
                step="0.01"
                value="<?php echo htmlspecialchars($_POST['costo'] ?? '', ENT_QUOTES); ?>" 
            >
        </div>

        <!-- Precio -->
        <div class="mb-3">
            <label for="precio" class="form-label">Precio</label>
            <input 
                type="number" 
                name="precio" 
                class="form-control form-control-sm" 
                id="precio" 
                step="0.01"
                value="<?php echo htmlspecialchars($_POST['precio'] ?? '', ENT_QUOTES); ?>" 
                required
            >
        </div>

        <button type="submit" class="btn btn-success btn-sm">Agregar Producto</button>
    </form>
</div>

<script>
    // Cuando cambia la unidad, ajustamos el step del campo stock
    const unidadSelect = document.getElementById('unidad_medida');
    const stockInput   = document.getElementById('stock');

    function ajustarStep() {
        if (unidadSelect.value === 'KG' || unidadSelect.value === 'LT') {
            stockInput.step = '0.001';
        } else {
            stockInput.step = '1';
        }
    }

    // Al cargar la página, ajustamos el step inicial
    window.addEventListener('DOMContentLoaded', ajustarStep);

    // Cada vez que el usuario cambie la unidad, actualizamos step
    unidadSelect.addEventListener('change', ajustarStep);
</script>

<?php include_once "footer.php"; ?>
