<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Clientes</h3>
    <h5>Administre aquí la información de los clientes.</h5>
</div>
</div>';
include 'encabezado.php';
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="formulario_agregar_cliente.php" class="btn btn-success btn-sm">Agregar</a>
                <form id="buscador-form" class="d-flex">
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por nombre o DNI">
                </form>
            </div>

            <!-- Tabla de clientes -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Documento</th>
                            <th>Teléfono</th>
                            <th>Dashboard</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-clientes">
                        <!-- Los resultados dinámicos se cargarán aquí -->
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center" id="paginacion">
                    <!-- Los botones de navegación dinámicos se cargarán aquí -->
                </ul>
            </nav>
        </div>
    </div>
</div>
    <script>
    function cargarClientes(query = '', pagina = 1) {
        fetch(`buscar_clientes.php?query=${encodeURIComponent(query)}&pagina=${pagina}`)
            .then(response => response.json())
            .then(data => {
                let tablaClientes = document.getElementById('tabla-clientes');
                let paginacion = document.getElementById('paginacion');
                tablaClientes.innerHTML = ""; // Limpiar resultados previos
                paginacion.innerHTML = ""; // Limpiar navegación previa

                // Mostrar los clientes en la tabla
                if (data.clientes.length > 0) {
                    data.clientes.forEach(cliente => {
                        tablaClientes.innerHTML += `
                            <tr>
                                <td>${cliente.nombre}</td>
                                <td>${cliente.documento}</td>
                                <td>${cliente.telefono}</td>
                                <td><a class="btn btn-info btn-sm" href="dashboard_cliente.php?id=${cliente.id}">Dashboard</a></td>
                                <td><a class="btn btn-warning btn-sm" href="formulario_editar_cliente.php?id=${cliente.id}">Editar</a></td>
                                <td><a class="btn btn-danger btn-sm" href="eliminar_cliente.php?id=${cliente.id}" onclick="return confirm('¿Está seguro de que desea eliminar este cliente?');">Eliminar</a></td>
                            </tr>
                        `;
                    });
                } else {
                    tablaClientes.innerHTML = `
                        <tr>
                            <td colspan="6" class="text-center">No se encontraron resultados.</td>
                        </tr>
                    `;
                }

                // Crear botones de navegación
                const totalPaginas = data.total_paginas;

                if (totalPaginas > 1) {
                    // Botón Inicio
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarClientes('${query}', 1)">Inicio</button>
                        </li>
                    `;

                    // Botón Anterior
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarClientes('${query}', ${pagina - 1})">Anterior</button>
                        </li>
                    `;

                    // Botón Siguiente
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarClientes('${query}', ${pagina + 1})">Siguiente</button>
                        </li>
                    `;

                    // Botón Fin
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarClientes('${query}', ${totalPaginas})">Fin</button>
                        </li>
                    `;
                }
            })
            .catch(error => console.error('Error:', error));
    }
    // Cargar todos los clientes al inicio
    document.addEventListener('DOMContentLoaded', () => cargarClientes());
    // Escuchar eventos de entrada en el buscador
    document.getElementById('busqueda').addEventListener('input', function () {
        const query = this.value;
        cargarClientes(query);
    });
</script>
<?php
include 'footer.php';
?>
