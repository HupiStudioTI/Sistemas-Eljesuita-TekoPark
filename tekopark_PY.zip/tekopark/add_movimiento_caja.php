<?php
ob_start(); // Iniciamos el búfer de salida para evitar problemas con header()

$contenido = '<div class="row mx-0 text-center">
    <div class="col-12 mb-4">
        <h3 style="color: #ff5722;">Agregar Movimiento de Caja</h3>
        <h5>Complete los detalles del movimiento.</h5>
    </div>
</div>';

include 'encabezado.php';
include_once 'conexion.php';

// Obtenemos el ID del usuario logueado
$user_id = $_SESSION['usuario']['id'];

// Definir un valor por defecto para la fecha/hora usando el sistema (formato para input datetime-local, sin segundos)
$fecha_default = date("Y-m-d\TH:i");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recibimos los datos del formulario
    // Quitamos los separadores de miles (puntos) antes de convertir a entero
    $credito_str = str_replace('.', '', $_POST['credito']);
    $debito_str  = str_replace('.', '', $_POST['debito']);
    $credito = (int)$credito_str;
    $debito  = (int)$debito_str;
    $descripcion = trim($_POST['descripcion']);
    // Recibimos la fecha en formato "Y-m-d\TH:i" y la convertimos a "Y-m-d H:i:s"
    $fecha_input = $_POST['fecha'];
    $fecha = str_replace("T", " ", $fecha_input) . ":00"; // agregamos segundos

    $stmt = $conn->prepare("INSERT INTO movimientos_caja (usuario_id, credito, debito, descripcion, fecha) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiss", $user_id, $credito, $debito, $descripcion, $fecha);
    $stmt->execute();
    header("Location: movimientos_caja.php");
    exit();
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Movimiento de Caja</title>
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form id="movimiento-form" action="add_movimiento_caja.php" method="post">
                <div class="row">
                    <!-- Fecha y Hora -->
                    <div class="mb-3">
                        <label for="fecha" class="form-label">Fecha y Hora</label>
                        <!-- Se aplica un ancho máximo para que el input se vea más corto -->
                        <input type="datetime-local" name="fecha" id="fecha" class="form-control" style="max-width: 250px;" value="<?php echo $fecha_default; ?>" required>
                    </div>
                    <!-- Descripción -->
                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea name="descripcion" id="descripcion" class="form-control" rows="3" placeholder="Detalle del movimiento" required></textarea>
                    </div>
                    <!-- Crédito -->
                    <div class="col-md-6 mb-3">
                        <label for="credito" class="form-label">Crédito</label>
                        <!-- Cambiado a tipo "text" para permitir formateo con puntos -->
                        <input type="text" class="form-control" name="credito" id="credito" placeholder="Ejemplo: 100" onfocus="unformatNumber(this)" onblur="formatNumber(this)" required>
                    </div>
                    <!-- Débito -->
                    <div class="col-md-6 mb-3">
                        <label for="debito" class="form-label">Débito</label>
                        <input type="text" class="form-control" name="debito" id="debito" placeholder="Ejemplo: 50" onfocus="unformatNumber(this)" onblur="formatNumber(this)" required>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar Movimiento</button>
                    <a href="movimientos_caja.php" class="btn btn-secondary btn-sm">Volver</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="./js/bootstrap.bundle.min.js"></script>
<script>
// Función para formatear el número con separador de miles (punto)
function formatNumber(input) {
    // Quitamos cualquier caracter que no sea dígito
    var value = input.value.replace(/\D/g, '');
    if(value === '') return;
    // Convertimos a entero y formateamos usando toLocaleString con la configuración de 'es-ES'
    input.value = parseInt(value, 10).toLocaleString('es-ES');
}

// Función para quitar el formateo (para edición)
function unformatNumber(input) {
    // Quita cualquier caracter que no sea dígito
    var value = input.value.replace(/\D/g, '');
    input.value = value;
}

// Antes de enviar el formulario, se quitan los puntos para que se envíe el valor numérico puro
document.getElementById('movimiento-form').addEventListener('submit', function(e) {
    var creditoInput = document.getElementById('credito');
    var debitoInput = document.getElementById('debito');
    creditoInput.value = creditoInput.value.replace(/\./g, '');
    debitoInput.value = debitoInput.value.replace(/\./g, '');
});
</script>
</body>
</html>
<?php include 'footer.php'; ?>
