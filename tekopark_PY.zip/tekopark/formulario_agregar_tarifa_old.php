<?php
include_once "encabezado.php";
?>

<div class="row">
    <div class="col-12">
        <h1>Agregar Tarifa</h1>
        <form action="guardar_tarifa.php" method="POST">
            <div class="form-group">
                <label for="actividad">Actividad</label>
                <input type="text" name="actividad" id="actividad" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="dia_semana">Día de la semana</label>
                <select name="dia_semana" id="dia_semana" class="form-control" required>
                    <option value="Lunes">Lunes</option>
                    <option value="Martes">Martes</option>
                    <option value="Miércoles">Miércoles</option>
                    <option value="Jueves">Jueves</option>
                    <option value="Viernes">Viernes</option>
                    <option value="Sábado">Sábado</option>
                    <option value="Domingo">Domingo</option>
                </select>
            </div>
            <div class="form-group">
                <label for="hora_inicio">Hora de inicio</label>
                <input type="time" name="hora_inicio" id="hora_inicio" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="duracion">Duración</label>
                <select name="duracion" id="duracion" class="form-control" required>
                    <option value="1h">1 Hora</option>
                    <option value="1.5h">1 Hora y Media</option>
                </select>
            </div>
            <div class="form-group">
                <label for="precio">Precio</label>
                <input type="number" step="1" name="precio" id="precio" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Guardar</button>
        </form>
    </div>
</div>
