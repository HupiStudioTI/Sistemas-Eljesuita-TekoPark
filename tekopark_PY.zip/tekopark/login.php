<?php
session_start();
require 'conexion.php'; // Asegúrate de que este archivo tenga la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $clave = trim($_POST['clave']);

    // Verificamos si existen usuarios en la tabla
    $sql = "SELECT COUNT(*) AS total FROM usuarios";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $totalUsuarios = $row['total'];

    // Si no hay usuarios, permitir el acceso con las credenciales predeterminadas
    if ($totalUsuarios == 0) {
        if ($nombre === 'gustavo' && $clave === 'tavo') {
            $_SESSION['usuario'] = [
                'nombre' => 'gustavo',
                'rol'    => 'admin'
            ];
            header("Location: index.php");
            exit();
        } else {
            $error = "Credenciales incorrectas. No existen usuarios registrados y las credenciales predeterminadas no coinciden.";
        }
    } else {
        // Si existen usuarios, se busca el usuario ingresado
        $stmt = $conn->prepare("SELECT * FROM usuarios WHERE nombre = ?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_assoc();

        if ($usuario && password_verify($clave, $usuario['clave'])) {
            $_SESSION['usuario'] = $usuario;
            header("Location: index.php");
            exit();
        } else {
            $error = "Credenciales incorrectas.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - TekoPark</title>
  <link href="./css/bootstrap.min.css" rel="stylesheet">
  <link href="./css/all.min.css" rel="stylesheet">
  <style>
      body {
          background: #f4f4f9;
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
      }
      .card {
          width: 100%;
          max-width: 400px;
          box-shadow: 0 0 20px rgba(0,0,0,0.1);
          border: none;
      }
      .card-header {
          background: linear-gradient(90deg, #ff007f, #ff8c00);
          color: #fff;
          text-align: center;
          font-size: 1.5rem;
      }
      .btn-primary {
          background-color: #ff007f;
          border-color: #ff007f;
      }
      .btn-primary:hover {
          background-color: #e60073;
          border-color: #e60073;
      }
  </style>
</head>
<body>
  <div class="card">
      <div class="card-header">
          Iniciar Sesión
      </div>
      <div class="card-body">
          <?php if (isset($error)) { echo "<div class='alert alert-danger'>{$error}</div>"; } ?>
          <form method="post" action="">
              <div class="mb-3">
                  <label for="nombre" class="form-label">Nombre</label>
                  <input type="text" id="nombre" name="nombre" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label for="clave" class="form-label">Clave</label>
                  <input type="password" id="clave" name="clave" class="form-control" required>
              </div>
              <div class="d-grid">
                  <button type="submit" class="btn btn-primary">Ingresar</button>
              </div>
          </form>
      </div>
      <div class="card-footer text-center">
          <?php
          // Opcional: Informar al usuario sobre las credenciales predeterminadas en caso de que no exista ningún usuario
          $sql = "SELECT COUNT(*) AS total FROM usuarios";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
          if ($row['total'] == 0) {
              echo "No hay usuarios registrados.<br>Comuniquese con Sopoprte: <strong>info@hupistudio.net</strong> / <strong>+5493764902929</strong>";
          }
          ?>
      </div>
  </div>
  <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>
