<?php
include_once "conexion.php";
$id = $_GET['id'];
$sql = "DELETE FROM colaboradores WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: colaboradores.php");
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
