<php>
include_once "conexion.php";
</php>
<!-- Modal para buscar y seleccionar clientes -->
<div class="modal fade" id="clientesModal" tabindex="-1" aria-labelledby="clientesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="clientesModalLabel">Seleccionar Clientes</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="cliente_search_modal" class="form-control" placeholder="Buscar cliente por nombre, teléfono, etc.">
                <table class="table mt-3" id="clientesTable">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Los resultados se cargarán aquí mediante JavaScript -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" id="agregarClientes">Agregar Clientes</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Autocomplete en el modal para buscar clientes
        $("#cliente_search_modal").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "buscar_clientes.php",
                    method: "GET",
                    dataType: "json",
                    data: { query: request.term },
                    success: function(data) {
                        response($.map(data, function(item) {
                            return {
                                label: item.nombre + " (" + item.telefono + ")",
                                value: item.id,
                                //nombre: item.nombre,
                                //telefono: item.telefono
                            };
                        }));
                    }
                });
            },
            select: function(event, ui) {
                // Agregar cliente a la tabla
                var cliente = `<tr data-id="${ui.item.value}">
                                   <td>${ui.item.nombre}</td>
                                   <td>${ui.item.telefono}</td>
                                   <td><button type="button" class="btn btn-danger btn-sm remove-client">Eliminar</button></td>
                               </tr>`;
                $("#clientesTable tbody").append(cliente);
                return false;
            }
        });

        // Agregar clientes a la grilla del formulario
        $("#agregarClientes").click(function() {
            var cantidadClientes = $("#cantidad_clientes").val();
            var selectedClients = $("#clientesTable tbody tr").length;

            if (selectedClients > cantidadClientes) {
                alert("No puedes agregar más clientes de los especificados.");
                return;
            }

            var clienteInputs = "";
            $("#clientesTable tbody tr").each(function() {
                var id = $(this).data("id");
                clienteInputs += `<input type="hidden" name="clientes[]" value="${id}">`;
            });

            $("#clientesContainer").html(clienteInputs);

            $("#clientesModal").modal('hide');
        });

        // Eliminar cliente de la tabla en el modal
        $(document).on('click', '.remove-client', function() {
            $(this).closest('tr').remove();
        });
    });
</script>
