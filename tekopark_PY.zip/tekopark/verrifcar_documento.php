<?php
// funciones.php
$host = 'localhost';
$db   = 'teko';
$user = 'root';
$pass = 'dragon2025';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

if (isset($_POST['documento'])) {
    $documento = $_POST['documento'];

    // Realiza la consulta para verificar si el documento existe
    $query = "SELECT COUNT(*) as count FROM clientes WHERE documento = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$documento]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Retorna la respuesta en formato JSON
    echo json_encode(['exists' => $result['count'] > 0]);
}
?>
