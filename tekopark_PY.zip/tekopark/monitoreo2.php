<?php
// monitoreo.php
include_once "conexion.php";

// Zona horaria
date_default_timezone_set('America/Argentina/Buenos_Aires');

// ---------------------
// Procesar Ajax
// ---------------------

// Escanear la pulsera
if (isset($_POST['action']) && $_POST['action'] === 'scan') {
    $pulsera = trim($_POST['pulsera']);

    // Buscar último registro
    $sqlCheck = "SELECT * FROM monitore WHERE pulsera = ? ORDER BY id DESC LIMIT 1";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $pulsera);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck && $resCheck->num_rows > 0) {
        $lastRow = $resCheck->fetch_assoc();
        if ($lastRow['estado'] === 'en_juego') {
            $updateSql = "UPDATE monitore SET estado = 'finalizado' WHERE id = ?";
            $stmtUpd = $conn->prepare($updateSql);
            $stmtUpd->bind_param("i", $lastRow['id']);
            $stmtUpd->execute();
            echo json_encode(['success' => true, 'msg' => 'Pulsera finalizada: ' . $pulsera]);
            exit;
        } else {
            echo json_encode(['success' => false, 'msg' => 'Pulsera ya fue finalizada.']);
            exit;
        }
    } else {
        // No hay registro anterior → buscar en clientes_reserva
        $sql = "SELECT cr.cliente_id, cr.reserva_id, cr.nombre, cr.identificacion, r.codigo_reserva,
                       r.hora_desde, r.hora_hasta, v.color_value AS color
                FROM clientes_reserva cr
                INNER JOIN reservas r ON cr.reserva_id = r.id
                LEFT JOIN ventas v ON v.reserva_id = r.id
                WHERE cr.pulsera = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pulsera);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fechaEscaneo = date('Y-m-d H:i:s');
            $clienteId    = $row['cliente_id'];
            $reservaId    = $row['reserva_id'];
            $nombreCl     = $row['nombre'];
            $identiCl     = $row['identificacion'];
            $codigoReserva= $row['codigo_reserva'];
            $color        = trim($row['color'] ?: '');
            if (!$color || strtolower($color) === 'sincolor') {
                $color = '#ccc';
            }
            $durationSeconds = strtotime($row['hora_hasta']) - strtotime($row['hora_desde']);
            $newHoraFin = date('Y-m-d H:i:s', strtotime($fechaEscaneo) + $durationSeconds);

            $insertSql = "INSERT INTO monitore 
                (pulsera, cliente_id, reserva_id, codigo_reserva, nombre_cliente, identificacion_cliente, 
                 color, fecha_escaneo, hora_fin, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'en_juego')";
            $stmtInsert = $conn->prepare($insertSql);
            $stmtInsert->bind_param("siissssss",
                $pulsera,
                $clienteId,
                $reservaId,
                $codigoReserva,
                $nombreCl,
                $identiCl,
                $color,
                $fechaEscaneo,
                $newHoraFin
            );
            $stmtInsert->execute();
            echo json_encode(['success' => true, 'msg' => 'Pulsera registrada: ' . $pulsera]);
            exit;
        } else {
            echo json_encode(['success' => false, 'msg' => 'Pulsera no encontrada en clientes_reserva']);
            exit;
        }
    }
}

// Listar “en_juego” (orden ASC)
if (isset($_POST['action']) && $_POST['action'] === 'listar') {
    $sql = "SELECT id, pulsera, nombre_cliente, identificacion_cliente, color, fecha_escaneo, hora_fin
            FROM monitore
            WHERE estado = 'en_juego'
            ORDER BY fecha_escaneo ASC";
    $result = $conn->query($sql);
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Monitoreo de Clientes en Juego</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap local -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Fuente Orbitron -->
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">

  <!-- Estilos personalizados (después de Bootstrap) -->
  <style>
    html, body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background: #fff;
      height: 100%;
    }
    #main-container {
      width: 100%;
      padding: 1rem;
      box-sizing: border-box;
    }
    .fucsia-box {
      position: relative;
      border: 4px solid fuchsia;
      border-radius: 8px;
      padding: 2.5rem 1rem 1rem;
      color: #000;
    }
    #clock {
      font-family: 'Orbitron', monospace;
      font-size: 2.5rem;
      color: #0f0;
      font-weight: bold;
      position: absolute;
      top: 0.5rem;
      right: 1rem;
      text-shadow: 0 0 5px #0f0;
    }
    .header-container {
      text-align: center;
      margin-bottom: 1rem;
    }
    .header-container img {
      max-height: 60px;
    }
    .scan-input {
      margin-bottom: 1rem;
    }

    /* Cuando quedan 5 minutos o menos: nombre, identificación, ingreso y tiempo en naranja y negrita */
    .text-time-warning {
      color: orange !important;
      font-weight: bold !important;
    }
    /* Cuando finalizó: parpadeo rojo en esos campos */
    @keyframes blinkRed {
      0%, 100% { color: red !important; }
      50%      { color: transparent !important; }
    }
    .text-blinking-red {
      animation: blinkRed 1s infinite alternate !important;
      font-weight: bold !important;
      color: red !important;
    }

    /* Paginación personalizada */
    #pagination {
      display: flex;
      justify-content: center;
      list-style: none;
      padding: 0;
      margin: 1rem 0 0 0;
    }
    #pagination li {
      margin: 0 4px;
    }
    #pagination button {
      background: #fff;
      border: 1px solid fuchsia;
      padding: 6px 10px;
      cursor: pointer;
      font-size: 0.9rem;
      color: #000;
      border-radius: 4px;
      transition: background 0.2s;
    }
    #pagination button:hover {
      background: fuchsia;
      color: #fff;
    }
    #pagination .active button {
      background: fuchsia;
      color: #fff;
      font-weight: bold;
    }
    #pagination .disabled button {
      border-color: #ccc;
      color: #ccc;
      cursor: default;
    }
  </style>
</head>
<body>
  <div id="main-container">
    <div class="fucsia-box">
      <div id="clock">--:--:--</div>

      <div class="header-container">
        <!-- Reemplazamos el título por el logo -->
        <img src="../img/logo_tekopark.png" alt="Logo TekoPark">
      </div>

      <div class="d-flex justify-content-center mb-3">
        <input 
          type="text" 
          id="pulsera" 
          class="form-control scan-input w-75"
          placeholder="Escanea la pulsera..."
          autofocus
        />
      </div>

      <div id="listado" class="table-responsive"></div>

      <!-- Paginación -->
      <ul id="pagination"></ul>
    </div>
  </div>

  <!-- Modal de error -->
  <div id="modal-error" class="modal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-danger">
        <div class="modal-body text-danger text-center" id="modal-message"></div>
      </div>
    </div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      let allData     = [];
      let currentPage = 0;
      const pageSize  = 10;

      const clockEl     = document.getElementById('clock');
      const pulseraEl   = document.getElementById('pulsera');
      const listadoEl   = document.getElementById('listado');
      const paginationEl= document.getElementById('pagination');
      const modalError  = new bootstrap.Modal(document.getElementById('modal-error'));
      const modalMsgEl  = document.getElementById('modal-message');

      function showModalError(msg) {
        modalMsgEl.text(msg);
        modalError.show();
        setTimeout(() => modalError.hide(), 2000);
        // reenfocar input
        pulseraEl.focus();
      }

      function escanearPulsera(code) {
        $.ajax({
          url: 'monitoreo2.php',
          type: 'POST',
          data: { action: 'scan', pulsera: code },
          dataType: 'json',
          success: function(r) {
            if (r.success) {
              listarMonitore();
            } else {
              showModalError(r.msg);
            }
            pulseraEl.focus();
          },
          error: function() {
            showModalError('Error de comunicación con el servidor.');
            pulseraEl.focus();
          }
        });
      }

      function listarMonitore() {
        $.ajax({
          url: 'monitoreo2.php',
          type: 'POST',
          data: { action: 'listar' },
          dataType: 'json',
          success: function(rows) {
            allData = parseData(rows);
            currentPage = 0;
            renderTabla();
            renderPagination();
            pulseraEl.focus();
          },
          error: function() {
            showModalError('Error al listar los clientes en juego.');
            pulseraEl.focus();
          }
        });
      }

      function parseData(rows) {
        rows.forEach(r => {
          if (r.hora_fin) {
            r.endDate = new Date(r.hora_fin.replace(' ', 'T'));
          } else {
            r.endDate = null;
          }
        });
        return rows;
      }

      function renderTabla() {
        if (!allData || allData.length === 0) {
          listadoEl.innerHTML = '<p class="text-center">No hay clientes en juego.</p>';
          return;
        }

        const now      = new Date();
        const startIdx = currentPage * pageSize;
        const endIdx   = startIdx + pageSize;
        const view     = allData.slice(startIdx, endIdx);

        let html = `
          <table class="table table-striped table-hover">
            <thead class="table-dark">
              <tr>
                <th>Pulsera</th>
                <th>Nombre</th>
                <th>Identificación</th>
                <th>Color</th>
                <th>Ingreso</th>
                <th>Tiempo Restante</th>
              </tr>
            </thead>
            <tbody>
        `;

        view.forEach(item => {
          const pulsera = item.pulsera || '';
          let nombre    = item.nombre_cliente || '';
          let identi    = item.identificacion_cliente || '';
          const color   = item.color || 'transparent';
          let fechaE    = item.fecha_escaneo || '';
          if (fechaE.indexOf(' ') > -1) {
            fechaE = fechaE.split(' ')[1];
          }

          let tiempoRestante = '---';
          let nameClass      = '';
          let idClass        = '';
          let ingresoClass   = '';
          let tiempoClass    = '';

          if (item.endDate) {
            const diffMs = item.endDate - now;
            if (diffMs > 5 * 60 * 1000) {
              const diffMins = Math.floor(diffMs / 60000);
              const diffSecs = Math.floor((diffMs % 60000) / 1000);
              tiempoRestante = `${diffMins}m ${diffSecs}s`;
            } else if (diffMs > 0) {
              const diffMins = Math.floor(diffMs / 60000);
              const diffSecs = Math.floor((diffMs % 60000) / 1000);
              tiempoRestante = `${diffMins}m ${diffSecs}s`;
              nameClass      = 'text-time-warning';
              idClass        = 'text-time-warning';
              ingresoClass   = 'text-time-warning';
              tiempoClass    = 'text-time-warning';
            } else {
              tiempoRestante = 'Finalizado';
              nameClass      = 'text-blinking-red';
              idClass        = 'text-blinking-red';
              ingresoClass   = 'text-blinking-red';
              tiempoClass    = 'text-blinking-red';
            }
          }

          html += `
            <tr>
              <td>${pulsera}</td>
              <td class="${nameClass}">${nombre}</td>
              <td class="${idClass}">${identi}</td>
              <td><div style="background:${color};width:16px;height:16px;border:1px solid #ccc;"></div></td>
              <td class="${ingresoClass}">${fechaE}</td>
              <td class="${tiempoClass}">${tiempoRestante}</td>
            </tr>
          `;
        });

        html += `
            </tbody>
          </table>
        `;
        listadoEl.innerHTML = html;
      }

      function renderPagination() {
        if (!allData || allData.length <= pageSize) {
          paginationEl.innerHTML = '';
          pulseraEl.focus();
          return;
        }
        const totalPages = Math.ceil(allData.length / pageSize);
        let html = '';

        // Botón Anterior
        html += `
          <li class="${currentPage === 0 ? 'disabled' : ''}">
            <button id="prevPage">&laquo;</button>
          </li>
        `;

        // Páginas
        for (let i = 0; i < totalPages; i++) {
          html += `
            <li class="${i === currentPage ? 'active' : ''}">
              <button class="page-num" data-page="${i}">${i + 1}</button>
            </li>
          `;
        }

        // Botón Siguiente
        html += `
          <li class="${currentPage === totalPages - 1 ? 'disabled' : ''}">
            <button id="nextPage">&raquo;</button>
          </li>
        `;

        paginationEl.innerHTML = html;

        // Evento “Anterior”
        $('#prevPage').off('click').on('click', function() {
          if (currentPage > 0) {
            currentPage--;
            renderTabla();
            renderPagination();
          }
          pulseraEl.focus();
        });

        // Evento “Siguiente”
        $('#nextPage').off('click').on('click', function() {
          if (currentPage < totalPages - 1) {
            currentPage++;
            renderTabla();
            renderPagination();
          }
          pulseraEl.focus();
        });

        // Evento botones de página
        $('.page-num').off('click').on('click', function() {
          currentPage = parseInt($(this).data('page'), 10);
          renderTabla();
          renderPagination();
          pulseraEl.focus();
        });
      }

      pulseraEl.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && this.value.trim() !== '') {
          escanearPulsera(this.value.trim());
          this.value = '';
        }
      });

      function updateClock() {
        const n = new Date();
        const hh = String(n.getHours()).padStart(2, '0');
        const mm = String(n.getMinutes()).padStart(2, '0');
        const ss = String(n.getSeconds()).padStart(2, '0');
        clockEl.textContent = `${hh}:${mm}:${ss}`;
      }
      setInterval(updateClock, 1000);

      function updateTiempos() {
        renderTabla();
      }
      setInterval(updateTiempos, 1000);

      // Inicialización
      listarMonitore();
    });
  </script>
</body>
</html>
