<?php
include 'header.php';
include 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'];
    $id_colaborador = $_POST['id_colaborador'];
    $forma_pago = $_POST['forma_pago'];
    $credito = $_POST['credito'];
    $debito = $_POST['debito'];
    $descripcion = $_POST['descripcion'];

    if (agregarCaja($fecha, $id_colaborador, $forma_pago, $credito, $debito, $descripcion)) {
        header('Location: cajas.php');
    } else {
        echo "<div class='alert alert-danger'>Error al agregar la caja.</div>";
    }
}

$colaboradores = obtenerColaboradores();
?>

<div class="container mt-4">
    <h2>Agregar Nueva Caja</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label>Fecha</label>
            <input type="datetime-local" name="fecha" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Colaborador</label>
            <select name="id_colaborador" class="form-control select2" required>
                <option value="">Seleccione...</option>
                <?php foreach ($colaboradores as $col): ?>
                    <option value="<?php echo $col['id']; ?>"><?php echo $col['nombre']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Forma de Pago</label>
            <select name="forma_pago" class="form-control" required>
                <option value="efectivo">Efectivo</option>
                <option value="tarjeta">Tarjeta</option>
                <option value="qr">QR</option>
                <option value="transferencia">Transferencia</option>
                <option value="otro">Otro</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Crédito</label>
            <input type="number" name="credito" class="form-control" step="0.01">
        </div>
        <div class="mb-3">
            <label>Débito</label>
            <input type="number" name="debito" class="form-control" step="0.01">
        </div>
        <div class="mb-3">
            <label>Descripción</label>
            <textarea name="descripcion" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="cajas.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>

<?php include 'footer.php'; ?>
