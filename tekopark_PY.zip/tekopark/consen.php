<?php
ob_start(); // Iniciar el buffer de salida
include 'funciones.php';
include_once 'encabezado.php';
$db = obtenerbd();

$id = $_GET['id'];
$query = $db->prepare("SELECT * FROM clientes WHERE id = ?");
$query->execute([$id]);
$cliente = $query->fetch(PDO::FETCH_ASSOC);

// Datos del padre/tutor
$obs = $cliente['obs'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Generar PDF
    require_once('tcpdf/tcpdf.php');

    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    // Contenido del consentimiento
    $contenido = "En consideración a los servicios prestados por Ideas del Norte SRL con el nombree fantasía TekoPark  y del permiso concedido por TekoPark de usar la propiedad, instalaciones y servicios del mismo y de participar en las actividades cama elástica, actividades de escalada y otras actividades en TekoPark (las «actividades»), que, en mi nombre y en nombre de los menores a mi cargo y/o persona autorizada para actuar en lugar de los padres se enumeran a continuación («Menores»), de acuerdo a los siguientes términos y condiciones: 
                  1. Este documento afecta a los derechos legales. Entiendo que este documento afecta mis derechos legales y los derechos legales de los menores de edad, y que al firmar abajo reconozco que he leído y comprendido la divulgación de riesgos, que acepto voluntariamente esos riesgos, y acepto estar obligado por los términos y condiciones de este acuerdo.
                  2. Liberación General y la renuncia de la responsabilidad. En consideración a los servicios prestados por el parque y del permiso concedido por TekoPark de uso de bienes, instalaciones y servicios  y de participar en las actividades, que, para mí y en nombre de mis cónyuge, hijos, tutelado, y otras personas dependientes, herederos, cesionarios, representantes personales y familiares («Partes liberadas»), la liberación voluntaria y descargo para siempre y estoy de acuerdo de no demandar al parque o sus agentes, empleados, miembros, gerentes, propietarios, funcionarios, directores, voluntarios, participantes, aseguradoras, explotadores de las instalaciones, arrendadores, sucesores, cesionarios, proveedores o fabricantes de equipos, proveedores de servicios, formadores, los titulares de propiedad intelectual, o cualquier otra persona o entidad que actúe en cualquier calidad y/o en nombre  (en adelante colectivamente como las «Partes Protegidas») de responsabilidad por cualquier reclamo mío o de los menores a mi cargo en la participación en las actividades o el uso de las instalaciones , entre ellos, en la medida permitida por la ley, tales reclamaciones que alegan actos u omisiones negligentes de cualquiera de las Partes Protegidas.
                  Entiendo que esta liberación de responsabilidad impedirá para el firmante como los menores de edad el ejercicio de cualquier demanda o cualquier reclamo por daños personales o la muerte relacionada con la participación en las actividades o el uso de las instalaciones de TekoPark.
                  3. Reconocimiento de Riesgos. Entiendo que mi participación y la participación de los menores en las actividades implican riesgos conocidos y desconocidos que podrían resultar en lesiones físicas, emocionales, parálisis, muerte o daño a mí, a los menores de edad, o para terceros. Tales riesgos (los «riesgos») incluyen, pero no se limitan a:
                  3.1 los riesgos inherentes a las actividades, incluyendo resbalones, caídas, colisiones con objetos fijos y/u otros participantes, la caída de equipos, fallo inesperado de los equipos, sobreesfuerzo, doble de rebote, no haber logrado saltos y acrobacias, laceraciones sostenidas, contraer cualquier enfermedad por el contacto con los equipos y/o superficies y/o cualquier otro elemento de TekoPark;
                  3.2 los actos negligentes u omisiones de las Partes protegidas;
                  3.3 defectos en TekoPark o cualquiera de sus instalaciones;
                  3.4 instrucción o supervisión incorrecta o inadecuada en relación con las actividades o el uso de las instalaciones del TekoPark;
                  3.5 el comportamiento de los demás participantes en las actividades y/o las personas que visitan el TekoPark;
                  3.6 accidentes o incidentes en las instalaciones de TekoPark; y
                  3.7 de primeros auxilios, tratamiento y/o servicios prestados y/o fallo de emergencia que deba prestar las Partes protegidas.
                  Los posibles daños incluyen, pero no se limitan a esguinces, rasguños, contusiones, fractura de huesos, lesiones en los ojos, roturas de ligamentos, lesiones en las articulaciones, debilitamiento de las placas de crecimiento, retraso en el crecimiento después de fracturas, lesiones internas, lesiones cerebrales, conmociones cerebrales, incapacidades permanentes, lesiones en la espalda, rotura del cuello, parálisis, infarto de miocardio y la muerte.
                  Entiendo y reconozco que el listado anterior no es completo ni exhaustivo, y que otros riesgos tanto conocidos como desconocidos también pueden provocar lesiones, muerte, enfermedad o daño a mí, a los menores de edad o en su propiedad.
                  Entiendo y reconozco que es política  que sus participantes revisen su video de seguridad que cubre algunos, pero no todos los riesgos relacionados con Teko Park en cada visita al mismo. Manifiesto que voy a ver el video de seguridad y que tanto los menores como el firmante estamos de acuerdo en adherirnos a la política de seguridad de vídeo y seguir las reglas y directrices contenidas en el mismo.
                  4. Asunción de riesgos. Después de estar completamente informados de lo anteriormente mencionado y de la comprensión de la realidad, la naturaleza y los efectos de este` Acuerdo, que, en mi propio nombre y, en la máxima medida permitida por la ley, en nombre de todas las Partes Liberadas y los menores de edad, expreso estar de acuerdo y prometo aceptar y asumir todos los riesgos conocidos y desconocidos asociados con la participación en las actividades y el uso de las instalaciones de TekoPark, incluyendo los riesgos mencionados anteriormente, y elijo voluntariamente participar y/o permitir que los menores de edad a mi cargo puedan participar en las actividades y el uso las instalaciones de TekoPark.
                  Estoy de acuerdo en que hay ciertos riesgos inherentes a las actividades que no pueden ser evitados y/o eliminados, y que al firmar este Acuerdo, estoy renunciando a mi derecho, el derecho de los menores y de cualquiera de las Partes Liberadas, para demandar y/o iniciar cualquier otro procedimiento en concepto de daño y/o daños personales y/o muerte que resulte de tales riesgos. Entiendo que tengo el derecho de negarme a firmar este Acuerdo, y el Parque tiene el derecho de negar la participación en el mismo a mí o a los menores a mi cargo en caso de no firmar el presente Acuerdo
                  5. Acuerdo de indemnización. En la medida permitida por la ley, por la presente manifiesto de manera irrevocable renunciar a realizar cualquier reclamo y/o solicitar una indemnización, y a defender a las Partes Liberadas contra cualquier reclamo, pérdida, acción, procedimiento, costo, gasto, daño, importes de liquidación y pasivos (incluyendo los reclamos presentados por cualquiera de las Partes Liberadas o menores de edad) y todos los costos y gastos en relación con los mismos, incluidos los honorarios de abogado y costos de la investigación (colectivamente los «Reclamos»), relacionados con el firmante o la participación de los menores en las actividades o el uso de las instalaciones de TekoPark, independientemente si los reclamos son resultado de actos y/u omisiones negligentes del firmante, de los menores de edad, las Partes Protegidas, o de terceros, incluyendo otros participantes en las actividades. Esta obligación deberá incluir, pero no limitarse a, cualquier reclamo, acción o procedimiento que alegue que el firmante o los menores han causado por negligencia o de manera intencional cualquier lesión, muerte o daño a otros participantes en las actividades u otros terceros en el Parque.
                  6. Liberación de Derechos de audio, video e imágenes fotográficas. Por la presente otorgo al Parque en mi nombre y de todos los menores a mi cargo el derecho irrevocable y el permiso para fotografiar y/o grabar a mí o a los menores a mi cargo en relación a las actividades, y al Parque, y al uso de las imágenes fotográficas, audios o vídeos a los efectos de seguimiento de las actividades llevadas a cabo en el parque, incluso para fines de seguridad. Estoy de acuerdo en que el parque tendrá derecho a retener dichas fotografías y grabaciones durante un período razonable después de mi asistencia o la de los menores a mi cargo al Parque, y que podrá utilizarla a su criterio con fines publicitarios en red.
                  7. Certificaciones. Con el fin de ayudar al Parque en la prestación efectiva por mi seguridad y la seguridad de los menores de edad, certifico y garantizo que:
                  7.1 No tengo conocimiento de ningún problema de salud que haría que la participación en las actividades impacte negativamente en mi salud o la de los menores de edad a mi cargo;
                  7.2 Los menores a mi cargo y/o el firmante poseemos un nivel suficiente de aptitud física y habilidad para participar con seguridad en las actividades. Ni yo ni los menores tienen alguna condición física o médica preexistente que podría verse afectada o agravada por el uso de TekoPark o cualquiera de sus instalaciones, incluyendo, pero no limitado a, el embarazo, problemas ortopédicos, problemas de espalda, problemas del corazón, o problemas respiratorios;
                  7.3 No voy a utilizar o permitir que los niños utilicen el Parque, mientras que alguno esté bajo la influencia de alguna droga y/o alcohol y/o medicamentos que pueda poner en peligro nuestras actividades físicas o juicio;
                  7.4 Acuerdo seguir (e instruir a los menores de edad seguir) todas las reglas de seguridad de TekoPark y alertar al personal de TekoPark cualquier violación de reglas y/o comportamientos peligrosos de los demás participantes, entre ellas las limitaciones de peso (máximo 120 kg) y de edad (Zona de salto de libre a partir de los 7 años en adelante)
                  7.5 Entiendo que el fracaso o la negativa a cumplir las normas de seguridad de TekoPark o las instrucciones y direcciones del personal de TekoPark por mi parte o de los menores a mi cargo, puede dar lugar a la revocación inmediata del derecho de uso de TekoPark, sin ningún derecho a la devolución de los pagos efectuados;
                  7.6 Voy a notificar al personal de TekoPark antes de que los menores de edad o yo participemos en las actividades si alguno de nosotros ha sido diagnosticado con trastornos de conducta o está tomando algún medicamento de modificación de conducta;
                  7.7 Voy a informar al personal de TekoPark de inmediato si los menores o yo sentimos alguna molestia inusual durante la participación en las actividades y se detendrá de inmediato (o causar a los menores de edad para detener) la participación en las actividades;
                  7.8 Soy consciente de que el personal de TekoPark puede necesitar poner fin a la participación en las actividades si los menores o yo presentamos un peligro para nosotros o para otros;
                  7.9 Autorizo al personal de TekoPark para administrar primeros auxilios y resucitación cardiopulmonar («RCP») para mí y para los menores de edad cuando se considere necesario por el personal de TekoPark y de manera irrevocable indemnizar y mantener TekoPark y las partes protegidas contra todas las responsabilidades, reclamaciones, daños y perjuicios de cualquier naturaleza y de cualquier causa que de mi parte o los menores a mi cargo pueda sufrir o provocarse como consecuencia directa o indirecta del personal de TekoPark administrando primeros auxilios y/o RCP.
                  7.10 Autorizo al personal de TekoPark para garantizar la atención médica de emergencia y/o transporte, si se considera necesario por el personal y estoy de acuerdo en asumir todos los costos de la atención médica de emergencia y transporte, y de manera irrevocable indemnizar y mantener el parque y las partes protegidas inofensivos contra todas las responsabilidades, reclamaciones, daños y perjuicios de cualquier naturaleza y de cualquier causa que de mi parte o de los menores pueda sufrir o provocarse como consecuencia directa o indirecta de cualquier y toda la atención médica de emergencia o transporte.
                  7.11 Tengo un seguro adecuado para cubrir cualquier lesión o daño que tanto yo como los menores pueden causar y/o sufrir durante su participación en las actividades, o en todo caso, estoy de acuerdo en asumir los costos de tales lesiones y daños a mí mismo, los menores de edad y otros.
                  ASUNCIÓN DE RIESGO:
                  8. Estoy de acuerdo, en la medida permitida por la ley, de renunciar y liberar a Ideas del Norte SRL de toda responsabilidad por muerte, discapacidad, lesiones personales, daños a la propiedad, el robo de propiedad o acciones de cualquier tipo en relación a la participación mía o de los menores en las actividades de TekoPark.
                  9. Divisibilidad. Cualquier disposición de este Acuerdo que sea o pueda ser ilegal, inválida o no ejecutable en cualquier jurisdicción afectada por el presente Acuerdo, en cuanto a dicha jurisdicción, deberá ser tratado como no haber sido escrito y separado del resto del Contrato, sin invalidar las restantes disposiciones de este Acuerdo o que afecten a la validez o aplicabilidad de dicha disposición en cualquier otra jurisdicción. Entiendo y estoy de acuerdo que este Acuerdo tiene la intención de ser tan amplio e inclusivo como permitido por las leyes de la República Argentina y que, si cualquier parte del mismo se considera inválida por un tribunal competente, el resto del acuerdo continuará con plena vigencia y efecto.
                  10. Efecto del Acuerdo. Estoy de acuerdo en que he tenido oportunidad razonable y suficiente para leer y comprender todo este acuerdo y reconozco que he sido libre para solicitar asesoría legal independiente acerca de la naturaleza y el efecto de cada disposición de este Acuerdo y que, o bien me asesoré de manera independiente o prescindí de la necesidad de hacerlo. Estoy de acuerdo, además, que cada disposición de este acuerdo es justo y razonable en todas las circunstancias.
                  11. Duración: El presente contrato tiene un plazo de 12 meses a partir de la fecha en la que se presta conformidad.
                  Certifico y garantizo que soy el padre o tutor legal o persona autorizada que actúa en lugar de los padres de los menores que figuran a continuación y que tengo la autoridad irrevocable de firmar este acuerdo en su nombre. Asimismo, certifico y garantizo que la información proporcionada a continuación para cada participante menor es verdadera y correcta. Reconozco y acepto que el personal  me requerirá una verificación de identidad (DNI) y constancia de haber completado y firmado este contrato tanto mía como del menor o menores que ingresen.
                  Toda información proveída por los participantes al Parque, deberá ser veraz, auténtica y comprobable, caso contrario, la empresa queda eximida de cualquier tipo de responsabilidad o reclamo que pueda surgir de ello.
                  No se podrá ingresar a los juegos con zapatillas o ropa no apta para la actividad, ni con elementos sueltos como anteojos, llaves, cinturones, o cualquier otro objeto corto punzante, a que, por la naturaleza y desenvolvimiento del juego, pueda convertirse en uno como tal.";
    $pdf->Write(0, $contenido, '', 0, 'L', true, 0, false, false, 0);
    // Insertar los datos del cliente en dos líneas
    $pdf->Ln();
    $pdf->Write(0, "Yo: " . $cliente['nombre'] . "\n", '', 0, 'L', true, 0, false, false, 0);
    $pdf->Write(0, "Con documento: " . $cliente['documento'] . "\n", '', 0, 'L', true, 0, false, false, 0);
    $pdf->Write(0, "Autorizo a: " . $obs . "\n", '', 0, 'L', true, 0, false, false, 0);

    // Espacio para firma
    $pdf->Ln(20);
    $pdf->Write(0, "Firma del Cliente: _________________________", '', 0, 'L', true, 0, false, false, 0);
    $pdf->Write(0, "Firma del Tutor (si aplica): _______________________", '', 0, 'L', true, 0, false, false, 0);
    ob_end_clean();

    // Salida del PDF
    $pdf->Output('consen.pdf', 'D');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consentimiento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
            padding: 20px;
            background-color: #f4f4f4;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        textarea {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            font-size: 14px;
            resize: none;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Consentimiento</h1>
        <form method="POST">
            <p>Por favor, lea y firme el consentimiento.</p>
            <textarea rows="20" cols="100" readonly><?php echo "En consideración a los servicios prestados por Ideas del Norte SRL con el nombree fantasía TekoPark  y del permiso concedido por TekoPark de usar la propiedad, instalaciones y servicios del mismo y de participar en las actividades cama elástica, actividades de escalada y otras actividades en TekoPark (las «actividades»), que, en mi nombre y en nombre de los menores a mi cargo y/o persona autorizada para actuar en lugar de los padres se enumeran a continuación («Menores»), de acuerdo a los siguientes términos y condiciones:
                  1. Este documento afecta a los derechos legales. Entiendo que este documento afecta mis derechos legales y los derechos legales de los menores de edad, y que al firmar abajo reconozco que he leído y comprendido la divulgación de riesgos, que acepto voluntariamente esos riesgos, y acepto estar obligado por los términos y condiciones de este acuerdo.
                  2. Liberación General y la renuncia de la responsabilidad. En consideración a los servicios prestados por el parque y del permiso concedido por TekoPark de uso de bienes, instalaciones y servicios  y de participar en las actividades, que, para mí y en nombre de mis cónyuge, hijos, tutelado, y otras personas dependientes, herederos, cesionarios, representantes personales y familiares («Partes liberadas»), la liberación voluntaria y descargo para siempre y estoy de acuerdo de no demandar al parque o sus agentes, empleados, miembros, gerentes, propietarios, funcionarios, directores, voluntarios, participantes, aseguradoras, explotadores de las instalaciones, arrendadores, sucesores, cesionarios, proveedores o fabricantes de equipos, proveedores de servicios, formadores, los titulares de propiedad intelectual, o cualquier otra persona o entidad que actúe en cualquier calidad y/o en nombre  (en adelante colectivamente como las «Partes Protegidas») de responsabilidad por cualquier reclamo mío o de los menores a mi cargo en la participación en las actividades o el uso de las instalaciones , entre ellos, en la medida permitida por la ley, tales reclamaciones que alegan actos u omisiones negligentes de cualquiera de las Partes Protegidas.
                  Entiendo que esta liberación de responsabilidad impedirá para el firmante como los menores de edad el ejercicio de cualquier demanda o cualquier reclamo por daños personales o la muerte relacionada con la participación en las actividades o el uso de las instalaciones de TekoPark.
                  3. Reconocimiento de Riesgos. Entiendo que mi participación y la participación de los menores en las actividades implican riesgos conocidos y desconocidos que podrían resultar en lesiones físicas, emocionales, parálisis, muerte o daño a mí, a los menores de edad, o para terceros. Tales riesgos (los «riesgos») incluyen, pero no se limitan a:
                  3.1 los riesgos inherentes a las actividades, incluyendo resbalones, caídas, colisiones con objetos fijos y/u otros participantes, la caída de equipos, fallo inesperado de los equipos, sobreesfuerzo, doble de rebote, no haber logrado saltos y acrobacias, laceraciones sostenidas, contraer cualquier enfermedad por el contacto con los equipos y/o superficies y/o cualquier otro elemento de TekoPark;
                  3.2 los actos negligentes u omisiones de las Partes protegidas;
                  3.3 defectos en TekoPark o cualquiera de sus instalaciones;
                  3.4 instrucción o supervisión incorrecta o inadecuada en relación con las actividades o el uso de las instalaciones del TekoPark;
                  3.5 el comportamiento de los demás participantes en las actividades y/o las personas que visitan el TekoPark;
                  3.6 accidentes o incidentes en las instalaciones de TekoPark; y
                  3.7 de primeros auxilios, tratamiento y/o servicios prestados y/o fallo de emergencia que deba prestar las Partes protegidas.
                  Los posibles daños incluyen, pero no se limitan a esguinces, rasguños, contusiones, fractura de huesos, lesiones en los ojos, roturas de ligamentos, lesiones en las articulaciones, debilitamiento de las placas de crecimiento, retraso en el crecimiento después de fracturas, lesiones internas, lesiones cerebrales, conmociones cerebrales, incapacidades permanentes, lesiones en la espalda, rotura del cuello, parálisis, infarto de miocardio y la muerte.
                  Entiendo y reconozco que el listado anterior no es completo ni exhaustivo, y que otros riesgos tanto conocidos como desconocidos también pueden provocar lesiones, muerte, enfermedad o daño a mí, a los menores de edad o en su propiedad.
                  Entiendo y reconozco que es política  que sus participantes revisen su video de seguridad que cubre algunos, pero no todos los riesgos relacionados con Teko Park en cada visita al mismo. Manifiesto que voy a ver el video de seguridad y que tanto los menores como el firmante estamos de acuerdo en adherirnos a la política de seguridad de vídeo y seguir las reglas y directrices contenidas en el mismo.
                  4. Asunción de riesgos. Después de estar completamente informados de lo anteriormente mencionado y de la comprensión de la realidad, la naturaleza y los efectos de este` Acuerdo, que, en mi propio nombre y, en la máxima medida permitida por la ley, en nombre de todas las Partes Liberadas y los menores de edad, expreso estar de acuerdo y prometo aceptar y asumir todos los riesgos conocidos y desconocidos asociados con la participación en las actividades y el uso de las instalaciones de TekoPark, incluyendo los riesgos mencionados anteriormente, y elijo voluntariamente participar y/o permitir que los menores de edad a mi cargo puedan participar en las actividades y el uso las instalaciones de TekoPark.
                  Estoy de acuerdo en que hay ciertos riesgos inherentes a las actividades que no pueden ser evitados y/o eliminados, y que al firmar este Acuerdo, estoy renunciando a mi derecho, el derecho de los menores y de cualquiera de las Partes Liberadas, para demandar y/o iniciar cualquier otro procedimiento en concepto de daño y/o daños personales y/o muerte que resulte de tales riesgos. Entiendo que tengo el derecho de negarme a firmar este Acuerdo, y el Parque tiene el derecho de negar la participación en el mismo a mí o a los menores a mi cargo en caso de no firmar el presente Acuerdo
                  5. Acuerdo de indemnización. En la medida permitida por la ley, por la presente manifiesto de manera irrevocable renunciar a realizar cualquier reclamo y/o solicitar una indemnización, y a defender a las Partes Liberadas contra cualquier reclamo, pérdida, acción, procedimiento, costo, gasto, daño, importes de liquidación y pasivos (incluyendo los reclamos presentados por cualquiera de las Partes Liberadas o menores de edad) y todos los costos y gastos en relación con los mismos, incluidos los honorarios de abogado y costos de la investigación (colectivamente los «Reclamos»), relacionados con el firmante o la participación de los menores en las actividades o el uso de las instalaciones de TekoPark, independientemente si los reclamos son resultado de actos y/u omisiones negligentes del firmante, de los menores de edad, las Partes Protegidas, o de terceros, incluyendo otros participantes en las actividades. Esta obligación deberá incluir, pero no limitarse a, cualquier reclamo, acción o procedimiento que alegue que el firmante o los menores han causado por negligencia o de manera intencional cualquier lesión, muerte o daño a otros participantes en las actividades u otros terceros en el Parque.
                  6. Liberación de Derechos de audio, video e imágenes fotográficas. Por la presente otorgo al Parque en mi nombre y de todos los menores a mi cargo el derecho irrevocable y el permiso para fotografiar y/o grabar a mí o a los menores a mi cargo en relación a las actividades, y al Parque, y al uso de las imágenes fotográficas, audios o vídeos a los efectos de seguimiento de las actividades llevadas a cabo en el parque, incluso para fines de seguridad. Estoy de acuerdo en que el parque tendrá derecho a retener dichas fotografías y grabaciones durante un período razonable después de mi asistencia o la de los menores a mi cargo al Parque, y que podrá utilizarla a su criterio con fines publicitarios en red.
                  7. Certificaciones. Con el fin de ayudar al Parque en la prestación efectiva por mi seguridad y la seguridad de los menores de edad, certifico y garantizo que:
                  7.1 No tengo conocimiento de ningún problema de salud que haría que la participación en las actividades impacte negativamente en mi salud o la de los menores de edad a mi cargo;
                  7.2 Los menores a mi cargo y/o el firmante poseemos un nivel suficiente de aptitud física y habilidad para participar con seguridad en las actividades. Ni yo ni los menores tienen alguna condición física o médica preexistente que podría verse afectada o agravada por el uso de TekoPark o cualquiera de sus instalaciones, incluyendo, pero no limitado a, el embarazo, problemas ortopédicos, problemas de espalda, problemas del corazón, o problemas respiratorios;
                  7.3 No voy a utilizar o permitir que los niños utilicen el Parque, mientras que alguno esté bajo la influencia de alguna droga y/o alcohol y/o medicamentos que pueda poner en peligro nuestras actividades físicas o juicio;
                  7.4 Acuerdo seguir (e instruir a los menores de edad seguir) todas las reglas de seguridad de TekoPark y alertar al personal de TekoPark cualquier violación de reglas y/o comportamientos peligrosos de los demás participantes, entre ellas las limitaciones de peso (máximo 120 kg) y de edad (Zona de salto de libre a partir de los 7 años en adelante)
                  7.5 Entiendo que el fracaso o la negativa a cumplir las normas de seguridad de TekoPark o las instrucciones y direcciones del personal de TekoPark por mi parte o de los menores a mi cargo, puede dar lugar a la revocación inmediata del derecho de uso de TekoPark, sin ningún derecho a la devolución de los pagos efectuados;
                  7.6 Voy a notificar al personal de TekoPark antes de que los menores de edad o yo participemos en las actividades si alguno de nosotros ha sido diagnosticado con trastornos de conducta o está tomando algún medicamento de modificación de conducta;
                  7.7 Voy a informar al personal de TekoPark de inmediato si los menores o yo sentimos alguna molestia inusual durante la participación en las actividades y se detendrá de inmediato (o causar a los menores de edad para detener) la participación en las actividades;
                  7.8 Soy consciente de que el personal de TekoPark puede necesitar poner fin a la participación en las actividades si los menores o yo presentamos un peligro para nosotros o para otros;
                  7.9 Autorizo al personal de TekoPark para administrar primeros auxilios y resucitación cardiopulmonar («RCP») para mí y para los menores de edad cuando se considere necesario por el personal de TekoPark y de manera irrevocable indemnizar y mantener TekoPark y las partes protegidas contra todas las responsabilidades, reclamaciones, daños y perjuicios de cualquier naturaleza y de cualquier causa que de mi parte o los menores a mi cargo pueda sufrir o provocarse como consecuencia directa o indirecta del personal de TekoPark administrando primeros auxilios y/o RCP.
                  7.10 Autorizo al personal de TekoPark para garantizar la atención médica de emergencia y/o transporte, si se considera necesario por el personal y estoy de acuerdo en asumir todos los costos de la atención médica de emergencia y transporte, y de manera irrevocable indemnizar y mantener el parque y las partes protegidas inofensivos contra todas las responsabilidades, reclamaciones, daños y perjuicios de cualquier naturaleza y de cualquier causa que de mi parte o de los menores pueda sufrir o provocarse como consecuencia directa o indirecta de cualquier y toda la atención médica de emergencia o transporte.
                  7.11 Tengo un seguro adecuado para cubrir cualquier lesión o daño que tanto yo como los menores pueden causar y/o sufrir durante su participación en las actividades, o en todo caso, estoy de acuerdo en asumir los costos de tales lesiones y daños a mí mismo, los menores de edad y otros.
                  ASUNCIÓN DE RIESGO:
                  8. Estoy de acuerdo, en la medida permitida por la ley, de renunciar y liberar a Ideas del Norte SRL de toda responsabilidad por muerte, discapacidad, lesiones personales, daños a la propiedad, el robo de propiedad o acciones de cualquier tipo en relación a la participación mía o de los menores en las actividades de TekoPark.
                  9. Divisibilidad. Cualquier disposición de este Acuerdo que sea o pueda ser ilegal, inválida o no ejecutable en cualquier jurisdicción afectada por el presente Acuerdo, en cuanto a dicha jurisdicción, deberá ser tratado como no haber sido escrito y separado del resto del Contrato, sin invalidar las restantes disposiciones de este Acuerdo o que afecten a la validez o aplicabilidad de dicha disposición en cualquier otra jurisdicción. Entiendo y estoy de acuerdo que este Acuerdo tiene la intención de ser tan amplio e inclusivo como permitido por las leyes de la República Argentina y que, si cualquier parte del mismo se considera inválida por un tribunal competente, el resto del acuerdo continuará con plena vigencia y efecto.
                  10. Efecto del Acuerdo. Estoy de acuerdo en que he tenido oportunidad razonable y suficiente para leer y comprender todo este acuerdo y reconozco que he sido libre para solicitar asesoría legal independiente acerca de la naturaleza y el efecto de cada disposición de este Acuerdo y que, o bien me asesoré de manera independiente o prescindí de la necesidad de hacerlo. Estoy de acuerdo, además, que cada disposición de este acuerdo es justo y razonable en todas las circunstancias.
                  11. Duración: El presente contrato tiene un plazo de 12 meses a partir de la fecha en la que se presta conformidad.
                  Certifico y garantizo que soy el padre o tutor legal o persona autorizada que actúa en lugar de los padres de los menores que figuran a continuación y que tengo la autoridad irrevocable de firmar este acuerdo en su nombre. Asimismo, certifico y garantizo que la información proporcionada a continuación para cada participante menor es verdadera y correcta. Reconozco y acepto que el personal  me requerirá una verificación de identidad (DNI) y constancia de haber completado y firmado este contrato tanto mía como del menor o menores que ingresen.
                  Toda información proveída por los participantes al Parque, deberá ser veraz, auténtica y comprobable, caso contrario, la empresa queda eximida de cualquier tipo de responsabilidad o reclamo que pueda surgir de ello.
                  No se podrá ingresar a los juegos con zapatillas o ropa no apta para la actividad, ni con elementos sueltos como anteojos, llaves, cinturones, o cualquier otro objeto corto punzante, a que, por la naturaleza y desenvolvimiento del juego, pueda convertirse en uno como tal."; ?></textarea>
            <button type="submit">Generar PDF de Consentimiento</button>
        </form>
    </div>
</body>
</html>
