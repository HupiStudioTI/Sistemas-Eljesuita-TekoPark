<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Proveedor</h3>
    <h5>Actualice los detalles del proveedor seleccionado.</h5>
</div>
</div>';
include 'encabezado.php';
include_once 'conexion.php';

// Obtener el ID del proveedor a editar
$id = $_GET['id'];
$sql = "SELECT * FROM proveedores WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$proveedor = $result->fetch_assoc();
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="actualizar_proveedor.php" method="post">
                <!-- Campo oculto para el ID -->
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($proveedor['id']); ?>">

                <div class="row">
                    <!-- Nombre del Proveedor -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input type="text" class="form-control form-control-sm" name="nombre" id="nombre" value="<?php echo htmlspecialchars($proveedor['nombre']); ?>" required>
                    </div>
                    <!-- Nombre Fantasía -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre_fantasia" class="form-label" style="font-size: 0.9rem;">Nombre Fantasía</label>
                        <input type="text" class="form-control form-control-sm" name="nombre_fantasia" id="nombre_fantasia" value="<?php echo htmlspecialchars($proveedor['nombre_fantasia']); ?>">
                    </div>
                </div>
                <div class="row">
                    <!-- Dirección -->
                    <div class="col-md-6 mb-3">
                        <label for="direccion" class="form-label" style="font-size: 0.9rem;">Dirección</label>
                        <input type="text" class="form-control form-control-sm" name="direccion" id="direccion" value="<?php echo htmlspecialchars($proveedor['direccion']); ?>">
                    </div>
                    <!-- Ciudad -->
                    <div class="col-md-6 mb-3">
                        <label for="ciudad" class="form-label" style="font-size: 0.9rem;">Ciudad</label>
                        <input type="text" class="form-control form-control-sm" name="ciudad" id="ciudad" value="<?php echo htmlspecialchars($proveedor['ciudad']); ?>">
                    </div>
                </div>
                <div class="row">
                    <!-- Teléfono -->
                    <div class="col-md-4 mb-3">
                        <label for="telefono" class="form-label" style="font-size: 0.9rem;">Teléfono</label>
                        <input type="text" class="form-control form-control-sm" name="telefono" id="telefono" value="<?php echo htmlspecialchars($proveedor['telefono']); ?>">
                    </div>
                    <!-- Email -->
                    <div class="col-md-4 mb-3">
                        <label for="email" class="form-label" style="font-size: 0.9rem;">Email</label>
                        <input type="email" class="form-control form-control-sm" name="email" id="email" value="<?php echo htmlspecialchars($proveedor['email']); ?>">
                    </div>
                    <!-- Número de Documento -->
                    <div class="col-md-4 mb-3">
                        <label for="nrodocumento" class="form-label" style="font-size: 0.9rem;">Nro de Documento</label>
                        <input type="text" class="form-control form-control-sm" name="nrodocumento" id="nrodocumento" value="<?php echo htmlspecialchars($proveedor['nrodocumento']); ?>">
                    </div>
                </div>
                <!-- Botón de Actualizar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-warning btn-sm">Actualizar Proveedor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
