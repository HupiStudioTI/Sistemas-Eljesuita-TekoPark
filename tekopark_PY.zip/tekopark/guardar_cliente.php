<?php
include_once "funciones.php";
$ok = agregarCliente($_POST["nombre"], $_POST["documento"], $_POST["fechanac"], $_POST["edad"], $_POST["sexo"], $_POST["ciudad"], $_POST["departamento"], $_POST["tel"], $_POST["email"], $_POST["padre"], $_POST["docpadre"], $_POST["telpadre"], $_POST["obs"]);
if (!$ok) {
    echo "Error registrando.";
} else {
    header("Location: clientes.php");
}
