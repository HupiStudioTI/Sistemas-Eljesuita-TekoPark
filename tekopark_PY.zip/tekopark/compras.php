<?php
$contenido = '<div class="row mx-0 text-center">
  <div class="col-12 mb-4">
      <h3 style="color: #ff5722;">Gestión de Compras</h3>
      <h5>Administre aquí las compras y actualice el stock de productos.</h5>
  </div>
</div>';
include 'encabezado.php';
include_once 'funciones.php';

// Se obtiene un listado plano de todos los detalles de compra (desde 2000 hasta hoy)
$detalleCompras = obtenerDetalleCompras('2000-01-01', date('Y-m-d'));
?>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="agregar_compra.php" class="btn btn-success btn-sm">Agregar Compra</a>
        <a href="informe_compras.php" class="btn btn-primary btn-sm">Informe de Compras</a>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-sm">
            <thead class="table-light">
                <tr>
                    <th>ID Compra</th>
                    <th>Proveedor</th>
                    <th>Fecha</th>
                    <th>Nro. Factura</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if (!empty($detalleCompras)) {
                    $ultimoCompra = null;
                    foreach ($detalleCompras as $row) {
                        // Solo se muestra una fila por cada compra
                        if ($ultimoCompra !== $row['compra_id']) {
                            echo '<tr>';
                            echo '<td>' . $row['compra_id'] . '</td>';
                            echo '<td>' . htmlspecialchars($row['proveedor']) . '</td>';
                            echo '<td>' . $row['fecha'] . '</td>';
                            echo '<td>' . htmlspecialchars($row['nro_factura']) . '</td>';
                            echo '<td>';
                            echo '<a href="#" class="btn btn-danger btn-sm" onclick="confirmarEliminacion(' . $row['compra_id'] . ')">Eliminar</a>';
                            echo '</td>';
                            echo '</tr>';
                            $ultimoCompra = $row['compra_id'];
                        }
                    }
                } else {
                    echo '<tr><td colspan="5" class="text-center">No hay compras registradas.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal de confirmación para eliminar compra -->
<div class="modal fade" id="modalEliminarCompra" tabindex="-1" aria-labelledby="modalEliminarLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="modalEliminarLabel">Confirmar Eliminación</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        ¿Estás seguro de que deseas eliminar esta compra? Esta acción no se puede deshacer.
      </div>
      <div class="modal-footer">
        <form id="formEliminarCompra" action="eliminar_compra.php" method="GET">
          <input type="hidden" name="id" id="compra_id_eliminar">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
function confirmarEliminacion(id) {
    document.getElementById('compra_id_eliminar').value = id;
    var modal = new bootstrap.Modal(document.getElementById('modalEliminarCompra'));
    modal.show();
}
</script>

<?php include 'footer.php'; ?>
