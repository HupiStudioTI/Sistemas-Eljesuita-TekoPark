<?php
include_once "conexion.php";
include_once "funciones.php";

// Se espera que en conexion.php se defina la variable $conn
if (isset($_GET["id"])) {
    $id = intval($_GET["id"]);
    $sql = "DELETE FROM proveedores WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Error en la preparación de la consulta: " . $conn->error;
        exit;
    }
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: proveedores.php");
        exit;
    } else {
        echo "Error al eliminar el proveedor: " . $stmt->error;
    }
} else {
    echo "No se especificó un proveedor a eliminar.";
}
?>
