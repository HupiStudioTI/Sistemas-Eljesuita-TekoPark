<?php
include_once 'funciones.php';

// Verificar que se ha pasado un ID
if (!isset($_GET['id'])) {
    die('ID de tarifa no proporcionado.');
}

$id = $_GET['id'];
$conn = obtenerBD();
$query = $conn->prepare("SELECT * FROM tarifas WHERE id = :id");
$query->bindParam(':id', $id, PDO::PARAM_INT);
$query->execute();
$tarifa = $query->fetch(PDO::FETCH_ASSOC);

// Verificar que se encontró la tarifa
if (!$tarifa) {
    die('Tarifa no encontrada.');
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tarifa</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Tarifa</h3>
</div>
</div>';
include_once "encabezado.php"; 
?>
<div class="container mt-5">
    <form action="actualizar_tarifa.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $tarifa['id']; ?>">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="actividad" class="form-label" style="font-weight: bold;">Actividad</label>
                <input type="text" name="actividad" class="form-control form-control-sm" id="actividad" value="<?php echo htmlspecialchars($tarifa['actividad']); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="nombretarifa" class="form-label" style="font-weight: bold;">Nombre de la Tarifa</label>
                <input type="text" name="nombretarifa" class="form-control form-control-sm" id="nombretarifa" value="<?php echo htmlspecialchars($tarifa['nombretarifa']); ?>" required>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="dias" class="form-label" style="font-weight: bold;">Días</label>
                <input type="text" name="dias" class="form-control form-control-sm" id="dias" value="<?php echo htmlspecialchars($tarifa['dias']); ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="duracion" class="form-label" style="font-weight: bold;">Duración</label>
                <select name="duracion" class="form-select form-select-sm" id="duracion" required>
                    <option value="30" <?php if ($tarifa['duracion'] == 30) echo 'selected'; ?>>30 Minutos</option>
                    <option value="60" <?php if ($tarifa['duracion'] == 60) echo 'selected'; ?>>1 Hora</option>
                    <option value="90" <?php if ($tarifa['duracion'] == 90) echo 'selected'; ?>>1 Hora y Media</option>
                    <option value="120" <?php if ($tarifa['duracion'] == 120) echo 'selected'; ?>>2 Horas</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="precio" class="form-label" style="font-weight: bold;">Precio</label>
                <input type="number" step="1" name="precio" class="form-control form-control-sm" id="precio" value="<?php echo $tarifa['precio']; ?>" required>
            </div>
        </div>
        <div class="form-group text-center">
            <button type="submit" class="btn btn-success btn-sm">Guardar Tarifa</button>
        </div>
    </form>
</div>
<?php include_once "footer.php"; ?>
<script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>
