<?php
include_once "conexion.php";
include_once "funciones.php";

// Se espera que en conexion.php se defina la variable $conn
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recoger datos del formulario
    $id = $_POST["id"] ?? '';
    $nombre = trim($_POST["nombre"] ?? '');
    $nombre_fantasia = trim($_POST["nombre_fantasia"] ?? '');
    $direccion = trim($_POST["direccion"] ?? '');
    $ciudad = trim($_POST["ciudad"] ?? '');
    $telefono = trim($_POST["telefono"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $nrodocumento = trim($_POST["nrodocumento"] ?? '');
    
    if (empty($id) || empty($nombre)) {
        echo "Error: Faltan datos obligatorios.";
        exit;
    }
    
    $sql = "UPDATE proveedores 
            SET nombre = ?, 
                nombre_fantasia = ?, 
                direccion = ?, 
                ciudad = ?, 
                telefono = ?, 
                email = ?, 
                nrodocumento = ? 
            WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Error en la preparación de la consulta: " . $conn->error;
        exit;
    }
    $stmt->bind_param("sssssssi", $nombre, $nombre_fantasia, $direccion, $ciudad, $telefono, $email, $nrodocumento, $id);
    if ($stmt->execute()) {
        header("Location: proveedores.php");
        exit;
    } else {
        echo "Error al actualizar el proveedor: " . $stmt->error;
    }
}
?>
