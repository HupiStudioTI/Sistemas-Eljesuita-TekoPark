<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Agregar Tarifa</h3>
    <h5>Ingrese la información de la nueva tarifa.</h5>
</div>
</div>';
include_once "encabezado.php";
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="guardar_tarifa.php" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="actividad" class="form-label">Actividad</label>
                        <input type="text" name="actividad" class="form-control form-control-sm" id="actividad" placeholder="Actividad" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nombretarifa" class="form-label">Nombre de la Tarifa</label>
                        <input type="text" name="nombretarifa" class="form-control form-control-sm" id="nombretarifa" placeholder="Nombre de la Tarifa" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="dias" class="form-label">Días</label>
                        <input type="text" name="dias" class="form-control form-control-sm" id="dias" placeholder="Días (Ej: Lunes a Viernes)" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="duracion" class="form-label">Duración en minutos</label>
                        <select name="duracion" class="form-select form-select-sm" id="duracion" oninput="calcularHoraFin()" required>
                            <option value="30">30 Minutos</option>
                            <option value="60">1 Hora</option>
                            <option value="90">1 Hora y Media</option>
                            <option value="120">2 Horas</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="precio" class="form-label">Precio</label>
                        <input type="number" step="1" name="precio" class="form-control form-control-sm" id="precio" placeholder="Precio" required>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar Tarifa</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>