<?php
include_once "conexion.php";
$nombre = $_POST['nombre'];
$descuento = $_POST['descuento'];
$stmt = $conn->prepare("INSERT INTO bonificaciones (nombre, descuento) VALUES (?, ?)");
$stmt->bind_param("sd", $nombre, $descuento);
if ($stmt->execute()) {
    header("Location: bonificaciones.php");
} else {
    echo "Error: " . $stmt->error;
}
$stmt->close();
$conn->close();
?>
