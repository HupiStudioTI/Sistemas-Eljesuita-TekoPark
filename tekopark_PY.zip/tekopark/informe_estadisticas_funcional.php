<?php
require_once 'tcpdf/tcpdf.php';
include_once "funciones.php";

if (isset($_POST['fecha_hora_desde'], $_POST['fecha_hora_hasta'])) {
    $fecha_hora_desde = $_POST['fecha_hora_desde'];
    $fecha_hora_hasta = $_POST['fecha_hora_hasta'];

    $pdo = obtenerbd();

    // Consulta SQL ajustada para agrupar también por día
    $sql = "
        SELECT 
            DATE(v.fecha) AS dia,
            r.actividad,
            DATE_FORMAT(v.fecha, '%H:00') AS hora,
            SUM(r.cantidad_clientes) AS total_clientes,
            SUM(v.total) AS total_ventas
        FROM ventas v
        INNER JOIN reservas r ON v.reserva_id = r.id
        WHERE v.fecha >= :fecha_hora_desde
          AND v.fecha <= :fecha_hora_hasta
          AND r.estado = 'pagada'
        GROUP BY dia, r.actividad, hora
        ORDER BY dia, r.actividad, hora;
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':fecha_hora_desde' => $fecha_hora_desde,
        ':fecha_hora_hasta' => $fecha_hora_hasta
    ]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informe de Ventas por Día, Actividad y Hora</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"> <!-- Cambia a tu ruta local -->
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Informe de Ventas por Día, Actividad y Hora</h1>

    <!-- Formulario para ingresar rango de fechahora -->
    <form method="POST" action="">
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="fecha_hora_desde" class="form-label">Fecha y Hora Desde</label>
                <input type="datetime-local" name="fecha_hora_desde" class="form-control" 
                       value="<?php echo isset($fecha_hora_desde) ? $fecha_hora_desde : ''; ?>" required>
            </div>
            <div class="col-md-6">
                <label for="fecha_hora_hasta" class="form-label">Fecha y Hora Hasta</label>
                <input type="datetime-local" name="fecha_hora_hasta" class="form-control" 
                       value="<?php echo isset($fecha_hora_hasta) ? $fecha_hora_hasta : ''; ?>" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Generar Informe</button>
    </form>

    <?php if (isset($resultados) && !empty($resultados)): ?>
        <div class="card mt-4">
            <div class="card-body">
                <p><strong>Rango de Fechas:</strong> <?php echo date('d/m/Y H:i', strtotime($fecha_hora_desde)) . ' - ' . date('d/m/Y H:i', strtotime($fecha_hora_hasta)); ?></p>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Día</th>
                                <th>Actividad</th>
                                <th>Hora</th>
                                <th>Total Clientes</th>
                                <th>Total Ventas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $dia_actual = null;
                            $actividad_actual = null;
                            $subtotal_dia_clientes = 0;
                            $subtotal_dia_ventas = 0;

                            foreach ($resultados as $row): 
                                if ($dia_actual !== $row['dia']):
                                    if ($dia_actual !== null): ?>
                                        <!-- Subtotales por día -->
                                        <tr class="table-warning">
                                            <td colspan="3"><strong>Subtotal para el Día <?php echo $dia_actual; ?></strong></td>
                                            <td><strong><?php echo $subtotal_dia_clientes; ?></strong></td>
                                            <td><strong>$<?php echo number_format($subtotal_dia_ventas, 2); ?></strong></td>
                                        </tr>
                                    <?php 
                                    endif;

                                    // Reiniciar subtotales y actualizar día actual
                                    $subtotal_dia_clientes = 0;
                                    $subtotal_dia_ventas = 0;
                                    $dia_actual = $row['dia'];
                                    ?>
                                    <!-- Mostrar el nuevo día -->
                                    <tr class="table-primary">
                                        <td colspan="5"><strong><?php echo date('d/m/Y', strtotime($dia_actual)); ?></strong></td>
                                    </tr>
                                <?php 
                                endif;

                                if ($actividad_actual !== $row['actividad']):
                                    if ($actividad_actual !== null): ?>
                                        <!-- Subtotales por actividad -->
                                        <tr class="table-secondary">
                                            <td colspan="2"><strong>Subtotal para <?php echo $actividad_actual; ?></strong></td>
                                            <td><strong><?php echo $subtotal_clientes; ?></strong></td>
                                            <td><strong><?php echo $subtotal_ventas; ?></strong></td>
                                        </tr>
                                    <?php 
                                    endif;

                                    // Reiniciar subtotales de actividad
                                    $subtotal_clientes = 0;
                                    $subtotal_ventas = 0;
                                    $actividad_actual = $row['actividad']; 
                                    ?>
                                    <!-- Mostrar la nueva actividad -->
                                    <tr class="table-light">
                                        <td></td>
                                        <td colspan="4"><strong><?php echo $actividad_actual; ?></strong></td>
                                    </tr>
                                <?php 
                                endif;

                                // Acumular subtotales
                                $subtotal_clientes += $row['total_clientes'];
                                $subtotal_ventas += $row['total_ventas'];
                                $subtotal_dia_clientes += $row['total_clientes'];
                                $subtotal_dia_ventas += $row['total_ventas'];
                                ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo $row['hora']; ?></td>
                                    <td><?php echo $row['total_clientes']; ?></td>
                                    <td>$<?php echo number_format($row['total_ventas'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <!-- Subtotales finales -->
                            <tr class="table-warning">
                                <td colspan="3"><strong>Subtotal para el Día <?php echo $dia_actual; ?></strong></td>
                                <td><strong><?php echo $subtotal_dia_clientes; ?></strong></td>
                                <td><strong>$<?php echo number_format($subtotal_dia_ventas, 2); ?></strong></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3">Total General</th>
                                <th><?php echo array_sum(array_column($resultados, 'total_clientes')); ?></th>
                                <th>$<?php echo number_format(array_sum(array_column($resultados, 'total_ventas')), 2); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
