<?php
include_once "conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM bonificaciones WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: bonificaciones.php");
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
