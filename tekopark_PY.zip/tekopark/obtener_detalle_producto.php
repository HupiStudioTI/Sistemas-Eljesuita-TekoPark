<?php
include_once "funciones.php";

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $pdo = obtenerBD();
    $stmt = $pdo->prepare("SELECT stock, costo, unidad_medida frOM productos WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode($producto);
}
?>
