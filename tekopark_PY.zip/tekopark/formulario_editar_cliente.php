<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Cliente</h3>
</div>
</div>';
include_once "encabezado.php";
include_once "funciones.php";
$cliente = obtenerClientePorId($_GET["id"]);
$departamentos = obtenerDepartamentos();
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="actualizar_cliente.php" method="post">
                <input type="hidden" name="id" value="<?php echo $cliente->id ?>">
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input value="<?php echo $cliente->nombre ?>" required type="text" class="form-control form-control-sm" name="nombre" id="nombre" placeholder="Nombre">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="documento" class="form-label" style="font-size: 0.9rem;">Nº Documento</label>
                        <input value="<?php echo $cliente->documento ?>" required type="text" class="form-control form-control-sm" name="documento" id="documento" readonly>
                    </div>
                    <div class="col-md-2 mb-2">
                        <label for="fechanac" class="form-label" style="font-size: 0.9rem;">Fecha Nac.</label>
                        <input value="<?php echo $cliente->fechanac ?>" required type="date" class="form-control form-control-sm" name="fechanac" id="fechanac">
                    </div>
                    <div class="col-md-1 mb-2">
                        <label for="edad" class="form-label" style="font-size: 0.9rem;">Edad</label>
                        <span id="edad"><?php echo htmlspecialchars($cliente->edad); ?></span>
                        <input type="hidden" name="edad" id="hiddenEdad" value="<?php echo htmlspecialchars($cliente->edad); ?>">
                    </div>
                    <div class="col-md-1 mb-2">
                        <label for="sexo" class="form-label" style="font-size: 0.9rem;">Sexo</label>
                        <select name="sexo" id="sexo" class="form-control form-control-sm">
                            <option value="Masculino" <?php echo $cliente->sexo === 'Masculino' ? 'selected' : ''; ?>>Masculino</option>
                            <option value="Femenino" <?php echo $cliente->sexo === 'Femenino' ? 'selected' : ''; ?>>Femenino</option>
                            <option value="Sin Datos" <?php echo $cliente->sexo === 'Sin Datos' ? 'selected' : ''; ?>>Sin Datos</option>
                            <option value="Otro" <?php echo $cliente->sexo === 'Otro' ? 'selected' : ''; ?>>Otro</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <label for="departamento" class="form-label" style="font-size: 0.9rem;">Actividad</label>
                        <select class="form-control form-control-sm" name="departamento" id="departamento">
                            <?php foreach ($departamentos as $departamento) { ?>
                                <option <?php echo $departamento === $cliente->departamento ? 'selected' : ''; ?> value="<?php echo $departamento ?>"><?php echo $departamento ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="ciudad" class="form-label" style="font-size: 0.9rem;">Ciudad</label>
                        <input value="<?php echo $cliente->ciudad ?>" required type="text" class="form-control form-control-sm" name="ciudad" id="ciudad" placeholder="Ciudad">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="tel" class="form-label" style="font-size: 0.9rem;">Tel. / Whatsapp</label>
                        <input value="<?php echo $cliente->telefono ?>" required type="text" class="form-control form-control-sm" name="tel" id="tel" placeholder="Nº Tel. o Whatsapp">
                    </div>
                    <div class="col-md-3 mb-2">
                        <label for="email" class="form-label" style="font-size: 0.9rem;">Email</label>
                        <input value="<?php echo $cliente->email ?>" required type="email" class="form-control form-control-sm" name="email" id="email" readonly>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <label for="padre" class="form-label" style="font-size: 0.9rem;">Padre/Tutor</label>
                        <input value="<?php echo $cliente->padre ?>" type="text" class="form-control form-control-sm" name="padre" id="padre" placeholder="Nombre del Padre o Tutor">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="docpadre" class="form-label" style="font-size: 0.9rem;">Doc. Padre/Tutor</label>
                        <input value="<?php echo $cliente->docpadre ?>" type="text" class="form-control form-control-sm" name="docpadre" id="docpadre" placeholder="Doc. del Padre o Tutor">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label for="telpadre" class="form-label" style="font-size: 0.9rem;">Tel. Padre/Tutor</label>
                        <input value="<?php echo $cliente->telpadre ?>" type="text" class="form-control form-control-sm" name="telpadre" id="telpadre" placeholder="Nº Tel. o Whatsapp">
                    </div>
                </div>
                <div class="form-group mb-2">
                    <label for="obs" class="form-label" style="font-size: 0.9rem;">Observaciones</label>
                    <input value="<?php echo $cliente->obs ?>" type="text" class="form-control form-control-sm" name="obs" id="obs" placeholder="Observaciones">
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success btn-sm">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    function calcularEdad(fechaNacimiento) {
        const hoy = new Date();
        const nacimiento = new Date(fechaNacimiento);
        let edad = hoy.getFullYear() - nacimiento.getFullYear();
        const mes = hoy.getMonth() - nacimiento.getMonth();
        if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
            edad--;
        }
        return edad;
    }

    $('#fechanac').on('change', function() {
        const edad = calcularEdad(this.value);
        $('#edad').text(edad);
        $('#hiddenEdad').val(edad);
    });
});
</script>
<?php include "footer.php"; ?>
