<?php
header('Content-Type: application/json');

include_once "conexion.php"; // Asegúrate de incluir tu archivo de conexión a la base de datos

$documento = isset($_POST['documento']) ? $_POST['documento'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';

$existe = false;

// Verificar si el número de documento ya existe
if (!empty($documento)) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM clientes WHERE documento = ?");
    $stmt->bind_param("s", $documento);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    if ($count > 0) {
        $existe = true;
    }
    $stmt->close();
}

// Verificar si el email ya existe
if (!$existe && !empty($email)) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    if ($count > 0) {
        $existe = true;
    }
    $stmt->close();
}

echo json_encode(['exists' => $existe]);
$conn->close();
?>
