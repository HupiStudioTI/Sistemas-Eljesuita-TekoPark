<?php
ob_start();  // Inicia buffering de salida
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include_once "encabezado.php";    // Asegúrate de que este archivo no genere salida extra
include_once "conexion.php";      // Se asume que obtenerBD() devuelve una instancia PDO
include_once "funciones.php";

// Variables iniciales
$fechaActual = date("Y-m-d");
$horaActual  = date("H:i");
$codigo_reserva_generado = generarCodigoReserva();
// Día actual ('lun','mar',…)
$diaCodigoActual = ['lun','mar','mie','jue','vie','sab','dom'][date('N') - 1];

// Definir el vendedor fijo (ej. id 1 y nombre "Tekopark")
$vendedor_fijo_id = 1;

// Definir el cliente genérico para clientes ocasionales (se supone que en la tabla clientes existe un registro con id 1 que representa "Cliente Ocasional")
$cliente_ocasional_id = 1;

error_log("Inicio del procesamiento de formulario Reserva y Venta.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Datos de la reserva (el campo codigo_reserva se envía de forma oculta)
    $codigo_reserva    = isset($_POST["codigo_reserva"]) ? trim($_POST["codigo_reserva"]) : '';
    $tarifa_id_temp    = isset($_POST["tarifa_id"]) ? intval($_POST["tarifa_id"]) : 0;
    // Si no se seleccionó tarifa (valor 0 o menor), asignar NULL
    $tarifa_id = ($tarifa_id_temp > 0) ? $tarifa_id_temp : null;
    $fecha_reserva     = isset($_POST["fecha_reserva"]) ? trim($_POST["fecha_reserva"]) : $fechaActual;
    $hora_desde        = isset($_POST["hora_desde"]) ? trim($_POST["hora_desde"]) : $horaActual;
    $hora_hasta        = isset($_POST["hora_hasta"]) ? trim($_POST["hora_hasta"]) : '';
    $cantidad_clientes = isset($_POST["cantidad_clientes"]) ? intval($_POST["cantidad_clientes"]) : 0;
    $estado            = isset($_POST["estado"]) ? trim($_POST["estado"]) : 'pendiente';

    error_log("Datos de reserva recibidos: Código: $codigo_reserva, Tarifa: " . ($tarifa_id===null ? "NULL" : $tarifa_id) . ", Fecha: $fecha_reserva, Hora desde: $hora_desde");

    // 2. Datos de clientes asociados (para venta de servicio)
    $cliente_ids     = isset($_POST['clientes']) ? $_POST['clientes'] : [];
    $cliente_nombres = isset($_POST['cliente_nombres']) ? $_POST['cliente_nombres'] : [];
    $identificaciones = isset($_POST['identificaciones']) ? $_POST['identificaciones'] : [];
    $pulseras         = isset($_POST['pulseras']) ? $_POST['pulseras'] : [];

    // 3. Datos de venta
    $subtotal_tarifa   = isset($_POST["subtotal_tarifa"]) ? floatval(str_replace('.', '', $_POST["subtotal_tarifa"])) : 0;
    $productos_json    = isset($_POST["productos"]) ? $_POST["productos"] : "[]";
    $productos         = json_decode($productos_json, true);
    $bonificacion_id   = isset($_POST["bonificacion"]) ? intval($_POST["bonificacion"]) : 0;
    $modo_pago         = isset($_POST["modo_pago"]) ? trim($_POST["modo_pago"]) : '';
    $color             = isset($_POST["color"]) ? trim($_POST["color"]) : '';
    // Se asigna el vendedor fijo
    $colaborador_id    = $vendedor_fijo_id;

    // Asignación automática de la actividad:
    // Si se selecciona una tarifa, se asume venta de servicio ("Cama Elastica"); de lo contrario, "Otros"
    $actividad = (!is_null($tarifa_id)) ? "Cama Elastica" : "Otros";

    error_log("Datos de venta recibidos: Subtotal tarifa: $subtotal_tarifa, Colaborador: $colaborador_id, Actividad: $actividad");

    // 4. Validaciones
    $errores = [];
    // Se valida que exista tarifa o que se hayan agregado productos
    if (is_null($tarifa_id) && empty($productos)) {
        $errores[] = "La tarifa es obligatoria o debe agregar productos.";
    }
    if (!is_null($tarifa_id)) {
        if ($cantidad_clientes <= 0)
            $errores[] = "La cantidad de clientes debe ser al menos 1.";
        // Se verifica que el número de clientes, nombres, identificaciones y pulseras coincida
        if (count($cliente_ids) != $cantidad_clientes || count($cliente_nombres) != $cantidad_clientes || count($identificaciones) != $cantidad_clientes || count($pulseras) != $cantidad_clientes)
            $errores[] = "El número de clientes, nombres, identificaciones o pulseras no coincide con la cantidad especificada.";
    }
    if (empty($codigo_reserva))
        $errores[] = "El código de reserva es obligatorio.";
    if (codigoReservaExiste($codigo_reserva))
        $errores[] = "El código de reserva ya existe. Por favor, genere uno único.";

    if (!empty($errores)) {
        error_log("Errores en validación: " . implode(" ", $errores));
        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => implode(" ", $errores)]);
        exit();
    }

    try {
        // Iniciar transacción
        $bd = obtenerBD();
        $bd->beginTransaction();
        error_log("Transacción iniciada.");

        // 5. Insertar la reserva (se guarda la actividad asignada automáticamente)
        $reserva_id = agregarReserva($codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado);
        if (!$reserva_id) {
            throw new Exception("No se pudo insertar la reserva.");
        }
        error_log("Reserva insertada con ID: $reserva_id");

        // 6. Insertar clientes_reserva (solo para venta de servicio)
        if (!is_null($tarifa_id)) {
            if (!asociarClientesReserva($reserva_id, $cliente_ids, $identificaciones, $pulseras, $cliente_nombres)) {
                throw new Exception("No se pudieron asociar los clientes a la reserva.");
            }
            error_log("Clientes asociados a la reserva.");
        }

        // 7. Procesar la venta
        $usuario_id = $_SESSION['usuario']['id'];
        $bonificacion_importe = 0;
        if ($bonificacion_id) {
            $descuento = obtenerBonificacion($bonificacion_id);
            $bonificacion_importe = $subtotal_tarifa * ($descuento / 100);
        }
        $total_productos = 0;
        foreach ($productos as $prod) {
            $total_productos += $prod['cantidad'] * $prod['precio_unitario'];
        }
        $total_tarifa_con_descuento = $subtotal_tarifa - $bonificacion_importe;
        $total_venta = $total_tarifa_con_descuento + $total_productos;
        error_log("Venta procesada: Total productos: $total_productos, Total venta: $total_venta");

        // 8. Mapeo de colores (por defecto, si no coincide, se usa Blanco)
        $colores = [
            "Blanco"   => "#FFFFFF",
            "Plata"    => "#C0C0C0",
            "Verde"    => "#008000",
            "Rojo"     => "#FF0000",
            "Azul"     => "#0000FF",
            "Dorado"   => "#FFD700",
            "Amarillo" => "#FFFF00",
            "Naranja"  => "#FFA500",
            "Violeta"  => "#EE82EE"
        ];
        $color_value = isset($colores[$color]) ? $colores[$color] : "#FFFFFF";

        // 9. Insertar la venta en la tabla ventas (incluye usuario_id y el vendedor fijo)
        $sqlVenta = "INSERT INTO ventas (
                        reserva_id, 
                        codigo_reserva, 
                        usuario_id,
                        colaborador_id, 
                        bonificacion_id, 
                        bonificacion, 
                        totaltarifas,
                        totalproductos,
                        total, 
                        modo_pago, 
                        color,
                        color_value
                    ) VALUES (
                        :reserva_id, 
                        :codigo_reserva, 
                        :usuario_id,
                        :colaborador_id, 
                        :bonificacion_id, 
                        :bonificacion, 
                        :totaltarifas, 
                        :totalproductos, 
                        :total, 
                        :modo_pago,
                        :color,
                        :color_value
                    )";
        $stmtVenta = $bd->prepare($sqlVenta);
        $stmtVenta->execute([
            ':reserva_id'      => $reserva_id,
            ':codigo_reserva'  => $codigo_reserva,
            ':usuario_id'      => $usuario_id,
            ':colaborador_id'  => $colaborador_id,
            ':bonificacion_id' => $bonificacion_id,
            ':bonificacion'    => $bonificacion_importe,
            ':totaltarifas'    => $subtotal_tarifa,
            ':totalproductos'  => $total_productos,
            ':total'           => $total_venta,
            ':modo_pago'       => $modo_pago,
            ':color'           => $color,
            ':color_value'     => $color_value
        ]);
        $venta_id = $bd->lastInsertId();
        error_log("Venta insertada con ID: $venta_id");

        // 10. Insertar detalle de venta en detalle_ventas
        if (!empty($productos)) {
            foreach ($productos as $producto) {
                $producto_id     = $producto['id'];
                $cantidad        = $producto['cantidad'];
                $precio_unitario = $producto['precio_unitario'];
                $total_producto  = $cantidad * $precio_unitario;

                $sqlDetalle = "INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario, total)
                               VALUES (:venta_id, :producto_id, :cantidad, :precio_unitario, :total)";
                $stmtDetalle = $bd->prepare($sqlDetalle);
                $stmtDetalle->execute([
                    ':venta_id'       => $venta_id,
                    ':producto_id'    => $producto_id,
                    ':cantidad'       => $cantidad,
                    ':precio_unitario'=> $precio_unitario,
                    ':total'          => $total_producto
                ]);
                error_log("Detalle de venta insertado para producto ID: $producto_id");

                // Movimiento de stock y actualización
                $sqlMov = "INSERT INTO movimientos_stock (producto_id, cantidad, tipo_movimiento, fecha)
                           VALUES (:producto_id, :cantidad, 'venta', NOW())";
                $stmtMov = $bd->prepare($sqlMov);
                $stmtMov->execute([
                    ':producto_id' => $producto_id,
                    ':cantidad'    => $cantidad
                ]);
                error_log("Movimiento de stock insertado para producto ID: $producto_id");

                $sqlUpd = "UPDATE productos SET stock = stock - :cantidad WHERE id = :producto_id";
                $stmtUpd = $bd->prepare($sqlUpd);
                $stmtUpd->execute([
                    ':cantidad'    => $cantidad,
                    ':producto_id' => $producto_id
                ]);
                error_log("Stock actualizado para producto ID: $producto_id");

                // Si el producto tiene componentes, descontarlos
                $stmtComp = $bd->prepare("SELECT * FROM productos_componentes WHERE id_producto_principal = :prod");
                $stmtComp->execute([':prod' => $producto_id]);
                $componentesData = $stmtComp->fetchAll(PDO::FETCH_ASSOC);
                foreach ($componentesData as $comp) {
                    $idComp   = $comp['id_producto_componente'];
                    $cantComp = $cantidad * $comp['cantidad']; 
                    $sqlMovComp = "INSERT INTO movimientos_stock (producto_id, cantidad, tipo_movimiento, fecha)
                                   VALUES (:idComp, :cantComp, 'venta', NOW())";
                    $stmtMovComp = $bd->prepare($sqlMovComp);
                    $stmtMovComp->execute([
                        ':idComp'   => $idComp,
                        ':cantComp' => $cantComp
                    ]);
                    error_log("Movimiento de stock insertado para componente ID: $idComp, Cantidad: $cantComp");
                    
                    $sqlUpdComp = "UPDATE productos SET stock = stock - :cantComp WHERE id = :idComp";
                    $stmtUpdComp = $bd->prepare($sqlUpdComp);
                    $stmtUpdComp->execute([
                        ':cantComp' => $cantComp,
                        ':idComp'   => $idComp
                    ]);
                    error_log("Stock actualizado para componente ID: $idComp, Cantidad: $cantComp");
                }
            }
        }

        // 11. Insertar comisión en comisiones (5% sobre subtotal tarifa)
        $comision_porcentaje = 5;
        $comision = intval($subtotal_tarifa * ($comision_porcentaje / 100));
        $sqlComision = "INSERT INTO comisiones (colaborador_id, venta_id, comision) VALUES (:colaborador_id, :venta_id, :comision)";
        $stmtComision = $bd->prepare($sqlComision);
        $stmtComision->execute([
            ':colaborador_id' => $colaborador_id,
            ':venta_id'       => $venta_id,
            ':comision'       => $comision
        ]);
        error_log("Comisión insertada: $comision");

        // 12. Actualizar estado de la reserva a 'pagada'
        $sqlUpdateReserva = "UPDATE reservas SET estado = 'pagada' WHERE id = :id";
        $stmtUpdate = $bd->prepare($sqlUpdateReserva);
        $stmtUpdate->execute([':id' => $reserva_id]);
        error_log("Reserva actualizada a pagada.");

        $bd->commit();
        error_log("Transacción completada exitosamente.");

        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit();

    } catch (Exception $e) {
        $bd->rollBack();
        error_log("Error en transacción: " . $e->getMessage());
        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Reserva y Venta</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    <style>
        .input-bordered {
            border: 2px solid #ff5722;
            border-radius: 5px;
            padding: 5px;
        }
        /* Clase para resaltar el input de producto */
        .producto-visible {
            background-color: #ffffcc; /* Fondo amarillo claro */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h3 class="text-center" style="color: #ff5722;">Nueva Reserva y Venta</h3>
    <?php
// ——— Bloque IMPORTANTE: Monitoreo de jugadores activos ———
try {
    $bdMon   = obtenerBD();
    $stmtMon = $bdMon->query(
        "SELECT 
             COUNT(*) AS total_active,
             MIN(TIMESTAMPDIFF(SECOND, NOW(), hora_fin)) AS seconds_left
         FROM monitore 
         WHERE estado = 'en_juego'"
    );
    $monData = $stmtMon->fetch(PDO::FETCH_ASSOC);
    $activos = (int)$monData['total_active'];
    $segRest = (int)$monData['seconds_left'];
} catch (Exception $e) {
    $activos = 0;
    $segRest = 0;
}

$limite = 40;
if ($activos < $limite) {
    $libres = $limite - $activos;
    $alert  = "<strong>IMPORTANTE:</strong> Hay $activos jugadores activos. Quedan $libres espacios disponibles.";
} else {
    $h = floor($segRest/3600);
    $m = floor(($segRest%3600)/60);
    $s = $segRest % 60;
    $alert = "<strong>IMPORTANTE:</strong> Límite de $limite alcanzado. Próximo espacio en: "
           . sprintf('%02d:%02d:%02d',$h,$m,$s) . ".";
}

echo '<div class="alert alert-warning text-center">'.$alert.'</div>';
// ——————————————————————————————————————————————————————————
?>

    <form id="ventaForm" action="formulario_reserva_ventas.php" method="POST">
        <!-- Campo oculto para el código de reserva -->
        <input type="hidden" name="codigo_reserva" value="<?php echo isset($_POST['codigo_reserva']) ? htmlspecialchars($_POST['codigo_reserva']) : htmlspecialchars($codigo_reserva_generado); ?>">
        
        <!-- Fila: Tarifa, Fecha, Hora Desde y Hora Hasta -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="tarifa_id" class="form-label">Tarifa</label>
                <select id="tarifa_id" name="tarifa_id" class="form-select form-select-sm input-bordered">
                    <option value="">Seleccione una tarifa</option>
                    <?php
                    //$tarifas = obtenerTarifas();
                    $tarifas = obtenerTarifasPorDia($diaCodigoActual);
                    foreach ($tarifas as $tarifa) {
                        $selected = (isset($_POST['tarifa_id']) && $_POST['tarifa_id'] == $tarifa->id) ? 'selected' : '';
                        $precio_formateado = number_format($tarifa->precio, 0, ',', '.');
                        echo "<option value=\"" . htmlspecialchars($tarifa->id) . "\" data-precio=\"" . htmlspecialchars($tarifa->precio) . "\" data-duracion=\"" . htmlspecialchars($tarifa->duracion) . "\" {$selected}>"
                             . htmlspecialchars("{$tarifa->actividad} - {$tarifa->nombretarifa} ({$tarifa->dias}) - {$tarifa->duracion} min - \$$precio_formateado")
                             . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="fecha_reserva" class="form-label">Fecha de Reserva</label>
                <input type="date" name="fecha_reserva" class="form-control form-control-sm input-bordered" id="fecha_reserva"
                       value="<?php echo isset($_POST['fecha_reserva']) ? htmlspecialchars($_POST['fecha_reserva']) : $fechaActual; ?>" required>
            </div>
            <div class="col-md-3">
                <label for="hora_desde" class="form-label">Hora Desde</label>
                <input type="time" name="hora_desde" class="form-control form-control-sm input-bordered" id="hora_desde"
                       value="<?php echo isset($_POST['hora_desde']) ? htmlspecialchars($_POST['hora_desde']) : $horaActual; ?>" required>
            </div>
            <div class="col-md-3">
                <label for="hora_hasta" class="form-label">Hora Hasta</label>
                <input type="time" name="hora_hasta" class="form-control form-control-sm input-bordered" id="hora_hasta"
                       value="<?php echo isset($_POST['hora_hasta']) ? htmlspecialchars($_POST['hora_hasta']) : ''; ?>">
            </div>
        </div>
        <!-- Fila: Cantidad de Clientes y Estado -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="cantidad_clientes" class="form-label">Cantidad de Clientes</label>
                <input type="number" name="cantidad_clientes" class="form-control form-control-sm input-bordered" id="cantidad_clientes"
                       value="<?php echo isset($_POST['cantidad_clientes']) ? htmlspecialchars($_POST['cantidad_clientes']) : ''; ?>" min="0">
            </div>
            <div class="col-md-3">
                <label for="estado" class="form-label">Estado</label>
                <select id="estado" name="estado" class="form-select form-select-sm input-bordered" required>
                    <?php
                    $estados = ['pendiente', 'pagada', 'cancelada'];
                    foreach ($estados as $estado_option) {
                        $selected = (isset($_POST['estado']) && $_POST['estado'] === $estado_option) ? 'selected' : '';
                        echo "<option value=\"" . htmlspecialchars($estado_option) . "\" {$selected}>" . ucfirst(htmlspecialchars($estado_option)) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <!-- Fila: Clientes Asociados (para venta de servicio) -->
        <div id="clientes_container">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['clientes'])) {
                $cantidad = count($_POST['clientes']);
                for ($i = 0; $i < $cantidad; $i++) {
                    $cliente_valor = isset($_POST['cliente_nombres'][$i]) ? htmlspecialchars($_POST['cliente_nombres'][$i]) : 'Cliente Ocasional';
                    $cliente_id = $_POST['clientes'][$i];
                    $identificacion = isset($_POST['identificaciones'][$i]) ? htmlspecialchars($_POST['identificaciones'][$i]) : '';
                    $pulsera = isset($_POST['pulseras'][$i]) ? htmlspecialchars($_POST['pulseras'][$i]) : '';
                    echo "
                    <div class='row mb-3'>
                        <div class='col-md-4'>
                            <label class='form-label'>Cliente " . ($i+1) . "</label>
                            <input type='text' name='cliente_nombres[]' class='form-control form-control-sm input-bordered cliente_search_occasional' value='$cliente_valor'>
                            <input type='hidden' name='clientes[]' class='cliente_id_occasional' value='$cliente_id'>
                        </div>
                        <div class='col-md-3'>
                            <label for='identificacion_" . ($i+1) . "' class='form-label'>Identificación</label>
                            <input type='text' name='identificaciones[]' class='form-control form-control-sm input-bordered' id='identificacion_" . ($i+1) . "' value='$identificacion' required>
                        </div>
                        <div class='col-md-2'>
                            <label for='pulsera_" . ($i+1) . "' class='form-label'>Pulsera</label>
                            <input type='text' name='pulseras[]' class='form-control form-control-sm input-bordered' id='pulsera_" . ($i+1) . "' value='$pulsera' required>
                        </div>
                    </div>";
                }
            }
            ?>
        </div>
        <!-- Fila: Datos de Venta (Subtotal Tarifa, Bonificación, Modo de Pago y Color) -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label for="subtotal_tarifa" class="form-label">Subtotal Tarifa</label>
                <input type="text" name="subtotal_tarifa" id="subtotal_tarifa" class="form-control form-control-sm input-bordered" placeholder="Ej: 12000" required>
            </div>
            <div class="col-md-3">
                <label for="bonificacion" class="form-label">Bonificación</label>
                <select id="bonificacion" name="bonificacion" class="form-select form-select-sm input-bordered">
                    <?php
                    $bonificaciones = obtenerBonificaciones();
                    foreach ($bonificaciones as $b) {
                        $selected = (strtoupper($b->nombre) === 'NINGUNA') ? 'selected' : '';
                        echo "<option value=\"" . htmlspecialchars($b->id) . "\" data-descuento=\"" . htmlspecialchars($b->descuento) . "\" $selected>" . htmlspecialchars($b->nombre) . " (" . htmlspecialchars($b->descuento) . "%)</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="modo_pago" class="form-label">Modo de Pago</label>
                <select id="modo_pago" name="modo_pago" class="form-select form-select-sm input-bordered" required>
                    <option value="EFECTIVO" selected>Efectivo</option>
                    <option value="TARJETA">Tarjeta</option>
                    <option value="QR">QR</option>
                    <option value="MERCADOPAGO">MercadoPago</option>
                    <option value="CANJE">Canje</option>
                    <option value="OTROS">Otros</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="color" class="form-label">Color</label>
                <select id="color" name="color" class="form-select form-select-sm input-bordered" required>
                    <?php
                    $colores = [
                        "Blanco"   => "#FFFFFF",
                        "Plata"    => "#C0C0C0",
                        "Verde"    => "#008000",
                        "Rojo"     => "#FF0000",
                        "Azul"     => "#0000FF",
                        "Dorado"   => "#FFD700",
                        "Amarillo" => "#FFFF00",
                        "Naranja"  => "#FFA500",
                        "Violeta"  => "#EE82EE"
                    ];
                    foreach ($colores as $nombre => $hex) {
                        $selected = ($nombre === "Blanco") ? 'selected' : '';
                        echo "<option value=\"" . htmlspecialchars($nombre) . "\" style='background-color: $hex; color: black;' $selected>" . htmlspecialchars($nombre) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <!-- Campo oculto para el vendedor fijo -->
        <input type="hidden" name="colaborador" value="<?php echo $vendedor_fijo_id; ?>">
        <!-- Fila: Sección de Productos -->
        <div class="card mb-3">
            <div class="card-header">Productos</div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="producto" class="form-label">Buscar Producto</label>
                        <!-- Se agregó la clase "producto-visible" para un fondo resaltado -->
                        <input type="text" id="producto" class="form-control form-control-sm input-bordered producto-visible" placeholder="Buscar producto...">
                    </div>
                    <div class="col-md-4 mt-3 mt-md-0">
                        <label for="cantidad_producto" class="form-label">Cantidad</label>
                        <input type="number" id="cantidad_producto" class="form-control form-control-sm" value="1" min="1">
                    </div>
                </div>
                <button type="button" id="agregar-producto" class="btn btn-primary btn-sm">Agregar Producto</button>
                <div class="table-responsive mt-3">
                    <table class="table table-sm table-striped table-bordered table-custom-sm">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Precio Unitario ($)</th>
                                <th>Total ($)</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="productos-list">
                            <!-- Se agregarán los productos -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Fila: Total General de la Venta -->
        <div class="text-center mb-3">
            <h4>Total Venta: $<span id="total-venta">0</span></h4>
        </div>
        <!-- Botón de Envío -->
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-sm">Guardar Reserva y Venta</button>
        </div>
    </form>
</div>
<?php include_once "footer.php"; ?>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {

    // Al cargar, si no hay tarifa seleccionada, se deshabilita la cantidad de clientes y se oculta el contenedor de clientes.
    if ($('#tarifa_id').val() === "") {
        $('#cantidad_clientes').val(0).prop('disabled', true);
        $('#clientes_container').hide();
        $('#subtotal_tarifa').val(0);
    } else {
        $('#cantidad_clientes').prop('disabled', false);
        $('#clientes_container').show();
    }

    // Cuando cambia la tarifa
    $('#tarifa_id').on('change', function() {
        calcularHoraHasta();

        if ($(this).val() === "") {
            // No se ha seleccionado tarifa: deshabilitar y ocultar datos de clientes
            $('#cantidad_clientes').val(0).prop('disabled', true);
            $('#clientes_container').empty().hide();
            $('#subtotal_tarifa').val(0);
        } else {
            // Tarifa seleccionada: habilitar y mostrar los campos de clientes
            $('#cantidad_clientes').prop('disabled', false).val('');
            $('#clientes_container').show();
        }
        calcularSubtotalTarifa();
    });

    function calcularHoraHasta() {
        const duracionTarifa = $('#tarifa_id').find(':selected').data('duracion');
        const horaDesde = $('#hora_desde').val();
        if (duracionTarifa && horaDesde) {
            let [hours, minutes] = horaDesde.split(':');
            let date = new Date();
            date.setHours(parseInt(hours), parseInt(minutes), 0);
            date.setMinutes(date.getMinutes() + parseInt(duracionTarifa));
            let horaHasta = date.toTimeString().split(':').slice(0,2).join(':');
            $('#hora_hasta').val(horaHasta);
        } else {
            $('#hora_hasta').val('');
        }
    }

    function calcularSubtotalTarifa() {
        let tarifaOption = $("#tarifa_id").find("option:selected");
        let precio = parseInt(tarifaOption.data("precio")) || 0;
        let cantidadClientes = parseInt($("#cantidad_clientes").val()) || 0;
        let subtotal = precio * cantidadClientes;
        $("#subtotal_tarifa").val(subtotal.toFixed(0));
        calcularTotal();
    }
    $("#tarifa_id, #cantidad_clientes").on("change", calcularSubtotalTarifa);

    // Generar los campos de clientes según la cantidad ingresada
    $('#cantidad_clientes').on('change', function() {
        let cantidad = parseInt($(this).val());
        let container = $('#clientes_container');
        container.empty();
        if (!isNaN(cantidad) && cantidad > 0) {
            for (let i = 1; i <= cantidad; i++) {
                container.append(`
                    <div class='row mb-3'>
                        <div class='col-md-4'>
                            <label class='form-label'>Cliente ${i}</label>
                            <input type='text' name='cliente_nombres[]' class='form-control form-control-sm input-bordered cliente_search_occasional' value="Cliente Ocasional">
                            <input type='hidden' name='clientes[]' class='cliente_id_occasional' value="1">
                        </div>
                        <div class='col-md-3'>
                            <label for='identificacion_${i}' class='form-label'>Identificación</label>
                            <input type='text' name='identificaciones[]' class='form-control form-control-sm input-bordered' id='identificacion_${i}' placeholder="Ej: 1234" required>
                        </div>
                        <div class='col-md-2'>
                            <label for='pulsera_${i}' class='form-label'>Pulsera</label>
                            <input type='text' name='pulseras[]' class='form-control form-control-sm input-bordered' id='pulsera_${i}' placeholder="Ej: A123" required>
                        </div>
                    </div>
                `);
            }
            // Activar autocomplete para cada campo de cliente ocasional
            $(".cliente_search_occasional").autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: "buscar_clientes_reservas.php",
                        method: "GET",
                        dataType: "json",
                        data: { query: request.term },
                        success: function(data) {
                            response($.map(data, function(item) {
                                return { label: item.label, value: item.label, id: item.value };
                            }));
                        },
                        error: function() {
                            response([]);
                        }
                    });
                },
                minLength: 2,
                select: function(event, ui) {
                    $(this).val(ui.item.label);
                    $(this).siblings(".cliente_id_occasional").val(ui.item.id);
                    return false;
                }
            });
        }
    });

    $("#producto").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "buscar_producto_por_nombre.php",
                type: "POST",
                data: { action: 'obtener_precio_producto', nombre: request.term },
                dataType: "json",
                success: function(data) {
                    response($.map(data, function(item) {
                        return {
                            label: item.nombre + " - $" + parseInt(item.precio).toLocaleString('es-ES', { minimumFractionDigits: 0 }),
                            value: item.nombre,
                            id: item.id,
                            precio: parseInt(item.precio)
                        };
                    }));
                },
                error: function() {
                    response([]);
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            $("#producto").val(ui.item.value);
            $("#producto").data("id", ui.item.id);
            $("#producto").data("precio", ui.item.precio);
            return false;
        }
    });

    function addProductToList(id, nombre, precio, cantidad) {
        var totalProducto = precio * cantidad;
        var existe = false;
        $("#productos-list tr").each(function() {
            if ($(this).data("id") == id) {
                var nuevaCantidad = parseInt($(this).find("td:nth-child(2)").text()) + cantidad;
                var nuevoTotal = nuevaCantidad * precio;
                $(this).find("td:nth-child(2)").text(nuevaCantidad);
                $(this).find(".total-producto").text("$" + nuevoTotal.toLocaleString('es-ES', { minimumFractionDigits: 0 }));
                existe = true;
                calcularTotal();
                return false;
            }
        });
        if (!existe) {
            $("#productos-list").append(`
                <tr data-id="${id}">
                    <td>${nombre}</td>
                    <td>${cantidad}</td>
                    <td class="precio-unitario">$${precio.toLocaleString('es-ES', { minimumFractionDigits: 0 })}</td>
                    <td class="total-producto">$${totalProducto.toLocaleString('es-ES', { minimumFractionDigits: 0 })}</td>
                    <td><button type="button" class="btn btn-danger btn-sm eliminar-producto">Eliminar</button></td>
                </tr>
            `);
            calcularTotal();
        }
        $("#producto").val("").removeData("id").removeData("precio");
        $("#cantidad_producto").val(1);
    }

    $("#agregar-producto").click(function() {
        var nombre = $("#producto").val().trim();
        var cantidad = parseInt($("#cantidad_producto").val());
        if (nombre && cantidad > 0) {
            var id = $("#producto").data("id");
            var precio = $("#producto").data("precio");
            if (id && precio) {
                addProductToList(id, nombre, precio, cantidad);
            } else {
                obtenerPrecioPorNombre(nombre, function(precio, id) {
                    if (precio && id) {
                        addProductToList(id, nombre, precio, cantidad);
                    } else {
                        alert("Producto no encontrado.");
                    }
                });
            }
        } else {
            alert("Ingrese un producto y cantidad válidos.");
        }
    });

    function obtenerPrecioPorNombre(nombre, callback) {
        $.ajax({
            url: "buscar_producto_por_nombre.php",
            type: "POST",
            data: { action: 'obtener_precio_producto', nombre: nombre },
            dataType: "json",
            success: function(producto) {
                callback(producto ? parseInt(producto.precio) : null, producto ? producto.id : null);
            },
            error: function() {
                callback(null, null);
            }
        });
    }
    
    $(document).on("click", ".eliminar-producto", function() {
        $(this).closest("tr").remove();
        calcularTotal();
    });

    function calcularTotal() {
        var totalVenta = 0;
        $("#productos-list tr").each(function() {
            var totalProducto = parseInt($(this).find(".total-producto").text().replace('$','').replace(/\./g, ''));
            totalVenta += totalProducto;
        });
        var subtotalTarifa = parseInt($("#subtotal_tarifa").val().replace(/\./g, '')) || 0;
        var bonificacion = parseInt($("#bonificacion option:selected").data("descuento")) || 0;
        var totalTarifaConDesc = subtotalTarifa - Math.floor(subtotalTarifa * (bonificacion / 100));
        var totalGeneral = totalTarifaConDesc + totalVenta;
        $("#total-venta").text(totalGeneral.toLocaleString('es-ES', { minimumFractionDigits: 0 }));
    }
    $("#bonificacion").change(function() {
        calcularTotal();
    });

    $("#ventaForm").on("submit", function(e) {
        e.preventDefault();
        var productos = [];
        $("#productos-list tr").each(function() {
            var id = $(this).data("id");
            var nombre = $(this).find("td:first").text();
            var cantidad = parseInt($(this).find("td:nth-child(2)").text());
            var precio_unitario = parseInt($(this).find(".precio-unitario").text().replace('$','').replace(/\./g, ''));
            productos.push({ id: id, nombre: nombre, cantidad: cantidad, precio_unitario: precio_unitario });
        });
        if (productos.length === 0 && parseInt($("#subtotal_tarifa").val()) === 0) {
            alert("Agrega al menos un producto o verifica la tarifa.");
            return;
        }
        var formData = $(this).serializeArray();
        formData.push({ name: "productos", value: JSON.stringify(productos) });
        formData.push({ name: "subtotal_tarifa", value: $("#subtotal_tarifa").val() });
        $.ajax({
            url: "formulario_reserva_ventas.php",
            type: "POST",
            data: formData,
            dataType: "json",
            success: function(result) {
                if (result.success) {
                    alert("Venta guardada exitosamente.");
                    window.location.href = "ventas.php";
                } else {
                    alert("Error al guardar la venta: " + result.error);
                }
            },
            error: function(xhr) {
                console.error("Error:", xhr.responseText);
                alert("Error al procesar la solicitud.");
            }
        });
    });
});
</script>
</body>
</html>
