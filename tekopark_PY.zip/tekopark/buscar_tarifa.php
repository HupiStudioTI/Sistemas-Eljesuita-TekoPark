<?php
include_once "conexion.php";

// Variables de entrada
$query = isset($_GET['query']) ? $_GET['query'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$offset = ($pagina - 1) * $registros_por_pagina;

// Consulta para contar los resultados totales de la búsqueda
$total_sql = "
    SELECT COUNT(*) as total 
    FROM tarifas 
    WHERE nombretarifa LIKE ? 
       OR actividad LIKE ? 
       OR dias LIKE ?
";
$stmt = $conn->prepare($total_sql);
$searchTerm = "%$query%";
$stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$total_result = $stmt->get_result();
$total_row = $total_result->fetch_assoc();
$total_paginas = ceil($total_row['total'] / $registros_por_pagina);

// Consulta para obtener los resultados de la búsqueda con paginación
$sql = "
    SELECT * 
    FROM tarifas 
    WHERE nombretarifa LIKE ? 
       OR actividad LIKE ? 
       OR dias LIKE ?
    LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssii", $searchTerm, $searchTerm, $searchTerm, $registros_por_pagina, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Construir la respuesta JSON
$tarifas = [];
while ($row = $result->fetch_assoc()) {
    $tarifas[] = $row;
}

echo json_encode([
    'tarifas' => $tarifas,
    'total_paginas' => $total_paginas,
]);

$stmt->close();
$conn->close();
?>
