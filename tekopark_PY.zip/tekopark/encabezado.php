<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
$rol = $_SESSION['usuario']['rol'];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="TekoPark">
    <link rel="shortcut icon" href="img/tekopark.ico" />
    <title>TekoPark</title>
    <!-- Cargar el CSS de Bootstrap -->
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome para los íconos (desde local) -->
    <link href="./css/all.min.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }
        .navbar {
            background: linear-gradient(90deg, #ff007f, #ff8c00);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            max-height: 50px;
        }
        .carousel-inner img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
        .thumbnail-slider {
            display: flex;
            justify-content: center;
            overflow: hidden;
            white-space: nowrap;
        }
        .thumbnail-slider img {
            height: auto;
            width: 10%;
            margin: 0 10px;
            transition: transform 0.3s; 
        }
        .thumbnail-slider img:hover {
            transform: scale(1.1);
        }
        .footer {
            background: #212121;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .footer a {
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-dark">
        <a class="navbar-brand" href="index.php">
            <img src="img/tekopark.png" alt="TekoPark Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#miNavbar" aria-controls="miNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars" style="color: #fff; font-size: 1.5rem;"></i>
        </button>
        <div class="collapse navbar-collapse" id="miNavbar">
            <ul class="navbar-nav me-auto">
                <?php if ($rol === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="clientes.php"><i class="fas fa-users"></i> Clientes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="bonificaciones.php"><i class="fas fa-gift"></i> Bonificaciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="caja_funcional.php"><i class="fas fa-user-friends"></i> Depuracion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tarifas.php"><i class="fas fa-tags"></i> Tarifas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="productos.php"><i class="fas fa-box"></i> Productos</a>
                    </li>
                    <!-- Dropdown para Compras -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cajaDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-shopping-cart"></i> Compras
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="cajaDropdown">
                            <li><a class="dropdown-item" href="proveedores.php">Proveedores</a></li>
                            <li><a class="dropdown-item" href="compras.php">Mov.de Compras</a></li>
                            <li><a class="dropdown-item" href="informe_compras.php">Informe de Compras</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ventas.php"><i class="fas fa-shopping-cart"></i> Ventas</a>
                    </li>
                    <!-- Dropdown para Caja -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cajaDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-cash-register"></i> Caja
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="cajaDropdown">
                            <li><a class="dropdown-item" href="movimientos_caja.php">Movimientos de Caja</a></li>
                            <li><a class="dropdown-item" href="caja.php">Informe de Caja</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="informe_estadisticas.php"><i class="fas fa-chart-bar"></i> Estadísticas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="monitoreo2.php"><i class="fas fa-desktop"></i> Monitoreo</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="abm_usuarios.php"><i class="fas fa-users-cog"></i> Usuarios</a>
                    </li>
                <?php elseif ($rol === 'ventas'): ?>
                    <!-- Clientes accesible para rol ventas -->
                    <li class="nav-item">
                        <a class="nav-link" href="clientes.php"><i class="fas fa-users"></i> Clientes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ventas.php"><i class="fas fa-shopping-cart"></i> Ventas</a>
                    </li>
                    <!-- Dropdown para Caja para rol ventas -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cajaDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-cash-register"></i> Caja
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="cajaDropdown">
                            <li><a class="dropdown-item" href="movimientos_caja.php">Movimientos de Caja</a></li>
                            <li><a class="dropdown-item" href="caja.php">Informe de Caja</a></li>
                        </ul>
                    </li>
                <?php elseif ($rol === 'monitoreo'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="monitoreo2.php"><i class="fas fa-desktop"></i> Monitoreo</a>
                    </li>
                <?php endif; ?>
            </ul>
            <!-- Bloque para mostrar el usuario logueado y opción de cerrar sesión -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <span class="nav-link">Usuario: <?php echo htmlspecialchars($_SESSION['usuario']['nombre']); ?></span>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link text-danger">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid mt-5 px-0">
        <?php
        // Mostrar el contenido dinámico (si existe)
        if (isset($contenido)) {
            echo $contenido;
        } else {
            echo '<div class="row mx-0 text-center">
                    <div class="col-12 mb-4">
                        <h3 style="color: #ff5722;">Sistema de Gestión</h3>
                        <h5>Elija una opción del menú para comenzar</h5>
                    </div>
                  </div>';
        }
        ?>
    </div>
    
    <!-- Optional Footer (comentado) -->
    <!--
    <footer class="footer">
        <a href="https://hupistudio.net/contact.html">Ayuda/Contacto</a> |
        <a href="https://www.tekopark.com">www.tekopark.com</a> | &copy; <?php echo date('Y'); ?> TekoPark
    </footer>
    -->
    <!-- Scripts de Bootstrap y jQuery -->
    <script src="./js/jquery.min.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>
