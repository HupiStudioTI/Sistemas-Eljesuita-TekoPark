<?php
header('Content-Type: application/json');
include_once "funciones.php";
$conn = obtenerbd();

// Si se envía el parámetro 'nombre', ejecuta la consulta
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';

if ($nombre !== '') {
    $stmt = $conn->prepare("SELECT id, nombre, precio FROM productos WHERE nombre LIKE ? LIMIT 10");
    $stmt->execute(['%' . $nombre . '%']);
    
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $resultado = [];
    foreach ($productos as $producto) {
        $resultado[] = [
            'id' => $producto['id'],
            'label' => $producto['nombre'],
            'nombre' => $producto['nombre'],
            'precio' => $producto['precio']
        ];
    }
    
    echo json_encode($resultado);
} else {
    // Si no se envía 'nombre', devuelve un array vacío
    echo json_encode([]);
}
