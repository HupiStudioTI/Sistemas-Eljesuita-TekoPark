<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Bonificación</h3>
    <h5>Actualice los detalles de la bonificación seleccionada.</h5>
</div>
</div>';
include 'encabezado.php';
include_once 'conexion.php';

// Obtener datos de la bonificación
$id = $_GET['id'];
$sql = "SELECT * FROM bonificaciones WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$bonificacion = $result->fetch_assoc();
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="actualizar_bonificacion.php" method="post">
                <!-- ID oculto -->
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($bonificacion['id']); ?>">

                <div class="row">
                    <!-- Nombre de la bonificación -->
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label" style="font-size: 0.9rem; color: blue; font-weight: bold;">Nombre</label>
                        <input type="text" class="form-control form-control-sm" name="nombre" id="nombre" value="<?php echo htmlspecialchars($bonificacion['nombre']); ?>" required>
                    </div>

                    <!-- Porcentaje de descuento -->
                    <div class="col-md-6 mb-3">
                        <label for="descuento" class="form-label" style="font-size: 0.9rem;">Descuento (%)</label>
                        <input type="number" class="form-control form-control-sm" name="descuento" id="descuento" min="0" max="100" value="<?php echo htmlspecialchars($bonificacion['descuento']); ?>" required>
                    </div>
                </div>

                <!-- Botón de actualizar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-warning btn-sm">Actualizar Bonificación</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Validar el campo de descuento para asegurar que sea entre 0 y 100
    $('#descuento').on('input', function() {
        let value = parseInt($(this).val(), 10);
        if (value < 0) $(this).val(0);
        if (value > 100) $(this).val(100);
    });
});
</script>

<?php include 'footer.php'; ?>
