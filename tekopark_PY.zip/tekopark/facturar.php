<?php
// facturar.php  –  ahora verifica si la venta ya fue facturada
session_start();
require_once "encabezado.php";
require_once "conexion.php";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

/* ── validar ID de venta ── */
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ventas.php");
    exit();
}
$venta_id = (int)$_GET['id'];

/* ── traer datos de la venta ── */
$st = $conn->prepare("SELECT total, modo_pago FROM ventas WHERE id = ? LIMIT 1");
$st->bind_param('i',$venta_id);
$st->execute();
$venta = $st->get_result()->fetch_assoc();
if (!$venta){ echo "<div class='alert alert-danger'>Venta no encontrada.</div>"; exit(); }

/* ── ¿ya tiene factura? ── */
$ff = $conn->prepare("SELECT id, nro_comprobante FROM facturas WHERE venta_id = ? LIMIT 1");
$ff->bind_param('i',$venta_id);
$ff->execute();
$facturaExistente = $ff->get_result()->fetch_assoc();   // false si no hay
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Facturar venta #<?= $venta_id ?></title>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body class="container py-4">

<h1 class="h4 mb-4">
    Facturar venta #<?= $venta_id ?> – Total $
    <?= number_format($venta['total'],0,',','.') ?>
</h1>

<?php if ($facturaExistente): ?>
    <!-- Modal de aviso -->
    <div class="modal fade show" id="yaFacturada" tabindex="-1" style="display:block;" aria-modal="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-warning">
            <h5 class="modal-title">Venta ya facturada</h5>
          </div>
          <div class="modal-body">
            <p>La venta #<?= $venta_id ?> ya posee la factura Nº <strong><?= $facturaExistente['nro_comprobante'] ?></strong>.</p>
          </div>
          <div class="modal-footer">
            <a href="imprimir_factura.php?id=<?= $facturaExistente['id'] ?>" class="btn btn-primary">Ver factura</a>
            <a href="ventas.php" class="btn btn-secondary">Volver a Ventas</a>
          </div>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
<?php else: ?>
    <!-- Formulario normal porque NO existe factura -->
    <form action="guardar_factura.php" method="post" class="row g-3 needs-validation" novalidate>
        <input type="hidden" name="venta_id" value="<?= $venta_id ?>">

        <div class="col-md-3">
            <label class="form-label">N° de Comprobante</label>
            <input type="number" name="nro_comprobante" class="form-control" required>
        </div>

        <div class="col-md-6">
            <label class="form-label">Nombre / Razón Social</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="col-md-3">
            <label class="form-label">RUC</label>
            <input type="text" name="ruc" class="form-control" required>
        </div>

        <div class="col-md-8">
            <label class="form-label">Dirección</label>
            <input type="text" name="direccion" class="form-control" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Tipo de pago</label>
            <select name="tipo_pago" class="form-select" required>
                <?php foreach(['Efectivo','Tarjeta','Transferencia','QR','Otro'] as $op){
                    $sel = ($op === $venta['modo_pago']) ? 'selected' : '';
                    echo "<option $sel>$op</option>";
                }?>
            </select>
        </div>

        <div class="col-12">
            <button class="btn btn-success">Guardar y abrir PDF</button>
            <a href="ventas.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
    (()=>{const forms=document.querySelectorAll('.needs-validation');
      Array.from(forms).forEach(f=>{
        f.addEventListener('submit',e=>{
          if(!f.checkValidity()){e.preventDefault();e.stopPropagation();}
          f.classList.add('was-validated');
        });
      });
    })();
    </script>
<?php endif; ?>

</body>
</html>
