<?php
include_once 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actividad     = $_POST['actividad']      ?? '';
    $nombretarifa  = $_POST['nombretarifa']   ?? '';
    $duracion      = $_POST['duracion']       ?? 0;
    $precio        = $_POST['precio']         ?? 0;

    /*  Nuevo: array → cadena */
    $diasArray = $_POST['dias'] ?? [];                 // ej. ['lun','mie']
    $dias      = implode(',', $diasArray);             // 'lun,mie'

    $conn  = obtenerBD();
    $query = $conn->prepare("
        INSERT INTO tarifas (actividad, nombretarifa, dias, duracion, precio)
        VALUES (:actividad, :nombretarifa, :dias, :duracion, :precio)
    ");
    $query->execute([
        ':actividad'     => $actividad,
        ':nombretarifa'  => $nombretarifa,
        ':dias'          => $dias,
        ':duracion'      => $duracion,
        ':precio'        => $precio
    ]);

    header('Location: tarifas.php?mensaje=Tarifa guardada correctamente');
    exit;
}
echo 'Solicitud no válida.';
