<?php include_once "encabezado.php" ?>
<div class="row">
    <div class="col-12">
        <h2>Créditos de las imágenes usadas:</h2>
        <div>Icons made by <a href="https://www.flaticon.com/authors/dimitry-miroliubov" title="Dimitry Miroliubov">Dimitry Miroliubov</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

        <div>Icons made by <a href="https://www.flaticon.com/authors/icongeek26" title="Icongeek26">Icongeek26</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

        <div>Icons made by <a href="https://www.flaticon.com/authors/smashicons" title="Smashicons">Smashicons</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

        <div>Icons made by <a href="https://www.flaticon.com/authors/iconixar" title="iconixar">iconixar</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>

        <div>Icons made by <a href="https://www.freepik.com" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
        <h2>Créditos de desarrollador</h2>
        <div>Develepment by <a href="https://www.hupistudio.com" title="hupistudio">Gustavo Puyol</a> from <a href="https://www.hupistudio.com/" title="hupistudio">www.hupistudio.com</a></div>
    </div>
</div>
<?php include_once "encabezado.php" ?>