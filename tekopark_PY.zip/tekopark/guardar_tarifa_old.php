<?php
include_once 'funciones.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actividad = $_POST['actividad'];
    $nombretarifa = $_POST['nombretarifa'];
    $dias = $_POST['dias'];
    $duracion = $_POST['duracion'];
    $precio = $_POST['precio'];
    // Guardar en la base de datos
    $conn = obtenerBD();
    $query = $conn->prepare("INSERT INTO tarifas (actividad, nombretarifa, dias, duracion, precio) VALUES (:actividad, :nombretarifa, :dias, :duracion, :precio)");
    $query->bindParam(':actividad', $actividad);
    $query->bindParam(':nombretarifa', $nombretarifa);
    $query->bindParam(':dias', $dias);
    $query->bindParam(':duracion', $duracion);
    $query->bindParam(':precio', $precio);
    if ($query->execute()) {
        header('Location: tarifas.php?mensaje=Tarifa guardada correctamente');
        exit;
    } else {
        echo 'Error al guardar la tarifa.';
    }
} else {
    echo 'Solicitud no válida.';
}
