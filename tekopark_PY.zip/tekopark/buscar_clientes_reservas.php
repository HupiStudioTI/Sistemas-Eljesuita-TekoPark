<?php
// buscar_clientes_reservas.php
include_once "funciones.php";

header('Content-Type: application/json');

if (isset($_GET['query'])) {
    $query = trim($_GET['query']);
    $clientes = buscarClientes($query); // Se utiliza la función modificada
    $result = [];

    foreach ($clientes as $cliente) {
        $result[] = [
            // Se muestra nombre, teléfono, documento y también se puede incluir el id si lo deseas en el label.
            'label'     => $cliente->nombre . " (" . $cliente->telefono . ") - " . $cliente->documento,
            'value'     => $cliente->id, 
            'documento' => $cliente->documento
        ];
    }

    echo json_encode($result);
} else {
    echo json_encode([]);
}
?>
