<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Reservas</h3>
    <h5>Administre aquí la información de las reservas.</h5>
</div>
</div>';
// reservas.php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php
        include_once "encabezado.php";
    ?>
    <style>
        .estado-pendiente {
            background-color: #ffcc80 !important;
            color: #333;
        }
        .estado-pagada {
            background-color: #a5d6a7 !important;
            color: #333;
        }
        .estado-cancelada {
            background-color: #ef9a9a !important;
            color: #333;
        }
        .pagination .page-item.active .page-link {
            background-color: #007bff;
            border-color: #007bff;
        }
        .pagination .page-link {
            border: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <?php include_once "conexion.php"; ?>
    <div class="container-fluid mt-2">
        <div class="row">
            <div class="col-12">
                <!--<h3 style="color: #ff5722; margin-bottom: 10px;">Gestión de Reservas</h3>-->
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <a href="formulario_reserva.php" class="btn btn-success btn-sm">Agregar Reserva</a>
                    <form id="buscador-form" class="d-flex">
                        <input id="busqueda" name="buscar" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por código o fecha">
                    </form>
                </div>

                <!-- Tabla de reservas -->
                <div class="table-responsive">
                    <!-- Contenido inicial de la tabla -->
                    <?php include_once "buscar_reservas.php"; ?>
                </div>
            </div>
        </div>
    </div>
    <?php include_once "footer.php"; ?>

    <!-- Incluye jQuery si no está incluido en encabezado.php -->
    <script src="js/jquery.min.js"></script>
    <!-- Incluye Bootstrap JS si lo usas en encabezado.php -->
    <script>
    $(document).ready(function () {
        // Función para cargar reservas
        function cargarReservas(buscar = '', pagina = 1) {
            $.ajax({
                url: 'buscar_reservas.php',
                type: 'GET',
                data: { buscar: buscar, pagina: pagina },
                beforeSend: function () {
                    // Mostrar un indicador de carga (opcional)
                    $('#tabla-reservas').html('<tr><td colspan="9" class="text-center">Cargando...</td></tr>');
                },
                success: function (response) {
                    $('#tabla-reservas').html($(response).find('#tabla-reservas').html());
                    $('.pagination').html($(response).find('.pagination').html());
                },
                error: function () {
                    alert('Error al cargar las reservas.');
                }
            });
        }

        // Buscador dinámico
        $('#busqueda').on('input', function () {
            const query = $(this).val();
            cargarReservas(query, 1);
        });

        // Paginación dinámica
        $(document).on('click', '.pagination .page-link', function (e) {
            e.preventDefault();
            const pagina = $(this).data('pagina');
            const query = $('#busqueda').val();
            cargarReservas(query, pagina);
        });

        // Imprimir ticket
        $(document).on('click', '.imprimir-ticket', function () {
            const idReserva = $(this).data('id');
            $.ajax({
                url: 'obtener_datos_reservaticket.php',
                type: 'GET',
                data: { id: idReserva },
                dataType: 'json',
                success: function (datosReserva) {
                    if (datosReserva.error) {
                        alert(datosReserva.error);
                        return;
                    }

                    const ventanaImpresion = window.open('', '_blank', 'width=600,height=600');
                    ventanaImpresion.document.write(`
                        <html>
                            <head>
                                <title>Ticket de Reserva</title>
                                <style>
                                    body { font-family: Arial, sans-serif; padding: 20px; }
                                    h1 { color: #ff5722; }
                                    p { font-size: 14px; }
                                </style>
                            </head>
                            <body>
                                <h1>Ticket de Reserva</h1>
                                <p><strong>Código de Reserva:</strong> ${datosReserva.codigo_reserva}</p>
                                <p><strong>Cliente:</strong> ${datosReserva.cliente_nombre ? datosReserva.cliente_nombre : 'Sin cliente'}</p>
                                <p><strong>Fecha:</strong> ${datosReserva.fecha_reserva}</p>
                                <p><strong>Hora Desde:</strong> ${datosReserva.hora_desde}</p>
                                <p><strong>Hora Hasta:</strong> ${datosReserva.hora_hasta}</p>
                                <p><strong>Cantidad de Clientes:</strong> ${datosReserva.cantidad_clientes}</p>
                                <p><strong>Estado:</strong> ${datosReserva.estado.charAt(0).toUpperCase() + datosReserva.estado.slice(1)}</p>
                            </body>
                        </html>
                    `);
                    ventanaImpresion.document.close();

                    ventanaImpresion.focus();
                    ventanaImpresion.print();
                    ventanaImpresion.close();
                },
                error: function (xhr, status, error) {
                    console.error('Error en la solicitud AJAX:', status, error);
                    alert('Hubo un problema al intentar imprimir el ticket. Por favor, inténtalo de nuevo.');
                }
            });
        });
    });
    </script>
</body>
</html>
