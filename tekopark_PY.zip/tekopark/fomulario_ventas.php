<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1>Registrar Venta</h1>
    <form action="guardar_venta.php" method="POST">
        <div class="mb-3">
            <label for="reserva_id" class="form-label">Seleccionar Reserva</label>
            <select name="reserva_id" id="reserva_id" class="form-select" required>
                <!-- Aquí debes cargar las reservas disponibles -->
                <?php
                // Conectar a la base de datos y obtener las reservas
                include_once "conexion.php";
                $reservas = $conn->query("SELECT id, codigo_reserva FROM reservas WHERE estado = 'pendiente'");
                while ($row = $reservas->fetch_assoc()) {
                    echo "<option value=\"{$row['id']}\">{$row['codigo_reserva']}</option>";
                }
                ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="forma_pago" class="form-label">Forma de Pago</label>
            <select name="forma_pago" id="forma_pago" class="form-select" required>
                <option value="efectivo">Efectivo</option>
                <option value="tarjeta">Tarjeta</option>
                <option value="qr">QR</option>
                <option value="transferencia">Transferencia</option>
                <option value="otro">Otro</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="bonificaciones" class="form-label">Bonificaciones</label>
            <input type="number" name="bonificaciones" id="bonificaciones" class="form-control" min="0" value="0">
        </div>

        <button type="submit" class="btn btn-success">Guardar Venta</button>
    </form>
</div>
</body>
</html>
