<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Colaboradores</h3>
    <h5>Administre aquí la información de los colaboradores.</h5>
</div>
</div>';
include 'encabezado.php';
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="add_colaboradores.php" class="btn btn-success btn-sm">Agregar</a>
                <form id="buscador-form" class="d-flex">
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por nombre o empresa">
                </form>
            </div>

            <!-- Tabla de colaboradores -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Email</th>
                            <th>Empresa</th>
                            <th>Dirección</th>
                            <th>Comisión (%)</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-colaboradores">
                        <!-- Los resultados dinámicos se cargarán aquí -->
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center" id="paginacion">
                    <!-- Los botones de navegación dinámicos se cargarán aquí -->
                </ul>
            </nav>
        </div>
    </div>
</div>
<script>
    function cargarColaboradores(query = '', pagina = 1) {
        fetch(`buscar_colaboradores.php?query=${encodeURIComponent(query)}&pagina=${pagina}`)
            .then(response => response.json())
            .then(data => {
                let tablaColaboradores = document.getElementById('tabla-colaboradores');
                let paginacion = document.getElementById('paginacion');
                tablaColaboradores.innerHTML = ""; // Limpiar resultados previos
                paginacion.innerHTML = ""; // Limpiar navegación previa

                // Mostrar los colaboradores en la tabla
                if (data.colaboradores.length > 0) {
                    data.colaboradores.forEach(colaborador => {
                        tablaColaboradores.innerHTML += `
                            <tr>
                                <td>${colaborador.nombre}</td>
                                <td>${colaborador.telefono}</td>
                                <td>${colaborador.email}</td>
                                <td>${colaborador.empresa}</td>
                                <td>${colaborador.direccion}</td>
                                <td>${colaborador.comision}</td>
                                <td><a class="btn btn-warning btn-sm" href="edit_colaboradores.php?id=${colaborador.id}">Editar</a></td>
                                <td><a class="btn btn-danger btn-sm" href="delete_colaboradores.php?id=${colaborador.id}" onclick="return confirm('¿Está seguro de que desea eliminar este colaborador?');">Eliminar</a></td>
                            </tr>
                        `;
                    });
                } else {
                    tablaColaboradores.innerHTML = `
                        <tr>
                            <td colspan="8" class="text-center">No se encontraron resultados.</td>
                        </tr>
                    `;
                }

                // Crear botones de navegación
                const totalPaginas = data.total_paginas;

                if (totalPaginas > 1) {
                    // Botón Inicio
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarColaboradores('${query}', 1)">Inicio</button>
                        </li>
                    `;

                    // Botón Anterior
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarColaboradores('${query}', ${pagina - 1})">Anterior</button>
                        </li>
                    `;

                    // Botón Siguiente
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarColaboradores('${query}', ${pagina + 1})">Siguiente</button>
                        </li>
                    `;

                    // Botón Fin
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarColaboradores('${query}', ${totalPaginas})">Fin</button>
                        </li>
                    `;
                }
            })
            .catch(error => console.error('Error:', error));
    }

    // Cargar todos los colaboradores al inicio
    document.addEventListener('DOMContentLoaded', () => cargarColaboradores());
    // Escuchar eventos de entrada en el buscador
    document.getElementById('busqueda').addEventListener('input', function () {
        const query = this.value;
        cargarColaboradores(query);
    });
</script>
<?php
include 'footer.php';
?>
