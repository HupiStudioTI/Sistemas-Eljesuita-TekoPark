<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Productos</h3>
    <h5>Administre aquí la información de los productos.</h5>
</div>
</div>';
include 'encabezado.php';
include_once 'funciones.php';

// Parámetros iniciales
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$inicio = ($pagina - 1) * $registros_por_pagina;

// Obtener productos y el total
$productos = obtenerProductosPaginados($busqueda, $inicio, $registros_por_pagina);
$total_productos = contarTotalProductos($busqueda);
$total_paginas = ceil($total_productos / $registros_por_pagina);
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="agregar_producto.php" class="btn btn-success btn-sm">Agregar</a>
                <form id="buscador-form" class="d-flex">
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por nombre">
                </form>
            </div>

            <!-- Tabla de productos -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Unidad</th> <!-- Nueva columna -->
                            <th>Precio</th>
                            <th>Costo</th>
                            <th>Stock</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                            <th>Componentes</th> <!-- 👈 Nueva columna -->
                        </tr>
                    </thead>
                    <tbody id="tabla-productos">
                        <!-- Los resultados dinámicos se cargarán aquí -->
                    </tbody>
                </table>
            </div>
            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center" id="paginacion">
                    <!-- Los botones de navegación dinámicos se cargarán aquí -->
                </ul>
            </nav>
            <!-- Botón para Informe de Stock -->
            <div class="text-center my-4">
                 <a href="informe_stock.php" class="btn btn-info btn-sm">Generar Informe de Stock</a>
            </div>
            <!-- Botón para Informe de Stock -->
           </div>
    </div>
</div>

<script>
    function cargarProductos(query = '', pagina = 1) {
        fetch(`buscar_producto.php?query=${encodeURIComponent(query)}&pagina=${pagina}`)
            .then(response => response.json())
            .then(data => {
                let tablaProductos = document.getElementById('tabla-productos');
                let paginacion = document.getElementById('paginacion');
                tablaProductos.innerHTML = ""; // Limpiar resultados previos
                paginacion.innerHTML = "";     // Limpiar navegación previa

                if (data.productos.length > 0) {
                    data.productos.forEach(producto => {
                        // Convertir stock a número
                        let stockNumerico = parseFloat(producto.stock);
                        let stockFormateado;

                        // Si la unidad es KG o LT, mostrar con 3 decimales,
                        // en caso contrario, mostrar como entero (sin decimales).
                        if (producto.unidad_medida === "KG" || producto.unidad_medida === "LT") {
                            stockFormateado = stockNumerico.toFixed(3);
                        } else {
                            // toFixed(0) muestra sin decimales
                            stockFormateado = stockNumerico.toFixed(0);
                        }

                        tablaProductos.innerHTML += `
                            <tr>
                                <td>${producto.id}</td>
                                <td>${producto.nombre}</td>
                                <td>${producto.unidad_medida}</td> 
                                <td>${producto.precio}</td>
                                <td>${producto.costo}</td>
                                <td>${stockFormateado}</td>
                                <td>
                                    <a class="btn btn-warning btn-sm" href="editar_producto.php?id=${producto.id}">
                                        Editar
                                    </a>
                                </td>
                                <td>
                                    <a class="btn btn-danger btn-sm" href="eliminar_producto.php?id=${producto.id}"
                                    onclick="return confirm('¿Está seguro de que desea eliminar este producto?');">
                                        Eliminar
                                    </a>
                                </td>
                                <td>
                                    <a class="btn btn-secondary btn-sm" href="asignar_componentes.php?id=${producto.id}">
                                        🧩 Componentes
                                    </a>
                                </td>
                            </tr>
                        `;
                    });
                } else {
                    tablaProductos.innerHTML = `
                        <tr>
                            <td colspan="9" class="text-center">No se encontraron resultados.</td>
                        </tr>
                    `;
                }

                // Crear botones de navegación
                const totalPaginas = data.total_paginas;
                if (totalPaginas > 1) {
                    for (let i = 1; i <= totalPaginas; i++) {
                        paginacion.innerHTML += `
                            <li class="page-item ${i === data.pagina_actual ? 'active' : ''}">
                                <button class="page-link btn-sm" onclick="cargarProductos('${query}', ${i})">
                                    ${i}
                                </button>
                            </li>
                        `;
                    }
                }
            })
            .catch(error => console.error('Error:', error));
    }

    // Cargar todos los productos al inicio
    document.addEventListener('DOMContentLoaded', () => cargarProductos());

    // Escuchar eventos de entrada en el buscador
    document.getElementById('busqueda').addEventListener('input', function () {
        const query = this.value;
        cargarProductos(query);
    });
</script>

<?php
include 'footer.php';
?>
