<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestion de Ventas</h3>
    <h5>Administre aquí las ventas.</h5>
</div>
</div>';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        /* Estilos personalizados para reducir el tamaño de la tabla */
        .table-custom-sm th, .table-custom-sm td {
            font-size: 0.8rem; /* Tamaño de fuente más pequeño */
            padding: 0.25rem; /* Padding reducido */
            vertical-align: middle; /* Alinear verticalmente al medio */
        }
        
        /* Reducir tamaño de fuente en botones dentro de la tabla */
        .table-custom-sm .btn {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        /* Opcional: Reducir tamaño de fuente en el modal */
        .modal-custom-sm .modal-body {
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
<?php
include_once "encabezado.php";
include_once "conexion.php"; // Archivo de conexión a la base de datos

// Establecer el charset para evitar problemas con caracteres especiales
mysqli_set_charset($conn, 'utf8mb4');

// Recibir el término de búsqueda de forma segura
$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';

// Definir la cantidad de registros por página
$registros_por_pagina = 10;

// Obtener y validar la página actual
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina_actual < 1) $pagina_actual = 1;

// Calcular el inicio para la consulta
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Preparar el término de búsqueda para usar con LIKE
$parametro_busqueda = '%' . $buscar . '%';

// **Importante:** Asegurarse de que los valores de LIMIT sean enteros
$inicio = (int)$inicio;
$registros_por_pagina = (int)$registros_por_pagina;

// Consulta con búsqueda y paginación usando prepared statements (excluyendo LIMIT)
$sql = "SELECT v.id, v.fecha, v.total, v.modo_pago, r.codigo_reserva, r.id AS reserva_id
        FROM ventas v
        LEFT JOIN reservas r ON v.reserva_id = r.id
        WHERE v.fecha LIKE ?
        OR v.id LIKE ?
        OR r.codigo_reserva LIKE ?
        OR r.id LIKE ?
        ORDER BY v.fecha DESC 
        LIMIT $inicio, $registros_por_pagina";

$stmt = $conn->prepare($sql);
if ($stmt) {
    // 'ssss' indica los tipos de los parámetros: string, string, string, string
    $stmt->bind_param('ssss', $parametro_busqueda, $parametro_busqueda, $parametro_busqueda, $parametro_busqueda);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    die("Error en la preparación de la consulta: " . htmlspecialchars($conn->error));
}

// Contar el total de ventas para la paginación usando prepared statements
$sql_total = "SELECT COUNT(DISTINCT v.id) as total 
              FROM ventas v
              LEFT JOIN reservas r ON v.reserva_id = r.id
              WHERE v.fecha LIKE ?
              OR v.id LIKE ?
              OR r.codigo_reserva LIKE ?
              OR r.id LIKE ?";

$stmt_total = $conn->prepare($sql_total);
if ($stmt_total) {
    $stmt_total->bind_param('ssss', $parametro_busqueda, $parametro_busqueda, $parametro_busqueda, $parametro_busqueda);
    $stmt_total->execute();
    $result_total = $stmt_total->get_result();
    $total_ventas = $result_total->fetch_assoc()['total'];
} else {
    die("Error en la preparación de la consulta total: " . htmlspecialchars($conn->error));
}

$total_paginas = ceil($total_ventas / $registros_por_pagina);
?>
<div class="container mt-5">
    <h1>Ventas</h1>
    <a href="formulario_reserva_ventas.php" class="btn btn-success mb-3 btn-sm">Registrar Venta</a>
    <!-- Buscador -->
    <form method="GET" action="ventas.php" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control form-control-sm" placeholder="Buscar por ID de venta, ID de reserva, código de reserva o fecha." value="<?php echo htmlspecialchars($buscar, ENT_QUOTES, 'UTF-8'); ?>">
            <button class="btn btn-primary btn-sm" type="submit">Buscar</button>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-striped table-sm table-custom-sm">
            <thead>
                <tr>
                    <th>ID Venta</th>
                    <th>ID Reserva</th>
                    <th>Código Reserva</th>
                    <th>Fecha</th>
                    <th>Total $</th>
                    <th>Modo de Pago</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row["id"], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo $row["reserva_id"] ? htmlspecialchars($row["reserva_id"], ENT_QUOTES, 'UTF-8') : 'Sin reserva'; ?></td>
                            <td><?php echo $row["codigo_reserva"] ? htmlspecialchars($row["codigo_reserva"], ENT_QUOTES, 'UTF-8') : 'Sin reserva'; ?></td>
                            <td><?php echo htmlspecialchars($row["fecha"], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars(number_format($row["total"], 2), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($row["modo_pago"], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <button class="btn btn-info btn-sm" onclick="verVenta(<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>)">Ver</button>
                                <a href="imprimir_ticket.php?id=<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-primary btn-sm">Imprimir Ticket</a>
                                <a href="facturar.php?id=<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-warning btn-sm">Facturar</a>
                                <a href="eliminar_venta.php?id=<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr><td colspan="7" class="text-center">No se encontraron ventas.</td></tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Paginación -->
    <?php if ($total_paginas > 1) { ?>
    <nav>
        <ul class="pagination pagination-sm justify-content-center">
            <!-- Botón Inicio -->
            <li class="page-item <?php echo $pagina_actual == 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=1&buscar=<?php echo urlencode($buscar); ?>">Inicio</a>
            </li>
            <!-- Botón Anterior -->
            <li class="page-item <?php echo $pagina_actual == 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo max($pagina_actual - 1, 1); ?>&buscar=<?php echo urlencode($buscar); ?>">Anterior</a>
            </li>
            <!-- Rango de Páginas -->
            <?php
            $rango = 2; // Número de páginas a mostrar a cada lado de la actual
            for ($i = max(1, $pagina_actual - $rango); $i <= min($total_paginas, $pagina_actual + $rango); $i++) {
                echo '<li class="page-item ' . ($i == $pagina_actual ? 'active' : '') . '">
                        <a class="page-link" href="?pagina=' . $i . '&buscar=' . urlencode($buscar) . '">' . $i . '</a>
                      </li>';
            }
            ?>
            <!-- Botón Siguiente -->
            <li class="page-item <?php echo $pagina_actual == $total_paginas ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo min($pagina_actual + 1, $total_paginas); ?>&buscar=<?php echo urlencode($buscar); ?>">Siguiente</a>
            </li>
            <!-- Botón Fin -->
            <li class="page-item <?php echo $pagina_actual == $total_paginas ? 'disabled' : ''; ?>">
                <a class="page-link" href="?pagina=<?php echo $total_paginas; ?>&buscar=<?php echo urlencode($buscar); ?>">Fin</a>
            </li>
        </ul>
    </nav>
    <?php } ?>

    <!-- Modal para mostrar detalles de la venta -->
    <div class="modal fade modal-custom-sm" id="ventaModal" tabindex="-1" aria-labelledby="ventaModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ventaModalLabel">Detalles de la Venta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body" id="ventaDetalle">
                    <!-- Aquí se cargarán los detalles de la venta -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        function verVenta(idVenta) {
            $.ajax({
                url: 'ver_detalle_venta.php', // Archivo PHP que recupera los detalles de la venta
                type: 'POST',
                data: { id: idVenta },
                success: function(response) {
                    $('#ventaDetalle').html(response); // Cargar los detalles en el modal
                    $('#ventaModal').modal('show'); // Mostrar el modal
                },
                error: function() {
                    alert('Error al cargar detalles de la venta.');
                }
            });
        }
    </script>
    <?php include_once "footer.php"; ?>
</body>
</html>
