<?php
// Establecer el servidor SMTP y el puerto en tiempo de ejecución
ini_set('SMTP', 'smtp.hostinger.com');
ini_set('smtp_port', 587);

// Verificar si el formulario ha sido enviado
if (isset($_POST['enviar_email'])) {
    echo '<div class="alert alert-info">Formulario enviado. Procesando envío del correo...</div>';

    // Parámetros del correo
    $to = "gustavohpuyol@gmail.com";
    $subject = "Prueba de correo desde PHP";
    $message = "Este es un correo de prueba enviado desde PHP usando la función mail().";

    // Encabezados del correo
    $headers = "From: tekoparkiguazu@eljesuita.com\r\n";
    $headers .= "Reply-To: tekoparkiguazu@eljesuita.com\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Intentar enviar el correo
    if (mail($to, $subject, $message, $headers)) {
        echo '<div class="alert alert-success">El correo fue enviado correctamente.</div>';
    } else {
        echo '<div class="alert alert-danger">Error al enviar el correo.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba de Envío de Correo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Prueba de Envío de Correo</h1>
    
    <!-- Formulario simple para enviar un correo -->
    <form method="POST" action="">
        <button type="submit" name="enviar_email" class="btn btn-primary">Enviar Correo de Prueba</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
