<?php
/* guardar_factura.php – graba la factura, controla duplicados,
   y abre el PDF en una pestaña nueva sin cerrar la app */
session_start();
require_once "conexion.php";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

/* ▸ recoger y validar POST */
$venta_id        = isset($_POST['venta_id'])        ? (int)$_POST['venta_id']        : 0;
$nro_comprobante = isset($_POST['nro_comprobante']) ? (int)$_POST['nro_comprobante'] : 0;
$nombre          = trim($_POST['nombre']    ?? '');
$ruc             = trim($_POST['ruc']       ?? '');
$direccion       = trim($_POST['direccion'] ?? '');
$tipo_pago       = trim($_POST['tipo_pago'] ?? '');

if (!$venta_id || !$nro_comprobante || !$nombre || !$ruc || !$direccion) {
    die("Datos incompletos.");
}

/* ▸ comprobar duplicado del nº de comprobante */
$dup = $conn->prepare("SELECT COUNT(*) FROM facturas WHERE nro_comprobante = ?");
$dup->bind_param('i', $nro_comprobante);
$dup->execute();
$existe = $dup->get_result()->fetch_row()[0] > 0;

if ($existe) {
    /* — modal si el comprobante ya existe — */
    ?>
    <!DOCTYPE html>
    <html lang="es"><head>
      <meta charset="utf-8"><title>Duplicado</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
    </head><body>
    <div class="modal fade show" style="display:block;" aria-modal="true">
      <div class="modal-dialog"><div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Comprobante duplicado</h5>
        </div>
        <div class="modal-body">
          El número de comprobante <strong><?= htmlspecialchars($nro_comprobante) ?></strong> ya existe.
        </div>
        <div class="modal-footer">
          <a href="ventas.php" class="btn btn-secondary">Volver a Ventas</a>
          <a href="facturar.php?id=<?= $venta_id ?>" class="btn btn-primary">Intentar otro número</a>
        </div>
      </div></div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    </body></html>
    <?php
    exit();
}

/* ▸ insertar factura + líneas */
try {
    $conn->begin_transaction();

    /* encabezado + tarifa */
    $enc = $conn->prepare("
        SELECT v.total, v.modo_pago,
               COALESCE(v.totaltarifas, t.precio, 0) AS tarifa
        FROM   ventas v
        LEFT   JOIN reservas r ON v.reserva_id = r.id
        LEFT   JOIN tarifas  t ON r.tarifa_id  = t.id
        WHERE  v.id = ? LIMIT 1
    ");
    $enc->bind_param('i', $venta_id);
    $enc->execute();
    $ventaRow = $enc->get_result()->fetch_assoc();
    if (!$ventaRow) throw new Exception("Venta no encontrada.");

    /* ítems (detalle_ventas) */
    $det = $conn->prepare("
        SELECT COALESCE(p.nombre, CONCAT('Producto #', dv.producto_id)) AS descripcion,
               dv.cantidad, dv.precio_unitario
        FROM   detalle_ventas dv
        LEFT   JOIN productos p ON dv.producto_id = p.id
        WHERE  dv.venta_id = ?
    ");
    $det->bind_param('i', $venta_id);
    $det->execute();
    $itemsRes = $det->get_result();

    $lineas = [];
    while ($r = $itemsRes->fetch_assoc()) {
        $lineas[] = [
            'descripcion'=> $r['descripcion'],
            'cantidad'   => $r['cantidad'],
            'unitario'   => $r['precio_unitario'],
            'subtotal'   => $r['cantidad'] * $r['precio_unitario']
        ];
    }

    /* tarifa como ítem */
    $tarifa = (float)$ventaRow['tarifa'];
    if ($tarifa > 0) {
        $lineas[] = ['descripcion'=>'Tarifa','cantidad'=>1,'unitario'=>$tarifa,'subtotal'=>$tarifa];
    }
    if (!$lineas) throw new Exception("Sin ítems ni tarifa para facturar.");

    /* totales e IVA */
    $ali        = 10.00;
    $impTotal   = array_sum(array_column($lineas,'subtotal'));
    $impNeto    = round($impTotal / (1 + $ali/100), 2);
    $iva        = round($impTotal - $impNeto, 2);

    /* insertar encabezado */
    $f = $conn->prepare("
        INSERT INTO facturas
        (venta_id, fecha, nro_comprobante,
         ruc, nombre, direccion,
         tipo_pago, importe_total, importe_neto,
         impuesto, alicuota, bonificacion, importe_bonificacion)
        VALUES
        (?, NOW(), ?,
         ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)
    ");
    $f->bind_param(
        'iissssdddd',
        $venta_id,
        $nro_comprobante,
        $ruc, $nombre, $direccion,
        $tipo_pago,
        $impTotal, $impNeto,
        $iva, $ali
    );
    $f->execute();
    $factura_id = $conn->insert_id;

    /* insertar líneas */
    $fi = $conn->prepare("
        INSERT INTO factura_items
        (factura_id, descripcion, cantidad,
         importe_unitario, importe_sin_impuesto, subtotal)
        VALUES
        (?, ?, ?, ?, ?, ?)
    ");
    foreach ($lineas as $L) {
        $sinIva = round($L['unitario'] / (1 + $ali/100), 2);
        $fi->bind_param(
            'isiddd',
            $factura_id,
            $L['descripcion'],
            $L['cantidad'],
            $L['unitario'],
            $sinIva,
            $L['subtotal']
        );
        $fi->execute();
    }

    $conn->commit();

    /* ▸ abrir PDF en pestaña nueva + mensaje */
    $pdfURL  = "imprimir_factura.php?id=$factura_id";
    $backURL = "ventas.php";
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8">
      <title>Factura creada</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body class="d-flex flex-column align-items-center justify-content-center" style="height:100vh;">
      <div class="text-center">
        <h4 class="mb-3">¡Factura generada correctamente!</h4>
        <p>Se abrió la factura en una pestaña nueva.<br>
           Si no la ves, haz clic en <a href="<?= $pdfURL ?>" target="_blank">este enlace</a>.</p>
        <a href="<?= $backURL ?>" class="btn btn-primary">Volver a Ventas</a>
      </div>

      <script>
        window.open("<?= $pdfURL ?>", "_blank");   // abre PDF
      </script>
    </body>
    </html>
    <?php
    exit();

} catch (Exception $e) {
    if ($conn->errno) $conn->rollback();
    echo "<h3>Error al guardar:</h3><p>". $e->getMessage() ."</p>";
}
