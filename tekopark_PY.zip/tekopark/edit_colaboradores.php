<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Colaborador</h3>
    <h5>Modifique los datos del colaborador y haga clic en actualizar.</h5>
</div>
</div>';
include_once "encabezado.php";

include_once "conexion.php";
$id = $_GET['id'];
$sql = "SELECT * FROM colaboradores WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$colaborador = $result->fetch_assoc();
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <form action="actualizar_colaboradores.php" method="post">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input required type="text" class="form-control form-control-sm" name="nombre" id="nombre" value="<?php echo htmlspecialchars($colaborador['nombre']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="telefono" class="form-label">Teléfono</label>
                        <input required type="text" class="form-control form-control-sm" name="telefono" id="telefono" value="<?php echo htmlspecialchars($colaborador['telefono']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input required type="email" class="form-control form-control-sm" name="email" id="email" value="<?php echo htmlspecialchars($colaborador['email']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="empresa" class="form-label">Empresa</label>
                        <input required type="text" class="form-control form-control-sm" name="empresa" id="empresa" value="<?php echo htmlspecialchars($colaborador['empresa']); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="direccion" class="form-label">Dirección</label>
                        <input required type="text" class="form-control form-control-sm" name="direccion" id="direccion" value="<?php echo htmlspecialchars($colaborador['direccion']); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="comision" class="form-label">Comisión (%)</label>
                        <input required type="number" step="0.01" class="form-control form-control-sm" name="comision" id="comision" value="<?php echo htmlspecialchars($colaborador['comision']); ?>">
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-warning btn-sm">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include_once "footer.php"; ?>
