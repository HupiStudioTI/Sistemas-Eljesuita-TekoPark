<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Editar Producto</h3>
    <h5>Actualice los detalles del producto seleccionado.</h5>
</div>
</div>';
include_once "encabezado.php";
include_once "funciones.php";

// Obtener los datos del producto a editar
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$pdo = obtenerBD();

try {
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$producto) {
        die('<div class="alert alert-danger">Producto no encontrado.</div>');
    }
} catch (PDOException $e) {
    die('<div class="alert alert-danger">Error al obtener el producto: ' . $e->getMessage() . '</div>');
}

// Manejar la lógica de edición de producto
$mensaje = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $costo = $_POST["costo"];
    $precio = $_POST["precio"];
    $stock = $_POST["stock"];
    try {
        $stmt = $pdo->prepare("UPDATE productos SET nombre = :nombre, precio = :precio, costo = :costo, stock = :stock WHERE id = :id");
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':costo', $costo, PDO::PARAM_STR);
        $stmt->bindParam(':precio', $precio, PDO::PARAM_STR);
        $stmt->bindParam(':stock', $stock, PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $mensaje = "<div class='alert alert-success'>Producto actualizado con éxito.</div>";
        } else {
            $mensaje = "<div class='alert alert-danger'>No se pudo actualizar el producto.</div>";
        }
    } catch (PDOException $e) {
        $mensaje = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<div class="container mt-5">
    <?php if (!empty($mensaje)) echo $mensaje; ?>

    <a href="productos.php" class="btn btn-secondary mb-3">Volver a Productos</a>

    <form action="editar_producto.php?id=<?php echo $id; ?>" method="POST">
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre del Producto</label>
            <input type="text" name="nombre" class="form-control form-control-sm" id="nombre" value="<?php echo htmlspecialchars($producto['nombre']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="costo" class="form-label">Costo</label>
            <input type="number" name="costo" class="form-control form-control-sm" id="costo" step="1" value="<?php echo htmlspecialchars($producto['costo'] ?? ''); ?>" >
        </div>
        <div class="mb-3">
            <label for="precio" class="form-label">Precio</label>
            <input type="number" name="precio" class="form-control form-control-sm" id="precio" step="1" value="<?php echo htmlspecialchars($producto['precio']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="stock" class="form-label">Stock</label>
            <input type="number" name="stock" class="form-control form-control-sm" id="stock" value="<?php echo htmlspecialchars($producto['stock']); ?>" required>
        </div>
        <button type="submit" class="btn btn-warning btn-sm">Actualizar Producto</button>
    </form>
</div>

<?php include_once "footer.php"; ?>
