<?php
include_once "conexion.php";
include_once "phpqrcode/phpqrcode.php"; // Incluye la librería QR

// Obtener el ID de la venta
$venta_id = $_GET['id'];

// Obtener los detalles de la venta
$stmt = $conn->prepare("SELECT v.*, r.codigo_reserva, r.actividad, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, c.nombre as colaborador_nombre, c.comision 
                        FROM ventas v
                        LEFT JOIN reservas r ON v.reserva_id = r.id
                        LEFT JOIN colaboradores c ON v.colaborador_id = c.id
                        WHERE v.id = ?");
$stmt->bind_param("i", $venta_id);
$stmt->execute();
$venta = $stmt->get_result()->fetch_assoc();
if (!$venta) {
    die("Error: No se encontró la venta.");
}

// Generar el código QR con el ID de la venta
$qrContent = 'ID Venta: ' . $venta_id;
$qrFilePath = 'qrs/venta_' . $venta_id . '.png';
QRcode::png($qrContent, $qrFilePath);

// Obtener los productos de la venta
$productos_stmt = $conn->prepare("SELECT dv.*, p.nombre 
                                  FROM detalle_ventas dv
                                  LEFT JOIN productos p ON dv.producto_id = p.id
                                  WHERE dv.venta_id = ?");
$productos_stmt->bind_param("i", $venta_id);
$productos_stmt->execute();
$productos = $productos_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket de Venta</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .ticket {
            width: 250px;
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            margin: auto;
        }
        .ticket-logo {
            width: 150px;  /* Aumentado el tamaño del logo */
            height: auto;
            margin-bottom: 10px;
        }
        .ticket-details {
            margin-bottom: 10px;
            font-size: 0.8rem; /* Reducido el tamaño de la fuente para los detalles */
        }
        .ticket-total {
            font-size: 1.2rem;
            font-weight: bold;
            margin-top: 10px;
        }
        .qr-code {
            margin-top: 10px;
        }
        .qr-code img {
            width: 130px;  /* Aumentado el tamaño del QR */
            height: 130px;
        }
        .table td, .table th {
            padding: 2px;
            font-size: 0.7rem; /* Reducido el tamaño de la fuente para la tabla */
        }
        .table th {
            text-align: center;
        }
        .table td {
            text-align: right;
        }
        @media print {
            .ticket {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="ticket">
    <img src="img/tekopark.png" alt="Logo Teko" class="ticket-logo">
    
    <div class="ticket-details">
        <p>ID Vta: <?php echo $venta_id; ?></p>
        <p>Código Reserva: <?php echo $venta['codigo_reserva']; ?></p>
        <p>Actividad: <?php echo $venta['actividad']; ?></p>
        <p>Fecha: <?php echo $venta['fecha_reserva']; ?> (<?php echo $venta['hora_desde']; ?> - <?php echo $venta['hora_hasta']; ?>)</p>
        <p>Cant. Clientes: <?php echo $venta['cantidad_clientes']; ?></p>
        <p>Colaborador: <?php echo $venta['colaborador_nombre']; ?> (Comisión: $<?php echo number_format($venta['comision'], 2); ?>)</p>
        <p>Color: <?php echo $venta['color']; ?></p>
        <p>Modo de Pago: <?php echo $venta['modo_pago']; ?></p>
        <p>Bonificación: $<?php echo number_format($venta['bonificacion'], 2); ?></p>
    </div>
    
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cant.</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($producto = $productos->fetch_assoc()) { ?>
            <tr>
                <td style="text-align: left;"><?php echo $producto['nombre']; ?></td>
                <td><?php echo $producto['cantidad']; ?></td>
                <td>$<?php echo number_format($producto['total'], 2); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

    <div class="ticket-total">
        Total: $<?php echo number_format($venta['total'], 2); ?>
    </div>
    
    <!-- Mostrar el código QR -->
    <div class="qr-code">
        <img src="<?php echo $qrFilePath; ?>" alt="Código QR">
    </div>
</div>

<script>
    window.print(); // Imprimir el ticket automáticamente
    // Redirigir a ventas.php después de la impresión
    window.onafterprint = function() {
        window.location.href = "ventas.php";
    };
</script>
</body>
</html>
