<?php
include_once 'funciones.php';

// Recibir parámetros
$query = isset($_GET['query']) ? $_GET['query'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$inicio = ($pagina - 1) * $registros_por_pagina;

// Obtener productos paginados y total
$productos = obtenerProductosPaginados($query, $inicio, $registros_por_pagina);
$total_productos = contarTotalProductos($query);
$total_paginas = ceil($total_productos / $registros_por_pagina);

// Convertir stock a decimal por si lo tenés como string
// y asegurarnos de que contenga la unidad_medida
foreach ($productos as $key => $prod) {
    // Convertir stock a número decimal
    $productos[$key]['stock'] = (float) $prod['stock']; 
    // Asegurarnos que exista unidad_medida (si tu función lo retorna)
    // Si no lo retorna, habría que ajustar la consulta en obtenerProductosPaginados
    // para incluir 'unidad_medida'.
}

// Responder en formato JSON
echo json_encode([
    'productos' => $productos,
    'total_paginas' => $total_paginas,
    'pagina_actual' => $pagina
]);
