<?php
include_once "funciones.php";
$ok=eliminarClientesReserva( $_GET["id"]);
if (!$ok) {
    echo "Error eliminando";
} else {
    $ok1 = eliminarReserva($_GET["id"]);
    if (!$ok1) {
        echo "Error eliminando";
    } else {
        header("Location: reservas.php");
    }
}