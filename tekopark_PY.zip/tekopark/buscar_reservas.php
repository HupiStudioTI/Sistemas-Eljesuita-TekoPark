<?php
// buscar_reservas.php
include_once "conexion.php";

// Recibir el término de búsqueda y la página
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$inicio = ($pagina_actual - 1) * $registros_por_pagina;

// Preparar el término de búsqueda para LIKE
$searchTerm = "%$buscar%";

// Obtener reservas con búsqueda dinámica
$sql = "SELECT r.id, r.codigo_reserva, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, r.estado,
           (SELECT c.nombre 
            FROM clientes c 
            INNER JOIN clientes_reserva cr ON c.id = cr.cliente_id 
            WHERE cr.reserva_id = r.id 
            LIMIT 1
           ) AS cliente_nombre
    FROM reservas r
    WHERE r.codigo_reserva LIKE ? OR r.fecha_reserva LIKE ?
    GROUP BY r.id
    ORDER BY r.fecha_reserva DESC, r.estado ASC
    LIMIT ?, ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssii", $searchTerm, $searchTerm, $inicio, $registros_por_pagina);
$stmt->execute();
$result = $stmt->get_result();

// Contar el total de reservas
$sql_count = "SELECT COUNT(DISTINCT r.id) as total 
    FROM reservas r
    WHERE r.codigo_reserva LIKE ? OR r.fecha_reserva LIKE ?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("ss", $searchTerm, $searchTerm);
$stmt_count->execute();
$total_reservas = $stmt_count->get_result()->fetch_assoc()['total'];

$total_paginas = ceil($total_reservas / $registros_por_pagina);

// Función para generar la paginación similar a tarifas.php
function generarPaginacion($pagina_actual, $total_paginas) {
    $pagination_html = '<nav>';
    $pagination_html .= '<ul class="pagination pagination-sm justify-content-center">';

    // Botón "Primero"
    if ($pagina_actual > 1) {
        $pagination_html .= '<li class="page-item"><a class="page-link" href="#" data-pagina="1">Primero</a></li>';
    } else {
        $pagination_html .= '<li class="page-item disabled"><span class="page-link">Primero</span></li>';
    }

    // Botón "Anterior"
    if ($pagina_actual > 1) {
        $pagination_html .= '<li class="page-item"><a class="page-link" href="#" data-pagina="'.($pagina_actual - 1).'">Anterior</a></li>';
    } else {
        $pagination_html .= '<li class="page-item disabled"><span class="page-link">Anterior</span></li>';
    }

    // Paginación numérica con puntos suspensivos
    $limite = 2; // Número de páginas a mostrar antes y después de la página actual

    if ($total_paginas > 1) {
        if ($pagina_actual > ($limite + 1)) {
            $pagination_html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        for ($i = max(1, $pagina_actual - $limite); $i <= min($pagina_actual + $limite, $total_paginas); $i++) {
            if ($i == $pagina_actual) {
                $pagination_html .= '<li class="page-item active"><span class="page-link">'.$i.'</span></li>';
            } else {
                $pagination_html .= '<li class="page-item"><a class="page-link" href="#" data-pagina="'.$i.'">'.$i.'</a></li>';
            }
        }

        if ($pagina_actual < ($total_paginas - $limite)) {
            $pagination_html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }

    // Botón "Siguiente"
    if ($pagina_actual < $total_paginas) {
        $pagination_html .= '<li class="page-item"><a class="page-link" href="#" data-pagina="'.($pagina_actual + 1).'">Siguiente</a></li>';
    } else {
        $pagination_html .= '<li class="page-item disabled"><span class="page-link">Siguiente</span></li>';
    }

    // Botón "Último"
    if ($pagina_actual < $total_paginas) {
        $pagination_html .= '<li class="page-item"><a class="page-link" href="#" data-pagina="'.$total_paginas.'">Último</a></li>';
    } else {
        $pagination_html .= '<li class="page-item disabled"><span class="page-link">Último</span></li>';
    }

    $pagination_html .= '</ul>';
    $pagination_html .= '</nav>';

    return $pagination_html;
}
?>

<!-- Tabla de reservas -->
<table class="table table-striped table-sm">
    <thead>
        <tr>
            <th>ID</th>
            <th>Código Reserva</th>
            <th>Cliente</th>
            <th>Fecha</th>
            <th>Hs Desde</th>
            <th>Hs Hasta</th>
            <th>Cant. Clientes</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody id="tabla-reservas">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <?php
                $estado_clase = '';
                switch ($row['estado']) {
                    case 'pendiente': $estado_clase = 'estado-pendiente'; break;
                    case 'pagada': $estado_clase = 'estado-pagada'; break;
                    case 'cancelada': $estado_clase = 'estado-cancelada'; break;
                }
                ?>
                <tr class="<?php echo $estado_clase; ?>">
                    <td><?php echo htmlspecialchars($row["id"]); ?></td>
                    <td><?php echo htmlspecialchars($row["codigo_reserva"]); ?></td>
                    <td><?php echo htmlspecialchars($row["cliente_nombre"] ? $row["cliente_nombre"] : "Sin cliente"); ?></td>
                    <td><?php echo htmlspecialchars($row["fecha_reserva"]); ?></td>
                    <td><?php echo htmlspecialchars($row["hora_desde"]); ?></td>
                    <td><?php echo htmlspecialchars($row["hora_hasta"]); ?></td>
                    <td><?php echo htmlspecialchars($row["cantidad_clientes"]); ?></td>
                    <td><?php echo ucfirst(htmlspecialchars($row["estado"])); ?></td>
                    <td>
                        <a href="edit_reserva.php?id=<?php echo urlencode($row['id']); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <button class="btn btn-primary btn-sm imprimir-ticket" data-id="<?php echo htmlspecialchars($row['id']); ?>">Imprimir</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="9" class="text-center">No se encontraron reservas.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Paginación -->
<?php
if ($total_paginas > 1) {
    echo generarPaginacion($pagina_actual, $total_paginas);
}
?>
