<?php
// ============================================================================
//  caja.php  –  Informe de Caja (PDF 100 % / 70 %)  –  Compatibilidad PHP 5.4+
// ============================================================================
session_start();
if (!isset($_SESSION['usuario']) || !is_array($_SESSION['usuario'])) {
    header('location:index.php'); exit();
}

$rol            = $_SESSION['usuario']['rol'];
$usuario_actual = $_SESSION['usuario']['id'];

require_once 'tcpdf/tcpdf.php';
include_once "funciones.php";

/* ---------------------------------------------------------------------------
 * 1) Preparar datos (cuando llega el formulario)
 * ------------------------------------------------------------------------- */
$tarifas_vendidas   = array();
$productos_vendidos = array();
$nombre_informe     = "";
$vista_movimientos  = 'detallado';

if (   isset($_POST['generar_informe'])
    || isset($_POST['generar_pdf'])
    || isset($_POST['generar_pdf_70']) ) {

    $fecha_inicio      = $_POST['fecha_inicio'];
    $fecha_fin         = $_POST['fecha_fin'];
    $vista_movimientos = isset($_POST['vista_movimientos'])
                         ? $_POST['vista_movimientos'] : 'detallado';

    $usuario_filter = ($rol === 'admin' && isset($_POST['usuario']))
                      ? (int)$_POST['usuario']
                      : $usuario_actual;

    $tarifas_vendidas   = obtenerTarifasVendidas($fecha_inicio,$fecha_fin,$usuario_filter);
    $productos_vendidos = obtenerProductosVendidos($fecha_inicio,$fecha_fin,$usuario_filter);

    if ($rol === 'admin' && $usuario_filter > 0) {
        $pdo  = obtenerBD();
        $stmt = $pdo->prepare("SELECT nombre FROM usuarios WHERE id = :id");
        $stmt->execute(array(':id'=>$usuario_filter));
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);
        $nombre_informe = $fila ? $fila['nombre'] : 'Desconocido';
    } elseif ($rol !== 'admin') {
        $nombre_informe = $_SESSION['usuario']['nombre'];
    } else {
        $nombre_informe = 'Todos los usuarios';
    }
}

/* ---------------------------------------------------------------------------
 * 2) Generar PDF (normal 100 % o reducido 70 %)
 * ------------------------------------------------------------------------- */
if (isset($_POST['generar_pdf']) || isset($_POST['generar_pdf_70'])) {

    ob_end_clean();                                  // Evita “headers already sent”

    $factor       = isset($_POST['generar_pdf_70']) ? 0.7 : 1.0;
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin    = $_POST['fecha_fin'];

    /* 2.1 Totales por Forma de Pago */
    $formas  = array('efectivo','tarjeta','qr','transferencia','otros');
    $fpDatos = array();
    foreach ($formas as $f) {
        $fpDatos[$f] = array('totaltarifas'=>0,'totalproductos'=>0,'total'=>0);
    }

    $pdo = obtenerBD();
    $sql = "SELECT LOWER(modo_pago) AS mp,
                   SUM(totaltarifas)   AS tot_tar,
                   SUM(totalproductos) AS tot_prod,
                   SUM(total)          AS tot_gen
            FROM ventas
            WHERE fecha BETWEEN :fi AND :ff";
    if ($usuario_filter > 0) $sql .= " AND usuario_id = :uid";
    $sql .= " GROUP BY mp";
    $stmt = $pdo->prepare($sql);
    $prm  = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter > 0) $prm[':uid'] = $usuario_filter;
    $stmt->execute($prm);

    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $m = $r['mp'];  if (!isset($fpDatos[$m])) continue;
        $prod_calc = $r['tot_prod'] !== null ? $r['tot_prod'] : ($r['tot_gen'] - $r['tot_tar']);
        $fpDatos[$m]['totaltarifas']   = $r['tot_tar']   * $factor;
        $fpDatos[$m]['totalproductos'] = $prod_calc      * $factor;
        $fpDatos[$m]['total']          = $r['tot_gen']   * $factor;
    }

    /* 2.2 Copiar/escala Tarifas y Productos */
    $tarifasPDF = array();
    foreach ($tarifas_vendidas as $t) {
        $tarifasPDF[] = array(
            'nombre'           => $t['nombre'],
            'cantidad_vendida' => $t['cantidad_vendida'],
            'total_tarifas'    => $t['total_tarifas'] * $factor
        );
    }
    $productosPDF = array();
    foreach ($productos_vendidos as $p) {
        $productosPDF[] = array(
            'nombre'           => $p['nombre'],
            'cantidad_vendida' => $p['cantidad_vendida'],
            'total_vendido'    => $p['total_vendido'] * $factor
        );
    }

    /* 2.3 Movimientos */
    $sqlMov = "SELECT * FROM movimientos_caja
               WHERE fecha BETWEEN :fi AND :ff";
    if ($usuario_filter > 0) $sqlMov .= " AND usuario_id = :uid";
    $sqlMov .= " ORDER BY fecha ASC";
    $stmtMov = $pdo->prepare($sqlMov);
    $prMov   = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter > 0) $prMov[':uid'] = $usuario_filter;
    $stmtMov->execute($prMov);
    $movimientos = $stmtMov->fetchAll(PDO::FETCH_ASSOC);
    $totCred=$totDeb=0;
    foreach ($movimientos as $m){ $totCred+=$m['credito']; $totDeb+=$m['debito']; }
    $neto_mov = $totCred - $totDeb;

    /* 2.4 Ventas totales */
    $stmtTot = $pdo->prepare(
        "SELECT SUM(total) AS tv FROM ventas
         WHERE fecha BETWEEN :fi AND :ff" .
         ($usuario_filter>0 ? " AND usuario_id = :uid" : ""));
    $prTot = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter>0) $prTot[':uid'] = $usuario_filter;
    $stmtTot->execute($prTot);
    $tv = $stmtTot->fetchColumn();  $tv = $tv ? $tv*$factor : 0;
    $totComb = $neto_mov + $tv;

    /* 2.5 PDF */
    $pdf = new TCPDF('P','mm',array(80,200));
    $pdf->SetMargins(5,5,5);  $pdf->AddPage();
    $pdf->SetFont('helvetica','BI',12);
    $pdf->Cell(0,5,
        $factor < 1 ? 'Listado Ventas Shopping' : 'Informe de Caja',
        0,1,'C');

    $pdf->SetFont('helvetica','',10);
    $pdf->Cell(0,5,'Usuario: '.$nombre_informe,0,1,'L');
    $pdf->Cell(0,5,'Desde: '.date('d/m/Y H:i',strtotime($fecha_inicio)),0,1,'L');
    $pdf->Cell(0,5,'Hasta: '.date('d/m/Y H:i',strtotime($fecha_fin)),0,1,'L');
    $pdf->Ln(5);

    /* Sección 1 – Forma de Pago */
    $pdf->SetFont('helvetica','B',9);
    $pdf->Cell(0,5,'Totales por Forma de Pago',0,1,'L');
    $pdf->SetFont('helvetica','B',6);
    $pdf->Cell(15,5,'FP',1,0,'C');
    $pdf->Cell(19,5,'Tarifa',1,0,'C');
    $pdf->Cell(19,5,'Prod',1,0,'C');
    $pdf->Cell(19,5,'Total',1,1,'C');
    $pdf->SetFont('helvetica','',6);
    foreach ($formas as $f){
        $d = $fpDatos[$f];
        $pdf->Cell(15,5,ucfirst($f),1,0,'C');
        $pdf->Cell(19,5,'$'.number_format($d['totaltarifas'],2),1,0,'C');
        $pdf->Cell(19,5,'$'.number_format($d['totalproductos'],2),1,0,'C');
        $pdf->Cell(19,5,'$'.number_format($d['total'],2),1,1,'C');
    }
    $pdf->Ln(5);

    /* Sección 2 – Ventas por Tarifa (solo PDF 100 %) */
    if ($factor == 1 && !empty($tarifasPDF)) {
        $pdf->SetFont('helvetica','B',9);
        $pdf->Cell(0,5,'Ventas por Tarifa',0,1,'L'); $pdf->Ln(3);
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(35,5,'Tarifa',1,0,'L');
        $pdf->Cell(15,5,'Cant.',1,0,'C');
        $pdf->Cell(22,5,'Importe',1,1,'R');
        $pdf->SetFont('helvetica','',7);
        $cT=$iT=0;
        foreach ($tarifasPDF as $t){
            $pdf->Cell(35,5,substr($t['nombre'],0,20),1,0,'L');
            $pdf->Cell(15,5,$t['cantidad_vendida'],1,0,'C');
            $pdf->Cell(22,5,'$'.number_format($t['total_tarifas'],2),1,1,'R');
            $cT += $t['cantidad_vendida'];  $iT += $t['total_tarifas'];
        }
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(35,5,'Totales',1,0,'L');
        $pdf->Cell(15,5,$cT,1,0,'C');
        $pdf->Cell(22,5,'$'.number_format($iT,2),1,1,'R');
        $pdf->Ln(5);
    }

    /* Sección 3 – Ventas por Producto */
    if (!empty($productosPDF)) {
        $pdf->SetFont('helvetica','B',9);
        $pdf->Cell(0,5,'Ventas por Producto',0,1,'L'); $pdf->Ln(3);
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(35,5,'Producto',1,0,'L');
        $pdf->Cell(15,5,'Cant.',1,0,'C');
        $pdf->Cell(22,5,'Importe',1,1,'R');
        $pdf->SetFont('helvetica','',7);
        $cP=$iP=0;
        foreach ($productosPDF as $p){
            $pdf->Cell(35,5,substr($p['nombre'],0,20),1,0,'L');
            $pdf->Cell(15,5,$p['cantidad_vendida'],1,0,'C');
            $pdf->Cell(22,5,'$'.number_format($p['total_vendido'],2),1,1,'R');
            $cP += $p['cantidad_vendida'];  $iP += $p['total_vendido'];
        }
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(35,5,'Totales',1,0,'L');
        $pdf->Cell(15,5,$cP,1,0,'C');
        $pdf->Cell(22,5,'$'.number_format($iP,2),1,1,'R');
        $pdf->Ln(5);
    }

    /* Sección 4 – Movimientos de Caja */
    $pdf->SetFont('helvetica','B',9);
    $pdf->Cell(0,5,'Movimientos de Caja ('.ucfirst($vista_movimientos).')',0,1,'L');
    if ($vista_movimientos == 'detallado') {
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(10,5,'ID',1,0,'C');
        $pdf->Cell(20,5,'Fecha',1,0,'C');
        $pdf->Cell(15,5,'Crédito',1,0,'C');
        $pdf->Cell(15,5,'Débito',1,0,'C');
        $pdf->Cell(20,5,'Total',1,0,'C');
        $pdf->Cell(20,5,'Desc.',1,1,'C');
        $pdf->SetFont('helvetica','',7);
        foreach ($movimientos as $m){
            $tot = $m['credito'] - $m['debito'];
            $pdf->Cell(10,5,$m['id'],1,0,'C');
            $pdf->Cell(20,5,date('d/m H:i',strtotime($m['fecha'])),1,0,'C');
            $pdf->Cell(15,5,'$'.number_format($m['credito'],0),1,0,'C');
            $pdf->Cell(15,5,'$'.number_format($m['debito'],0),1,0,'C');
            $pdf->Cell(20,5,'$'.number_format($tot,0),1,0,'C');
            $pdf->Cell(20,5,substr($m['descripcion'],0,20),1,1,'C');
        }
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(45,5,'Totales',1,0,'L');
        $pdf->Cell(15,5,'$'.number_format($totCred,0),1,0,'C');
        $pdf->Cell(15,5,'$'.number_format($totDeb,0),1,0,'C');
        $pdf->Cell(20,5,'$'.number_format($neto_mov,0),1,1,'C');
    } else {
        $pdf->SetFont('helvetica','B',7);
        $pdf->Cell(50,5,'Total Crédito: $'.number_format($totCred,0),1,1,'L');
        $pdf->Cell(50,5,'Total Débito:  $'.number_format($totDeb,0),1,1,'L');
        $pdf->Cell(50,5,'Neto Mov.:     $'.number_format($neto_mov,0),1,1,'L');
    }
    $pdf->Ln(5);

    /* Sección 5 – Total combinado */
    $pdf->SetFont('helvetica','B',9);
    $pdf->Cell(0,5,'Total Combinado (Caja + Ventas)',0,1,'L');
    $pdf->SetFont('helvetica','B',7);
    $pdf->Cell(50,5,'Ventas Totales: $'.number_format($tv,2),1,1,'L');
    $pdf->Cell(50,5,'Caja Neto:     $'.number_format($neto_mov,0),1,1,'L');
    $pdf->Cell(50,5,'Total Combin.: $'.number_format($totComb,2),1,1,'L');

    /* Guardar + descargar */
    $suf = $factor < 1 ? '_70' : '';
    $file = __DIR__."/pdf/cajas/informe_caja_ticket$suf"."_".date('YmdHis').".pdf";
    $pdf->Output($file,'F');
    $pdf->Output("informe_caja_ticket$suf.pdf",'D');
    exit;
}
?>

<?php include_once "encabezado.php"; ?>

<?php
/* ---------------------------------------------------------------------------
 * 3) Lista de usuarios para el selector (solo admin)
 * ------------------------------------------------------------------------- */
if ($rol === 'admin') {
    $usuarios = obtenerUsuarios();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Módulo de Caja</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script>
$(function () {
    $("#btnGenerarPDF, #btnGenerarPDF70").click(function () {
        $("#formInforme").removeAttr("target");
    });
});
</script>
</head>
<body>
<div class="container mt-5">
<h1 class="mb-4">Informe de Caja</h1>

<form method="POST" action="" id="formInforme">
    <div class="row mb-3">
        <div class="col-md-4">
            <label class="form-label">Fecha y hora, desde</label>
            <input type="datetime-local" name="fecha_inicio" class="form-control"
                   value="<?php echo isset($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : ''; ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Fecha y hora, hasta</label>
            <input type="datetime-local" name="fecha_fin" class="form-control"
                   value="<?php echo isset($_POST['fecha_fin']) ? $_POST['fecha_fin'] : ''; ?>" required>
        </div>
        <div class="col-md-4">
        <?php if ($rol === 'admin'): ?>
            <label class="form-label">Usuario</label>
            <select name="usuario" class="form-select">
                <option value="0">Todos los usuarios</option>
                <?php foreach ($usuarios as $u): ?>
                <option value="<?php echo $u['id']; ?>"
                    <?php echo (isset($_POST['usuario']) && $_POST['usuario']==$u['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($u['nombre']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <input type="hidden" name="usuario" value="<?php echo $usuario_actual; ?>">
        <?php endif; ?>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-md-12">
            <label class="form-label">Vista de Movimientos de Caja</label>
            <select name="vista_movimientos" class="form-select">
                <option value="detallado"
                    <?php echo (isset($_POST['vista_movimientos']) && $_POST['vista_movimientos']=='detallado') ? 'selected' : ''; ?>>
                    Detallado</option>
                <option value="resumen"
                    <?php echo (isset($_POST['vista_movimientos']) && $_POST['vista_movimientos']=='resumen') ? 'selected' : ''; ?>>
                    Resumen</option>
            </select>
        </div>
    </div>
    <button type="submit" class="btn btn-warning" name="generar_pdf_70" id="btnGenerarPDF70">
        Generar Ventas
    </button>
</form>

<?php if (isset($_POST['generar_informe'])):

    /* -------- Datos para Informe HTML (misma lógica que el PDF 100 %) -------- */
    $dp = array('efectivo'=>0,'tarjeta'=>0,'qr'=>0,'transferencia'=>0,'otros'=>0);
    $pdo = obtenerBD();
    $sqlH = "SELECT LOWER(modo_pago) mp, SUM(total) ttl
             FROM ventas
             WHERE fecha BETWEEN :fi AND :ff";
    if ($usuario_filter > 0) $sqlH .= " AND usuario_id = :uid";
    $sqlH .= " GROUP BY mp";
    $stmtH = $pdo->prepare($sqlH);
    $prH   = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter > 0) $prH[':uid'] = $usuario_filter;
    $stmtH->execute($prH);
    $total_general = 0;
    while ($row = $stmtH->fetch(PDO::FETCH_ASSOC)) {
        $dp[$row['mp']] = $row['ttl'];  $total_general += $row['ttl'];
    }

    /* Movimientos HTML */
    $sqlM = "SELECT * FROM movimientos_caja
             WHERE fecha BETWEEN :fi AND :ff";
    if ($usuario_filter > 0) $sqlM .= " AND usuario_id = :uid";
    $sqlM .= " ORDER BY fecha ASC";
    $stmM = $pdo->prepare($sqlM);
    $prM  = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter > 0) $prM[':uid'] = $usuario_filter;
    $stmM->execute($prM);
    $movHTML = $stmM->fetchAll(PDO::FETCH_ASSOC);
    $credH=$debH=0;
    foreach ($movHTML as $mh){ $credH+=$mh['credito']; $debH+=$mh['debito']; }
    $netH = $credH - $debH;
?>
<!-- =============== Tarjeta Totales por Forma de Pago (HTML) =============== -->
<div class="card mt-4">
<div class="card-body">
    <p><strong>Informe de Caja para:</strong> <?php echo htmlspecialchars($nombre_informe); ?></p>
    <p><strong>Desde:</strong> <?php echo date('d/m/Y H:i',strtotime($fecha_inicio)); ?></p>
    <p><strong>Hasta:</strong> <?php echo date('d/m/Y H:i',strtotime($fecha_fin)); ?></p>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-dark"><tr><th>Forma de Pago</th><th>Total</th></tr></thead>
            <tbody>
            <?php foreach ($dp as $fp=>$val): ?>
                <tr><td><?php echo ucfirst($fp); ?></td><td>$<?php echo number_format($val,2); ?></td></tr>
            <?php endforeach; ?>
                <tr><td><strong>Total General</strong></td>
                    <td><strong>$<?php echo number_format($total_general,2); ?></strong></td></tr>
            </tbody>
        </table>
    </div>
</div>
</div>

<!-- =============== Movimientos de Caja (HTML) =============== -->
<div class="card mt-4"><div class="card-body">
    <h5>Movimientos de Caja (<?php echo ucfirst($vista_movimientos); ?>)</h5>

<?php if ($vista_movimientos == 'detallado'): ?>
    <div class="table-responsive">
        <table class="table table-bordered">
        <thead class="table-dark">
            <tr><th>ID</th><th>Fecha</th><th>Crédito</th>
                <th>Débito</th><th>Total Mov.</th><th>Descripción</th></tr>
        </thead><tbody>
        <?php foreach ($movHTML as $mh): $tot=$mh['credito']-$mh['debito']; ?>
            <tr>
                <td><?php echo $mh['id']; ?></td>
                <td><?php echo date('d/m/Y H:i',strtotime($mh['fecha'])); ?></td>
                <td>$<?php echo number_format($mh['credito'],0); ?></td>
                <td>$<?php echo number_format($mh['debito'],0); ?></td>
                <td>$<?php echo number_format($tot,0); ?></td>
                <td><?php echo htmlspecialchars($mh['descripcion']); ?></td>
            </tr>
        <?php endforeach; ?>
            <tr><td colspan="2"><strong>Totales</strong></td>
                <td><strong>$<?php echo number_format($credH,0); ?></strong></td>
                <td><strong>$<?php echo number_format($debH,0); ?></strong></td>
                <td colspan="2"><strong>$<?php echo number_format($netH,0); ?></strong></td></tr>
        </tbody></table>
    </div>
<?php else: ?>
    <p><strong>Total Crédito:</strong> $<?php echo number_format($credH,0); ?></p>
    <p><strong>Total Débito:</strong>  $<?php echo number_format($debH,0); ?></p>
    <p><strong>Neto Movimientos:</strong> $<?php echo number_format($netH,0); ?></p>
<?php endif;

    /* Ventas totales HTML */
    $stVT = $pdo->prepare("SELECT SUM(total) tv FROM ventas
                           WHERE fecha BETWEEN :fi AND :ff"
                           .($usuario_filter>0?" AND usuario_id=:uid":""));
    $prVT = array(':fi'=>$fecha_inicio, ':ff'=>$fecha_fin);
    if ($usuario_filter>0) $prVT[':uid']=$usuario_filter;
    $stVT->execute($prVT);
    $tvH = $stVT->fetchColumn();  $totComb = $netH + $tvH;
?>
    <p><strong>Total Ventas:</strong> $<?php echo number_format($tvH,2); ?></p>
    <p><strong>Total Combinado (Caja + Ventas):</strong>
        $<?php echo number_format($totComb,2); ?></p>
</div></div>

<!-- =============== Ventas por Tarifa (HTML) =============== -->
<?php if (!empty($tarifas_vendidas)): ?>
<div class="card mt-4"><div class="card-body">
    <h5>Ventas por Tarifa</h5>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr><th>Tarifa</th><th>Cantidad</th><th>Importe</th></tr>
            </thead><tbody>
            <?php $cT=$iT=0; foreach ($tarifas_vendidas as $t): ?>
                <tr>
                    <td><?php echo htmlspecialchars($t['nombre']); ?></td>
                    <td><?php echo $t['cantidad_vendida']; ?></td>
                    <td>$<?php echo number_format($t['total_tarifas'],2); ?></td>
                </tr>
            <?php $cT+=$t['cantidad_vendida']; $iT+=$t['total_tarifas']; endforeach; ?>
                <tr><td><strong>Totales</strong></td>
                    <td><strong><?php echo $cT; ?></strong></td>
                    <td><strong>$<?php echo number_format($iT,2); ?></strong></td></tr>
            </tbody>
        </table>
    </div>
</div></div>
<?php endif; ?>

<!-- =============== Ventas por Producto (HTML) =============== -->
<?php if (!empty($productos_vendidos)): ?>
<div class="card mt-4"><div class="card-body">
    <h5>Ventas por Producto</h5>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr><th>Producto</th><th>Cantidad</th><th>Importe</th></tr>
            </thead><tbody>
            <?php $cP=$iP=0; foreach ($productos_vendidos as $p): ?>
                <tr>
                    <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                    <td><?php echo $p['cantidad_vendida']; ?></td>
                    <td>$<?php echo number_format($p['total_vendido'],2); ?></td>
                </tr>
            <?php $cP+=$p['cantidad_vendida']; $iP+=$p['total_vendido']; endforeach; ?>
                <tr><td><strong>Totales</strong></td>
                    <td><strong><?php echo $cP; ?></strong></td>
                    <td><strong>$<?php echo number_format($iP,2); ?></strong></td></tr>
            </tbody>
        </table>
    </div>
</div></div>
<?php endif; ?>

<?php endif; /* generar_informe */ ?>
</div><!-- /.container -->
</body>
</html>
