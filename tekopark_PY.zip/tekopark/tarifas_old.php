<?php
$contenido = '<div class="row mx-0 text-center">
<div class="col-12 mb-4">
    <h3 style="color: #ff5722;">Gestión de Tarifas</h3>
    <h5>Administre las tarifas de actividades y servicios aquí.</h5>
</div>
</div>';
include_once "encabezado.php";
include_once "conexion.php";

// Configuración de paginación
$limit = 10; // Número de resultados por página
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Obtener el total de registros
$total_sql = "SELECT COUNT(*) AS total FROM tarifas";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total = $total_row['total'];
$total_pages = ceil($total / $limit);

// Obtener las tarifas con paginación
$sql = "SELECT * FROM tarifas LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="add_tarifa.php" class="btn btn-success btn-sm">Agregar</a>
                <form id="buscador-form" class="d-flex">
                    <input id="busqueda" name="busqueda" class="form-control form-control-sm me-2" type="text" placeholder="Buscar por actividad o tarifa">
                </form>
            </div>

            <!-- Tabla de tarifas -->
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Actividad</th>
                            <th>Tarifa</th>
                            <th>Días</th>
                            <th>Duración</th>
                            <th>Precio</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-tarifas">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo $row["actividad"]; ?></td>
                                    <td><?php echo $row["nombretarifa"]; ?></td>
                                    <td><?php echo $row["dias"]; ?></td>
                                    <td><?php echo $row["duracion"]; ?></td>
                                    <td><?php echo $row["precio"]; ?></td>
                                    <td>
                                        <a href="edit_tarifa.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                                        <a href="delete_tarifa.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center">No se encontraron tarifas.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <nav>
                <ul class="pagination pagination-sm justify-content-center" id="paginacion">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php if ($i === $page) echo 'active'; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>
<script>
    function cargarTarifas(query = '', pagina = 1) {
        fetch(`buscar_tarifa.php?query=${encodeURIComponent(query)}&pagina=${pagina}`)
            .then(response => response.json())
            .then(data => {
                let tablaTarifas = document.getElementById('tabla-tarifas');
                let paginacion = document.getElementById('paginacion');
                tablaTarifas.innerHTML = ""; // Limpiar resultados previos
                paginacion.innerHTML = ""; // Limpiar navegación previa

                // Mostrar las tarifas en la tabla
                if (data.tarifas.length > 0) {
                    data.tarifas.forEach(tarifa => {
                        tablaTarifas.innerHTML += `
                            <tr>
                                <td>${tarifa.id}</td>
                                <td>${tarifa.actividad}</td>
                                <td>${tarifa.nombretarifa}</td>
                                <td>${tarifa.dias}</td>
                                <td>${tarifa.duracion}</td>
                                <td>${tarifa.precio}</td>
                                <td>
                                    <a href="edit_tarifa.php?id=${tarifa.id}" class="btn btn-warning btn-sm">Editar</a>
                                    <a href="delete_tarifa.php?id=${tarifa.id}" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?');">Eliminar</a>
                                </td>
                            </tr>
                        `;
                    });
                } else {
                    tablaTarifas.innerHTML = `
                        <tr>
                            <td colspan="7" class="text-center">No se encontraron resultados.</td>
                        </tr>
                    `;
                }

                // Crear botones de navegación
                const totalPaginas = data.total_paginas;

                if (totalPaginas > 1) {
                    // Botón Inicio
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarTarifas('${query}', 1)">Inicio</button>
                        </li>
                    `;

                    // Botón Anterior
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === 1 ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarTarifas('${query}', ${pagina - 1})">Anterior</button>
                        </li>
                    `;

                    // Botón Siguiente
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarTarifas('${query}', ${pagina + 1})">Siguiente</button>
                        </li>
                    `;

                    // Botón Fin
                    paginacion.innerHTML += `
                        <li class="page-item ${pagina === totalPaginas ? 'disabled' : ''}">
                            <button class="page-link btn-sm" onclick="cargarTarifas('${query}', ${totalPaginas})">Fin</button>
                        </li>
                    `;
                }
            })
            .catch(error => console.error('Error:', error));
    }

    // Cargar tarifas al inicio
    document.addEventListener('DOMContentLoaded', () => cargarTarifas());

    // Escuchar eventos de entrada en el buscador
    document.getElementById('busqueda').addEventListener('input', function () {
        const query = this.value;
        cargarTarifas(query);
    });
</script>
<?php include 'footer.php'; ?>
