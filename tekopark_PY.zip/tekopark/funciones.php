<?php
// funciones.php
date_default_timezone_set("America/Argentina/Buenos_Aires");

/**
 * Establece y retorna la conexión PDO con la base de datos.
 *
 * @return PDO Conexión PDO.
 */
function obtenerBD()
{
    $user = "root";
    $password = "";
    $dbName = "teko";
    $host = "localhost";

    try {
        $database = new PDO("mysql:host={$host};dbname={$dbName};charset=utf8", $user, $password);
        $database->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $database->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
        return $database;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

/**
 * Obtiene la lista de departamentos o actividades.
 *
 * @return array Lista de departamentos.
 */
function obtenerDepartamentos()
{
    return [
        "Cama Elástica",
        "Inflable",
        "Bar",
        "Canchas",
        "Bowling",
        "Pelotero",
        "Todos",
        "Otros"
    ];
}

/**
 * Agrega un nuevo cliente a la base de datos.
 *
 * @param string $nombre Nombre del cliente.
 * @param string $documento Documento del cliente.
 * @param string $fechanac Fecha de nacimiento.
 * @param int $edad Edad del cliente.
 * @param string $sexo Sexo del cliente.
 * @param string $ciudad Ciudad del cliente.
 * @param string $departamento Departamento del cliente.
 * @param string $tel Teléfono del cliente.
 * @param string $email Email del cliente.
 * @param string $padre Nombre del padre (si aplica).
 * @param string $docpadre Documento del padre (si aplica).
 * @param string $telpadre Teléfono del padre (si aplica).
 * @param string $obs Observaciones adicionales.
 * @return bool Resultado de la inserción.
 */
function agregarCliente($nombre, $documento, $fechanac, $edad, $sexo, $ciudad, $departamento, $tel, $email, $padre, $docpadre, $telpadre, $obs)
{
    $bd = obtenerBD();
    $fechaRegistro = date("Y-m-d");
    $sql = "INSERT INTO clientes (nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro)
            VALUES (:nombre, :documento, :fechanac, :edad, :sexo, :ciudad, :departamento, :telefono, :email, :padre, :docpadre, :telpadre, :obs, :fecha_registro)";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':nombre' => $nombre,
        ':documento' => $documento,
        ':fechanac' => $fechanac,
        ':edad' => $edad,
        ':sexo' => $sexo,
        ':ciudad' => $ciudad,
        ':departamento' => $departamento,
        ':telefono' => $tel,
        ':email' => $email,
        ':padre' => $padre,
        ':docpadre' => $docpadre,
        ':telpadre' => $telpadre,
        ':obs' => $obs,
        ':fecha_registro' => $fechaRegistro
    ]);
}

/**
 * Verifica si un cliente existe en la base de datos.
 *
 * @param int $cliente_id ID del cliente.
 * @return bool Verdadero si el cliente existe, falso en caso contrario.
 */
function clienteExiste($cliente_id) {
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total FROM clientes WHERE id = :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $cliente_id]);
    $result = $stmt->fetch();
    return $result->total > 0;
}

/**
 * Obtiene todos los clientes de la base de datos.
 *
 * @return array Lista de clientes.
 */
function obtenerClientes()
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro 
            FROM clientes 
            ORDER BY nombre ASC";
    $stmt = $bd->query($sql);
    return $stmt->fetchAll();
}

/**
 * Busca clientes por nombre.
 *
 * @param string $nombre Término de búsqueda.
 * @return array Lista de clientes que coinciden.
 */
function buscarClientes($query)
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro
            FROM clientes
            WHERE (nombre LIKE :query1
                   OR CAST(id AS CHAR) LIKE :query2
                   OR documento LIKE :query3
                   OR telefono LIKE :query4)
            ORDER BY nombre ASC";
    $stmt = $bd->prepare($sql);
    $param = "%$query%";
    $stmt->execute([
        ':query1' => $param,
        ':query2' => $param,
        ':query3' => $param,
        ':query4' => $param
    ]);
    return $stmt->fetchAll();
}
/**
 * Elimina un cliente por su ID.
 *
 * @param int $id ID del cliente.
 * @return bool Resultado de la eliminación.
 */
function eliminarCliente($id)
{
    $bd = obtenerBD();
    $sql = "DELETE FROM clientes WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([':id' => $id]);
}

/**
 * Obtiene un cliente por su ID.
 *
 * @param int $id ID del cliente.
 * @return object|null Objeto del cliente o null si no existe.
 */
function obtenerClientePorId($id)
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro
            FROM clientes
            WHERE id = :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

/**
 * Actualiza los datos de un cliente.
 *
 * @param string $nombre Nombre del cliente.
 * @param string $documento Documento del cliente.
 * @param string $fechanac Fecha de nacimiento.
 * @param int $edad Edad del cliente.
 * @param string $sexo Sexo del cliente.
 * @param string $ciudad Ciudad del cliente.
 * @param string $departamento Departamento del cliente.
 * @param string $tel Teléfono del cliente.
 * @param string $email Email del cliente.
 * @param string $padre Nombre del padre (si aplica).
 * @param string $docpadre Documento del padre (si aplica).
 * @param string $telpadre Teléfono del padre (si aplica).
 * @param string $obs Observaciones adicionales.
 * @param int $id ID del cliente a actualizar.
 * @return bool Resultado de la actualización.
 */
function actualizarCliente($nombre, $documento, $fechanac, $edad, $sexo, $ciudad, $departamento, $tel, $email, $padre, $docpadre, $telpadre, $obs, $id)
{
    $bd = obtenerBD();
    $sql = "UPDATE clientes
            SET nombre = :nombre,
                documento = :documento,
                fechanac = :fechanac,
                edad = :edad,
                sexo = :sexo,
                ciudad = :ciudad,
                departamento = :departamento,
                telefono = :telefono,
                email = :email,
                padre = :padre,
                docpadre = :docpadre,
                telpadre = :telpadre,
                obs = :obs
            WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':nombre' => $nombre,
        ':documento' => $documento,
        ':fechanac' => $fechanac,
        ':edad' => $edad,
        ':sexo' => $sexo,
        ':ciudad' => $ciudad,
        ':departamento' => $departamento,
        ':telefono' => $tel,
        ':email' => $email,
        ':padre' => $padre,
        ':docpadre' => $docpadre,
        ':telpadre' => $telpadre,
        ':obs' => $obs,
        ':id' => $id
    ]);
}

/**
 * Obtiene clientes con paginación.
 *
 * @param int $inicio Inicio de la paginación.
 * @param int $registros_por_pagina Número de registros por página.
 * @return array Lista de clientes.
 */
function obtenerClientesPaginados($inicio, $registros_por_pagina)
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro 
            FROM clientes
            ORDER BY nombre ASC
            LIMIT :inicio, :registros_por_pagina";
    $stmt = $bd->prepare($sql);
    $stmt->bindValue(':inicio', (int)$inicio, PDO::PARAM_INT);
    $stmt->bindValue(':registros_por_pagina', (int)$registros_por_pagina, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Cuenta el total de clientes en la base de datos.
 *
 * @return int Total de clientes.
 */
function contarTotalClientes()
{
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total FROM clientes";
    $stmt = $bd->query($sql);
    return $stmt->fetch()->total;
}

/**
 * Busca clientes por nombre con paginación.
 *
 * @param string $busqueda Término de búsqueda.
 * @param int $inicio Inicio de la paginación.
 * @param int $registros_por_pagina Número de registros por página.
 * @return array Lista de clientes que coinciden.
 */
function buscarClientesPaginados($busqueda, $inicio, $registros_por_pagina)
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombre, documento, fechanac, edad, sexo, ciudad, departamento, telefono, email, padre, docpadre, telpadre, obs, fecha_registro 
            FROM clientes
            WHERE nombre LIKE :busqueda
            ORDER BY nombre ASC
            LIMIT :inicio, :registros_por_pagina";
    $stmt = $bd->prepare($sql);
    $stmt->bindValue(':busqueda', "%$busqueda%", PDO::PARAM_STR);
    $stmt->bindValue(':inicio', (int)$inicio, PDO::PARAM_INT);
    $stmt->bindValue(':registros_por_pagina', (int)$registros_por_pagina, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Cuenta el total de clientes que coinciden con la búsqueda.
 *
 * @param string $busqueda Término de búsqueda.
 * @return int Total de clientes que coinciden.
 */
function contarTotalClientesPorBusqueda($busqueda)
{
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total
            FROM clientes
            WHERE nombre LIKE :busqueda";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':busqueda' => "%$busqueda%"]);
    return $stmt->fetch()->total;
}

/**
 * Agrega una nueva venta para un cliente.
 *
 * @param int $idCliente ID del cliente.
 * @param float $monto Monto de la venta.
 * @param string $fecha Fecha de la venta.
 * @return bool Resultado de la inserción.
 */
function agregarVenta($idCliente, $monto, $fecha)
{
    $bd = obtenerBD();
    $sql = "INSERT INTO ventas_clientes (id_cliente, monto, fecha)
            VALUES (:id_cliente, :monto, :fecha)";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':id_cliente' => $idCliente,
        ':monto' => $monto,
        ':fecha' => $fecha
    ]);
}

/**
 * Calcula el total acumulado de ventas por cliente.
 *
 * @param int $idCliente ID del cliente.
 * @return float Total acumulado.
 */
function totalAcumuladoVentasPorCliente($idCliente)
{
    $bd = obtenerBD();
    $sql = "SELECT COALESCE(SUM(monto), 0) AS total
            FROM ventas_clientes
            WHERE id_cliente = :id_cliente";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id_cliente' => $idCliente]);
    return $stmt->fetch()->total;
}

/**
 * Calcula el total acumulado de ventas por cliente en el último mes.
 *
 * @param int $idCliente ID del cliente.
 * @return float Total acumulado en el último mes.
 */
function totalAcumuladoVentasPorClienteEnUltimoMes($idCliente)
{
    $inicio = date("Y-m-d", strtotime("first day of this month"));
    $bd = obtenerBD();
    $sql = "SELECT COALESCE(SUM(monto), 0) AS total
            FROM ventas_clientes
            WHERE id_cliente = :id_cliente AND fecha >= :inicio";
    $stmt = $bd->prepare($sql);
    $stmt->execute([
        ':id_cliente' => $idCliente,
        ':inicio' => $inicio
    ]);
    return $stmt->fetch()->total;
}

/**
 * Calcula el total acumulado de ventas por cliente en el último año.
 *
 * @param int $idCliente ID del cliente.
 * @return float Total acumulado en el último año.
 */
function totalAcumuladoVentasPorClienteEnUltimoAnio($idCliente)
{
    $inicio = date("Y-01-01");
    $bd = obtenerBD();
    $sql = "SELECT COALESCE(SUM(monto), 0) AS total
            FROM ventas_clientes
            WHERE id_cliente = :id_cliente AND fecha >= :inicio";
    $stmt = $bd->prepare($sql);
    $stmt->execute([
        ':id_cliente' => $idCliente,
        ':inicio' => $inicio
    ]);
    return $stmt->fetch()->total;
}

/**
 * Calcula el total acumulado de ventas por cliente antes del último año.
 *
 * @param int $idCliente ID del cliente.
 * @return float Total acumulado antes del último año.
 */
function totalAcumuladoVentasPorClienteAntesDeUltimoAnio($idCliente)
{
    $inicio = date("Y-01-01");
    $bd = obtenerBD();
    $sql = "SELECT COALESCE(SUM(monto), 0) AS total
            FROM ventas_clientes
            WHERE id_cliente = :id_cliente AND fecha < :inicio";
    $stmt = $bd->prepare($sql);
    $stmt->execute([
        ':id_cliente' => $idCliente,
        ':inicio' => $inicio
    ]);
    return $stmt->fetch()->total;
}

/**
 * Obtiene el número total de clientes.
 *
 * @return int Número total de clientes.
 */
function obtenerNumeroTotalClientes()
{
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) AS conteo FROM clientes";
    $stmt = $bd->query($sql);
    return $stmt->fetch()->conteo;
}

/**
 * Obtiene el número total de clientes registrados en los últimos 30 días.
 *
 * @return int Número de clientes en los últimos 30 días.
 */
function obtenerNumeroTotalClientesUltimos30Dias()
{
    $hace30Dias = date("Y-m-d", strtotime("-30 days"));
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) AS conteo FROM clientes WHERE fecha_registro >= :hace30Dias";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':hace30Dias' => $hace30Dias]);
    return $stmt->fetch()->conteo;
}

/**
 * Obtiene el número total de clientes registrados en el último año.
 *
 * @return int Número de clientes en el último año.
 */
function obtenerNumeroTotalClientesUltimoAnio()
{
    $inicio = date("Y-01-01");
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) AS conteo FROM clientes WHERE fecha_registro >= :inicio";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':inicio' => $inicio]);
    return $stmt->fetch()->conteo;
}

/**
 * Obtiene el número total de clientes registrados antes del último año.
 *
 * @return int Número de clientes antes del último año.
 */
function obtenerNumeroTotalClientesAniosAnteriores()
{
    $inicio = date("Y-01-01");
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) AS conteo FROM clientes WHERE fecha_registro < :inicio";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':inicio' => $inicio]);
    return $stmt->fetch()->conteo;
}

/**
 * Obtiene el total acumulado de ventas.
 *
 * @return float Total de ventas.
 */
function obtenerTotalDeVentas()
{
    $bd = obtenerBD();
    $sql = "SELECT COALESCE(SUM(monto), 0) AS total FROM ventas_clientes";
    $stmt = $bd->query($sql);
    return $stmt->fetch()->total;
}

/**
 * Obtiene la cantidad de clientes por departamento.
 *
 * @return array Lista de departamentos con su conteo de clientes.
 */
function obtenerClientesPorDepartamento()
{
    $bd = obtenerBD();
    $sql = "SELECT departamento, COUNT(*) AS conteo FROM clientes GROUP BY departamento";
    $stmt = $bd->query($sql);
    return $stmt->fetchAll();
}

/**
 * Obtiene el conteo de clientes por rango de edad.
 *
 * @param int $inicio Edad mínima.
 * @param int $fin Edad máxima.
 * @return int Conteo de clientes en el rango de edad.
 */
function obtenerConteoClientesPorRangoDeEdad($inicio, $fin)
{
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) AS conteo FROM clientes WHERE edad >= :inicio AND edad <= :fin";
    $stmt = $bd->prepare($sql);
    $stmt->execute([
        ':inicio' => $inicio,
        ':fin' => $fin
    ]);
    return $stmt->fetch()->conteo;
}

/**
 * Obtiene las ventas del año actual organizadas por mes.
 *
 * @return array Lista de ventas por mes.
 */
function obtenerVentasAnioActualOrganizadasPorMes()
{
    $bd = obtenerBD();
    $anio = date("Y");
    $sql = "SELECT MONTH(fecha) AS mes, COUNT(*) AS total
            FROM ventas_clientes
            WHERE YEAR(fecha) = :anio
            GROUP BY MONTH(fecha)";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':anio' => $anio]);
    return $stmt->fetchAll();
}

/**
 * Obtiene un reporte de clientes por rangos de edad.
 *
 * @return array Lista de reportes de edades.
 */
function obtenerReporteClientesEdades()
{
    $rangos = [
        [1, 10],
        [11, 20],
        [21, 40],
        [41, 80],
    ];
    $resultados = [];
    foreach ($rangos as $rango) {
        $inicio = $rango[0];
        $fin = $rango[1];
        $conteo = obtenerConteoClientesPorRangoDeEdad($inicio, $fin);
        $dato = new stdClass;
        $dato->etiqueta = "$inicio - $fin";
        $dato->valor = $conteo;
        $resultados[] = $dato;
    }
    return $resultados;
}

/**
 * Obtiene todas las tarifas de la base de datos.
 *
 * @return array Lista de tarifas.
 */
function obtenerTarifas()
{
    $bd = obtenerBD();
    $sql = "SELECT id, nombretarifa, actividad, dias, duracion, precio FROM tarifas ORDER BY nombretarifa ASC";
    $stmt = $bd->query($sql);
    return $stmt->fetchAll();
}

/**
 * Busca tarifas por nombre o alguna otra columna.
 *
 * @param string $query Término de búsqueda.
 * @return array Lista de tarifas que coinciden.
 */
function buscarTarifas($query)
{
    $bd = obtenerBD();
    $sql = "SELECT * FROM tarifas WHERE nombretarifa LIKE :query OR alguna_otra_columna LIKE :query ORDER BY nombretarifa ASC";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':query' => "%$query%"]);
    return $stmt->fetchAll();
}

/**
 * Agrega una nueva reserva a la base de datos.
 *
 * @param string $codigo_reserva Código de la reserva.
 * @param string $actividad Actividad de la reserva.
 * @param int $tarifa_id ID de la tarifa.
 * @param string $fecha_reserva Fecha de la reserva.
 * @param string $hora_desde Hora de inicio.
 * @param string $hora_hasta Hora de fin.
 * @param int $cantidad_clientes Cantidad de clientes.
 * @param string $estado Estado de la reserva.
 * @return int ID de la reserva insertada.
 */
function agregarReserva($codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado) {
    $bd = obtenerBD();
    $sql = "INSERT INTO reservas (codigo_reserva, actividad, tarifa_id, fecha_reserva, hora_desde, hora_hasta, cantidad_clientes, estado)
            VALUES (:codigo_reserva, :actividad, :tarifa_id, :fecha_reserva, :hora_desde, :hora_hasta, :cantidad_clientes, :estado)";
    $stmt = $bd->prepare($sql);
    $stmt->execute([
        ':codigo_reserva' => $codigo_reserva,
        ':actividad' => $actividad,
        ':tarifa_id' => $tarifa_id,
        ':fecha_reserva' => $fecha_reserva,
        ':hora_desde' => $hora_desde,
        ':hora_hasta' => $hora_hasta,
        ':cantidad_clientes' => $cantidad_clientes,
        ':estado' => $estado
    ]);
    return $bd->lastInsertId();
}

/**
 * Asocia clientes a una reserva.
 *
 * @param int $reserva_id ID de la reserva.
 * @param array $clientes Array de IDs de clientes.
 * @param array $identificaciones Array de identificaciones correspondientes.
 * @return bool Resultado de la inserción.
 */
/**
 * Asocia múltiples clientes a una reserva.
 *
 * @param int $reserva_id ID de la reserva.
 * @param array $cliente_ids Array de IDs de clientes.
 * @param array $identificaciones Array de identificaciones correspondientes.
 * @param array $pulseras Array de pulseras correspondientes.
 * @return bool Resultado de la inserción.
 */
function asociarClientesReserva($reserva_id, $cliente_ids, $identificaciones, $pulseras) {
    $bd = obtenerBD();
    $sql = "INSERT INTO clientes_reserva (reserva_id, cliente_id, nombre, identificacion, pulsera)
            VALUES (:reserva_id, :cliente_id, :nombre, :identificacion, :pulsera)";
    $stmt = $bd->prepare($sql);

    foreach ($cliente_ids as $index => $cliente_id) {
        // Obtener el nombre del cliente desde la tabla 'clientes'
        $nombre = obtenerNombreCliente($cliente_id);
        // Asegurarse de que existan identificaciones y pulseras para cada cliente
        $identificacion = isset($identificaciones[$index]) ? $identificaciones[$index] : '';
        $pulsera = isset($pulseras[$index]) ? $pulseras[$index] : '';
        $stmt->execute([
            ':reserva_id' => $reserva_id,
            ':cliente_id' => $cliente_id,
            ':nombre' => $nombre,
            ':identificacion' => $identificacion,
            ':pulsera' => $pulsera
        ]);
    }

    return true;
}

/**
 * Obtiene el nombre de un cliente dado su ID.
 *
 * @param int $cliente_id ID del cliente.
 * @return string Nombre del cliente.
 */
function obtenerNombreCliente($cliente_id) {
    $bd = obtenerBD();
    $sql = "SELECT nombre FROM clientes WHERE id = :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $cliente_id]);
    $result = $stmt->fetch(PDO::FETCH_OBJ);
    return $result ? $result->nombre : '';
}

function obtenerReservaPorId($id) {
    try {
        // Obtener la conexión a la base de datos
        $bd = obtenerBD(); // Asegúrate de que esta función retorna una instancia válida de PDO

        // Preparar la consulta para obtener los detalles de la reserva
        $sqlReserva = "SELECT 
                            r.id,
                            r.codigo_reserva,
                            r.actividad,
                            r.tarifa_id,
                            r.fecha_reserva,
                            r.hora_desde,
                            r.hora_hasta,
                            r.cantidad_clientes,
                            r.estado
                       FROM reservas r
                       WHERE r.id = :id";
        $stmtReserva = $bd->prepare($sqlReserva);
        $stmtReserva->bindParam(':id', $id, PDO::PARAM_INT);
        $stmtReserva->execute();
        $reserva = $stmtReserva->fetch(PDO::FETCH_OBJ);

        if (!$reserva) {
            // Reserva no encontrada
            return null;
        }

        // Preparar la consulta para obtener los clientes asociados a la reserva
        $sqlClientes = "SELECT 
                            cr.cliente_id,
                            c.nombre,
                            c.telefono,
                            cr.identificacion,
                            cr.pulsera
                        FROM clientes_reserva cr
                        JOIN clientes c ON cr.cliente_id = c.id
                        WHERE cr.reserva_id = :id";
        $stmtClientes = $bd->prepare($sqlClientes);
        $stmtClientes->bindParam(':id', $id, PDO::PARAM_INT);
        $stmtClientes->execute();
        $clientes = $stmtClientes->fetchAll(PDO::FETCH_OBJ);

        // Asignar los clientes al objeto de reserva
        $reserva->clientes = $clientes;

        return $reserva;
    } catch (PDOException $e) {
        // Manejar errores de la base de datos
        error_log("Error en obtenerReservaPorId: " . $e->getMessage());
        return null;
    }
}

function eliminarReserva($id)
{
    $bd = obtenerBD();
    $sql = "DELETE FROM reservas WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([':id' => $id]);
}

/**
 * Elimina los clientes asociados a una reserva.
 *
 * @param int $reserva_id ID de la reserva.
 * @return bool Resultado de la eliminación.
 */
function eliminarClientesReserva($reserva_id)
{
    $bd = obtenerBD();
    $sql = "DELETE FROM clientes_reserva WHERE reserva_id = :reserva_id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([':reserva_id' => $reserva_id]);
}

/**
 * Elimina un producto por su ID.
 *
 * @param int $id ID del producto.
 * @return bool Resultado de la eliminación.
 */
function eliminarProducto($id)
{
    $bd = obtenerBD();
    $sql = "DELETE FROM productos WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([':id' => $id]);
}
/**
 * Obtiene una venta por su código de reserva.
 *
 * @param string $codigoReserva Código de reserva.
 * @return object|null Datos de la venta o null si no existe.
 */
function obtenerVentaPorCodigoReserva($codigoReserva)
{
    try {
        $bd = obtenerBD();
        $sql = "SELECT * FROM ventas_clientes WHERE codigo_reserva = :codigo_reserva LIMIT 1";
        $stmt = $bd->prepare($sql);
        $stmt->execute([':codigo_reserva' => $codigoReserva]);
        $venta = $stmt->fetch();
        return $venta ? $venta : null;
    } catch (PDOException $e) {
        die("Error al obtener la venta: " . $e->getMessage());
    }
}

/**
 * Obtiene una reserva por su ID.
 *
 * @param int $idReserva ID de la reserva.
 * @return object|null Datos de la reserva o null si no existe.
 */
/**
 * Obtiene una reserva específica por ID, incluyendo opcionalmente los clientes asociados.
 *
 * @param int $reserva_id ID de la reserva.
 * @param bool $include_clients Indica si se deben incluir los clientes asociados.
 * @return object|false Objeto de la reserva (con clientes si $include_clients es true), o false si no existe.
 */
function obtenerReserva($reserva_id, $include_clients = false) {
    $bd = obtenerBD();
    
    // Obtener los detalles de la reserva
    $sql = "SELECT * FROM reservas WHERE id = :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $reserva_id]);
    $reserva = $stmt->fetch();
    
    if ($reserva && $include_clients) {
        // Obtener los clientes asociados si se solicita
        $sql_clientes = "SELECT cliente_id, identificacion, pulsera FROM clientes_reserva WHERE reserva_id = :reserva_id";
        $stmt_clientes = $bd->prepare($sql_clientes);
        $stmt_clientes->execute([':reserva_id' => $reserva_id]);
        $reserva->clientes = $stmt_clientes->fetchAll();
    }
    
    return $reserva;
}
/**
 * Actualiza una reserva existente en la base de datos.
 *
 * @param int $reserva_id ID de la reserva a actualizar.
 * @param string $codigo_reserva Nuevo código de reserva.
 * @param string $actividad Nueva actividad de la reserva.
 * @param int $tarifa_id Nuevo ID de la tarifa seleccionada.
 * @param string $fecha_reserva Nueva fecha de la reserva.
 * @param string $hora_desde Nueva hora de inicio.
 * @param string $hora_hasta Nueva hora de fin.
 * @param int $cantidad_clientes Nueva cantidad de clientes.
 * @param string $estado Nuevo estado de la reserva.
 * @return bool Resultado de la actualización (true si fue exitosa, false en caso contrario).
 */
function actualizarReserva($reserva_id, $codigo_reserva, $actividad, $tarifa_id, $fecha_reserva, $hora_desde, $hora_hasta, $cantidad_clientes, $estado) {
    $bd = obtenerBD();
    $sql = "UPDATE reservas SET 
                codigo_reserva = :codigo_reserva,
                actividad = :actividad,
                tarifa_id = :tarifa_id,
                fecha_reserva = :fecha_reserva,
                hora_desde = :hora_desde,
                hora_hasta = :hora_hasta,
                cantidad_clientes = :cantidad_clientes,
                estado = :estado
            WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':codigo_reserva' => $codigo_reserva,
        ':actividad' => $actividad,
        ':tarifa_id' => $tarifa_id,
        ':fecha_reserva' => $fecha_reserva,
        ':hora_desde' => $hora_desde,
        ':hora_hasta' => $hora_hasta,
        ':cantidad_clientes' => $cantidad_clientes,
        ':estado' => $estado,
        ':id' => $reserva_id
    ]);
}
function registrarEntrada($codigo_reserva)
{
    try {
        $bd = obtenerBD();

        // Obtener la cantidad de clientes desde la reserva vinculada
        $sqlCantidadClientes = "
            SELECT r.cantidad_clientes 
            FROM reservas r
            JOIN ventas_clientes v ON v.reserva_id = r.id
            WHERE v.codigo_reserva = :codigo_reserva
        ";
        $stmt = $bd->prepare($sqlCantidadClientes);
        $stmt->execute([':codigo_reserva' => $codigo_reserva]);
        $reserva = $stmt->fetch();

        if (!$reserva) {
            throw new Exception("No se encontró la cantidad de clientes para el código de reserva proporcionado.");
        }

        $cantidad_clientes = $reserva->cantidad_clientes;

        // Insertar el registro de entrada
        $sqlInsert = "
            INSERT INTO registro_reservas (codigo_reserva, fecha_hora_entrada, estado, cantidad_clientes)
            VALUES (:codigo_reserva, NOW(), 'activo', :cantidad_clientes)
        ";
        $stmtInsert = $bd->prepare($sqlInsert);
        return $stmtInsert->execute([
            ':codigo_reserva' => $codigo_reserva,
            ':cantidad_clientes' => $cantidad_clientes
        ]);
    } catch (Exception $e) {
        die("Error al registrar entrada: " . $e->getMessage());
    }
}

/**
 * Registra la salida de una reserva.
 *
 * @param string $codigo_reserva Código de reserva.
 * @return bool Resultado de la actualización.
 */
function registrarSalida($codigo_reserva)
{
    try {
        $bd = obtenerBD();
        $sql = "UPDATE registro_reservas 
                SET fecha_hora_salida = NOW(), estado = 'finalizado' 
                WHERE codigo_reserva = :codigo_reserva AND estado = 'activo'";
        $stmt = $bd->prepare($sql);
        return $stmt->execute([':codigo_reserva' => $codigo_reserva]);
    } catch (PDOException $e) {
        die("Error al registrar salida: " . $e->getMessage());
    }
}

/**
 * Obtiene los registros activos de reservas.
 *
 * @return array Lista de registros activos.
 */
function obtenerRegistrosActivos()
{
    try {
        $bd = obtenerBD();
        $sql = "SELECT * FROM registro_reservas WHERE estado = 'activo' ORDER BY fecha_hora_entrada ASC";
        $stmt = $bd->query($sql);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        die("Error al obtener registros activos: " . $e->getMessage());
    }
}

/**
 * Busca un registro activo por código de reserva.
 *
 * @param string $codigo_reserva Código de reserva.
 * @return object|null Datos del registro o null si no existe.
 */
function buscarRegistroActivo($codigo_reserva)
{
    $bd = obtenerBD();
    $sql = "SELECT * FROM registro_reservas WHERE codigo_reserva = :codigo_reserva AND estado = 'activo'";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':codigo_reserva' => $codigo_reserva]);
    return $stmt->fetch();
}

/**
 * Obtiene los clientes asociados a una reserva específica.
 *
 * @param int $reserva_id ID de la reserva.
 * @return array Lista de clientes.
 */
function obtenerClientesReserva($reserva_id)
{
    $bd = obtenerBD();
    $sql = "SELECT cr.cliente_id, c.nombre, cr.identificacion
            FROM clientes_reserva cr
            JOIN clientes c ON cr.cliente_id = c.id
            WHERE cr.reserva_id = :reserva_id
            ORDER BY c.nombre ASC";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':reserva_id' => $reserva_id]);
    return $stmt->fetchAll();
}

/**
 * Agrega una bonificación a la base de datos.
 *
 * @param string $nombre Nombre de la bonificación.
 * @param float $descuento Descuento de la bonificación.
 * @return bool Resultado de la inserción.
 */
function agregarBonificacion($nombre, $descuento)
{
    $bd = obtenerBD();
    $sql = "INSERT INTO bonificaciones (nombre, descuento)
            VALUES (:nombre, :descuento)";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':nombre' => $nombre,
        ':descuento' => $descuento
    ]);
}

/**
 * Obtiene todas las bonificaciones de la base de datos.
 *
 * @return array Lista de bonificaciones.
 */
function obtenerBonificaciones()
{
    $bd = obtenerBD();
    $sql = "SELECT * FROM bonificaciones ORDER BY nombre ASC";
    $stmt = $bd->query($sql);
    return $stmt->fetchAll();
}

/**
 * Obtiene una bonificación por su ID.
 *
 * @param int $id ID de la bonificación.
 * @return object|null Bonificación o null si no existe.
 */
function obtenerBonificacionPorId($id)
{
    $bd = obtenerBD();
    $sql = "SELECT * FROM bonificaciones WHERE id = :id";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}
function obtenerBonificacion($bonificacion_id) {
    $bd = obtenerBD(); // Asegúrate de que obtenerBD() retorna tu conexión PDO
    $sql = "SELECT descuento FROM bonificaciones WHERE id = :id LIMIT 1";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':id' => $bonificacion_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['descuento'] : 0;
}


/**
 * Actualiza una bonificación.
 *
 * @param int $id ID de la bonificación.
 * @param string $nombre Nombre de la bonificación.
 * @param float $descuento Descuento de la bonificación.
 * @return bool Resultado de la actualización.
 */
function actualizarBonificacion($id, $nombre, $descuento)
{
    $bd = obtenerBD();
    $sql = "UPDATE bonificaciones
            SET nombre = :nombre,
                descuento = :descuento
            WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':nombre' => $nombre,
        ':descuento' => $descuento,
        ':id' => $id
    ]);
}

/**
 * Elimina una bonificación por su ID.
 *
 * @param int $id ID de la bonificación.
 * @return bool Resultado de la eliminación.
 */
function eliminarBonificacion($id)
{
    $bd = obtenerBD();
    $sql = "DELETE FROM bonificaciones WHERE id = :id";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([':id' => $id]);
}

function obtenerProductosPaginados($query, $inicio, $registrosPorPagina) {
    $bd = obtenerBD();  // obtenerBD() es tu función para acceder a la conexión PDO
    
    $sql = "SELECT id,
                   nombre,
                   precio,
                   costo,
                   stock,
                   unidad_medida
            FROM productos
            WHERE nombre LIKE :busqueda
            ORDER BY id DESC
            LIMIT :inicio, :registros";

    $stmt = $bd->prepare($sql);
    // Preparar el %query% para buscar en nombre
    $busqueda = "%$query%";

    // Enlazar parámetros
    $stmt->bindParam(':busqueda', $busqueda, PDO::PARAM_STR);
    $stmt->bindParam(':inicio', $inicio, PDO::PARAM_INT);
    $stmt->bindParam(':registros', $registrosPorPagina, PDO::PARAM_INT);

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function contarTotalProductos($query) {
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total FROM productos
            WHERE nombre LIKE :busqueda";
    $stmt = $bd->prepare($sql);
    $busqueda = "%$query%";
    $stmt->bindParam(':busqueda', $busqueda, PDO::PARAM_STR);
    $stmt->execute();
    $fila = $stmt->fetch(PDO::FETCH_ASSOC);
    return $fila['total'] ?? 0;
}
/**
 * Obtiene reservas con paginación y búsqueda.
 *
 * @param string $busqueda Término de búsqueda.
 * @param int $inicio Inicio de la paginación.
 * @param int $registros_por_pagina Número de registros por página.
 * @return array Lista de reservas.
 */
function obtenerReservasPaginadas($busqueda = '', $inicio = 0, $registros_por_pagina = 10)
{
    $bd = obtenerBD();
    if (!empty($busqueda)) {
        $sql = "SELECT r.id, r.codigo_reserva, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, r.estado,
                       (SELECT c.nombre 
                        FROM clientes c 
                        JOIN clientes_reserva cr ON c.id = cr.cliente_id 
                        WHERE cr.reserva_id = r.id 
                        LIMIT 1
                       ) AS cliente_nombre
                FROM reservas r
                WHERE r.codigo_reserva LIKE :busqueda
                ORDER BY r.fecha_reserva DESC, r.estado ASC
                LIMIT :inicio, :registros_por_pagina";
    } else {
        $sql = "SELECT r.id, r.codigo_reserva, r.fecha_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, r.estado,
                       (SELECT c.nombre 
                        FROM clientes c 
                        JOIN clientes_reserva cr ON c.id = cr.cliente_id 
                        WHERE cr.reserva_id = r.id 
                        LIMIT 1
                       ) AS cliente_nombre
                FROM reservas r
                ORDER BY r.fecha_reserva DESC, r.estado ASC
                LIMIT :inicio, :registros_por_pagina";
    }

    $stmt = $bd->prepare($sql);

    if (!empty($busqueda)) {
        $stmt->bindValue(':busqueda', "%$busqueda%", PDO::PARAM_STR);
    }
    $stmt->bindValue(':inicio', (int)$inicio, PDO::PARAM_INT);
    $stmt->bindValue(':registros_por_pagina', (int)$registros_por_pagina, PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetchAll();
}

/**
 * Cuenta el total de reservas, con o sin búsqueda.
 *
 * @param string $busqueda Término de búsqueda.
 * @return int Total de reservas.
 */
function contarTotalReservas($busqueda = '')
{
    $bd = obtenerBD();
    if (!empty($busqueda)) {
        $sql = "SELECT COUNT(*) as total
                FROM reservas
                WHERE codigo_reserva LIKE :busqueda";
        $stmt = $bd->prepare($sql);
        $stmt->execute([':busqueda' => "%$busqueda%"]);
    } else {
        $sql = "SELECT COUNT(*) as total FROM reservas";
        $stmt = $bd->query($sql);
    }
    return $stmt->fetch()->total;
}

/**
 * Obtiene todas las bonificaciones disponibles.
 *
 * @return array Lista de bonificaciones.
 */
function obtenerBonificacionesDisponibles()
{
    return obtenerBonificaciones();
}

/**
 * Añade un producto a la venta (detalle de venta).
 *
 * @param int $venta_id ID de la venta.
 * @param int $producto_id ID del producto.
 * @param int $cantidad Cantidad vendida.
 * @param float $precio_unitario Precio unitario del producto.
 * @return bool Resultado de la inserción.
 */
function agregarDetalleVenta($venta_id, $producto_id, $cantidad, $precio_unitario)
{
    $bd = obtenerBD();
    $sql = "INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario)
            VALUES (:venta_id, :producto_id, :cantidad, :precio_unitario)";
    $stmt = $bd->prepare($sql);
    return $stmt->execute([
        ':venta_id' => $venta_id,
        ':producto_id' => $producto_id,
        ':cantidad' => $cantidad,
        ':precio_unitario' => $precio_unitario
    ]);
}

// Obtener compras paginadas
function obtenerComprasPaginadas($busqueda = '', $inicio = 0, $registros_por_pagina = 10) {
    $pdo = obtenerBD();
    $sql = "SELECT ms.id, p.nombre AS producto, ms.cantidad, ms.fecha 
            FROM movimientos_stock ms
            JOIN productos p ON ms.producto_id = p.id
            WHERE ms.tipo_movimiento = 'COMPRA' AND p.nombre LIKE :busqueda
            ORDER BY ms.fecha DESC 
            LIMIT :inicio, :limite";
    
    $stmt = $pdo->prepare($sql);
    $busqueda = "%$busqueda%";
    $stmt->bindParam(':busqueda', $busqueda, PDO::PARAM_STR);
    $stmt->bindParam(':inicio', $inicio, PDO::PARAM_INT);
    $stmt->bindParam(':limite', $registros_por_pagina, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Contar total de compras para la paginación
function contarTotalCompras($busqueda = '') {
    $pdo = obtenerBD();
    $sql = "SELECT COUNT(*) as total 
            FROM movimientos_stock ms
            JOIN productos p ON ms.producto_id = p.id
            WHERE ms.tipo_movimiento = 'COMPRA' AND p.nombre LIKE :busqueda";
    
    $stmt = $pdo->prepare($sql);
    $busqueda = "%$busqueda%";
    $stmt->bindParam(':busqueda', $busqueda, PDO::PARAM_STR);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'];
}
function obtenerProductos() {
    $pdo = obtenerBD();
    $sql = "SELECT id, nombre, unidad_medida FROM productos";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
// Obtener listado de cajas
function obtenerCajas() {
    global $conn;
    $query = "SELECT c.id, c.fecha, c.forma_pago, c.credito, c.debito, c.descripcion, col.nombre AS colaborador 
              FROM cajas c 
              LEFT JOIN colaboradores col ON c.id_colaborador = col.id
              ORDER BY c.fecha DESC";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Agregar una nueva caja
function agregarCaja($fecha, $id_colaborador, $forma_pago, $credito, $debito, $descripcion) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO cajas (fecha, id_colaborador, forma_pago, credito, debito, descripcion) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sissss", $fecha, $id_colaborador, $forma_pago, $credito, $debito, $descripcion);
    return $stmt->execute();
}

// Obtener caja por ID
function obtenerCajaPorId($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM cajas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Editar caja existente
function editarCaja($id, $fecha, $id_colaborador, $forma_pago, $credito, $debito, $descripcion) {
    global $conn;
    $stmt = $conn->prepare("UPDATE cajas SET fecha = ?, id_colaborador = ?, forma_pago = ?, credito = ?, debito = ?, descripcion = ? WHERE id = ?");
    $stmt->bind_param("sissssi", $fecha, $id_colaborador, $forma_pago, $credito, $debito, $descripcion, $id);
    return $stmt->execute();
}

// Eliminar caja por ID
function eliminarCaja($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM cajas WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

// Generar informe de cajas en un rango de fechas
function obtenerInformeCajas($fecha_desde, $fecha_hasta) {
    global $conn;
    $stmt = $conn->prepare("SELECT c.fecha, c.forma_pago, c.credito, c.debito, c.descripcion, col.nombre AS colaborador 
                            FROM cajas c
                            LEFT JOIN colaboradores col ON c.id_colaborador = col.id
                            WHERE c.fecha BETWEEN ? AND ?
                            ORDER BY c.fecha ASC");
    $stmt->bind_param("ss", $fecha_desde, $fecha_hasta);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Obtener listado de colaboradores para Select2
function obtenerColaboradores() {
    global $conn;
    $query = "SELECT id, nombre FROM colaboradores ORDER BY nombre ASC";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function generarCodigoReserva() {
    return 'CR' . date('dmyHis'); // ddmmyyHis
}

function codigoReservaExiste($codigo_reserva) {
    $bd = obtenerBD();
    $sql = "SELECT COUNT(*) as total FROM reservas WHERE codigo_reserva = :codigo_reserva";
    $stmt = $bd->prepare($sql);
    $stmt->execute([':codigo_reserva' => $codigo_reserva]);
    $result = $stmt->fetch(PDO::FETCH_OBJ);
    return $result->total > 0;
}
/**
 * Obtiene la lista de usuarios.
 *
 * @return array Lista de usuarios con sus id y nombre.
 */
function obtenerUsuarios() {
    $bd = obtenerBD();
    $sql = "SELECT id, nombre FROM usuarios ORDER BY nombre ASC";
    $stmt = $bd->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function obtenerTarifasVendidas($fecha_inicio, $fecha_fin, $usuario_filter) {
    $pdo = obtenerBD();
    $sql = "SELECT t.nombretarifa AS nombre, 
                   SUM(r.cantidad_clientes) AS cantidad_vendida, 
                   SUM(v.totaltarifas) AS total_tarifas
            FROM ventas v
            JOIN reservas r ON v.reserva_id = r.id
            JOIN tarifas t ON r.tarifa_id = t.id
            WHERE v.fecha BETWEEN :fecha_inicio AND :fecha_fin";
    if ($usuario_filter > 0) {
         $sql .= " AND v.usuario_id = :usuario_filter";
    }
    $sql .= " GROUP BY t.nombretarifa";
    $stmt = $pdo->prepare($sql);
    $params = [
         ':fecha_inicio' => $fecha_inicio,
         ':fecha_fin' => $fecha_fin
    ];
    if ($usuario_filter > 0) {
         $params[':usuario_filter'] = $usuario_filter;
    }
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function obtenerProductosVendidos($fecha_inicio, $fecha_fin, $usuario_filter) {
    $pdo = obtenerBD();
    $sql = "SELECT p.nombre, 
                   SUM(dv.cantidad) AS cantidad_vendida, 
                   SUM(dv.cantidad * dv.precio_unitario) AS total_vendido
            FROM detalle_ventas dv
            JOIN productos p ON dv.producto_id = p.id
            JOIN ventas v ON dv.venta_id = v.id
            WHERE v.fecha BETWEEN :fecha_inicio AND :fecha_fin";
    if ($usuario_filter > 0) {
         $sql .= " AND v.usuario_id = :usuario_filter";
    }
    $sql .= " GROUP BY p.nombre";
    $stmt = $pdo->prepare($sql);
    $params = [
         ':fecha_inicio' => $fecha_inicio,
         ':fecha_fin' => $fecha_fin
    ];
    if ($usuario_filter > 0) {
         $params[':usuario_filter'] = $usuario_filter;
    }
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function obtenerMovimientosStock($fecha_inicio, $fecha_fin, $id_producto) {
    // Incluir el archivo de conexión y obtener la conexión PDO
    require_once 'conexion.php';
    $conn = obtenerbd();

    // Construir la consulta base
    $sql = "SELECT m.id, p.nombre AS producto, m.fecha, m.tipo_movimiento, m.cantidad
            FROM movimientos_stock m
            INNER JOIN productos p ON m.producto_id = p.id
            WHERE 1=1";
    
    // Array para almacenar parámetros
    $params = [];

    // Agregar condiciones según los filtros recibidos
    if (!empty($fecha_inicio)) {
        $sql .= " AND m.fecha >= :fecha_inicio";
        $params[':fecha_inicio'] = $fecha_inicio;
    }
    if (!empty($fecha_fin)) {
        $sql .= " AND m.fecha <= :fecha_fin";
        $params[':fecha_fin'] = $fecha_fin;
    }
    if (!empty($id_producto)) {
        $sql .= " AND m.producto_id = :id_producto";
        $params[':id_producto'] = $id_producto;
    }

    // Ordenar resultados por fecha descendente
    $sql .= " ORDER BY m.fecha DESC";

    // Preparar la consulta
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error en la preparación: " . print_r($conn->errorInfo(), true));
    }

    // Ejecutar la consulta con los parámetros
    $stmt->execute($params);

    // Obtener todos los resultados en un arreglo asociativo
    $movimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Cerrar la conexión (opcional, ya que PDO se cierra automáticamente al finalizar el script)
    $conn = null;

    return $movimientos;
}
function obtenerProveedores() {
    $pdo = obtenerBD();
    $stmt = $pdo->query("SELECT id, nombre FROM proveedores WHERE activo = 1 ORDER BY nombre ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function obtenerTodasLasComprasConDetalle($desde = null, $hasta = null, $proveedor_id = null, $producto_id = null) {
    $conn = obtenerBD();

    if (!$desde) $desde = '2000-01-01';
    if (!$hasta) $hasta = date('Y-m-d');

    $sql = "
        SELECT 
            c.id AS compra_id,
            c.nro_factura,
            c.fecha_compra AS fecha,
            p.nombre AS proveedor,
            pr.id AS producto_id,
            pr.nombre AS nombre,
            pr.unidad_medida,
            pr.stock AS stock_actual,
            d.cantidad,
            d.costo_unitario
        FROM compras c
        JOIN proveedores p ON c.proveedor_id = p.id
        JOIN detalle_compras d ON c.id = d.compra_id
        JOIN productos pr ON d.producto_id = pr.id
        WHERE c.fecha_compra BETWEEN :desde AND :hasta
    ";

    $parametros = [
        ':desde' => $desde,
        ':hasta' => $hasta
    ];

    if ($proveedor_id) {
        $sql .= " AND c.proveedor_id = :proveedor_id";
        $parametros[':proveedor_id'] = $proveedor_id;
    }

    if ($producto_id) {
        $sql .= " AND d.producto_id = :producto_id";
        $parametros[':producto_id'] = $producto_id;
    }

    $sql .= " ORDER BY c.fecha_compra DESC, c.id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($parametros);
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Agrupar productos por compra
    $comprasAgrupadas = [];

    foreach ($resultado as $fila) {
        $id = $fila['compra_id'];
        if (!isset($comprasAgrupadas[$id])) {
            $comprasAgrupadas[$id] = [
                'id' => $id,
                'nro_factura' => $fila['nro_factura'],
                'fecha' => $fila['fecha'],
                'proveedor' => $fila['proveedor'],
                'productos' => []
            ];
        }

        $comprasAgrupadas[$id]['productos'][] = [
            'producto_id' => $fila['producto_id'],
            'nombre' => $fila['nombre'],
            'unidad_medida' => $fila['unidad_medida'],
            'stock_actual' => $fila['stock_actual'],
            'cantidad' => $fila['cantidad'],
            'costo_unitario' => $fila['costo_unitario']
        ];
    }

    return array_values($comprasAgrupadas);
}
function obtenerDetalleCompras($desde = '2000-01-01', $hasta = null, $proveedor_id = null, $producto_id = null) {
    $pdo = obtenerBD();
    
    if (!$hasta) {
        $hasta = date('Y-m-d');
    }
    
    $sql = "
        SELECT 
            c.id AS compra_id,
            c.nro_factura,
            c.fecha_compra AS fecha,
            prov.nombre AS proveedor,
            prod.nombre AS producto,
            prod.unidad_medida,
            d.cantidad,
            prod.stock AS stock_actual,
            d.costo_unitario
        FROM compras c
        JOIN proveedores prov ON c.proveedor_id = prov.id
        JOIN detalle_compras d ON c.id = d.compra_id
        JOIN productos prod ON d.producto_id = prod.id
        WHERE c.fecha_compra BETWEEN :desde AND :hasta
    ";
    
    $parametros = [
        ':desde' => $desde,
        ':hasta' => $hasta
    ];
    
    if (!empty($proveedor_id) && $proveedor_id !== 'todos') {
        $sql .= " AND c.proveedor_id = :proveedor_id";
        $parametros[':proveedor_id'] = $proveedor_id;
    }
    
    if (!empty($producto_id) && $producto_id !== 'todos') {
        $sql .= " AND d.producto_id = :producto_id";
        $parametros[':producto_id'] = $producto_id;
    }
    
    $sql .= " ORDER BY c.fecha_compra DESC, c.id DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($parametros);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function obtenerTarifasPorDia($dia)
    {
        $bd  = obtenerBD();
        $sql = "SELECT *
                FROM tarifas
                WHERE FIND_IN_SET(:dia, dias)
                ORDER BY actividad, nombretarifa";
        $st  = $bd->prepare($sql);
        $st->execute([':dia' => $dia]);
        return $st->fetchAll(PDO::FETCH_OBJ);
    }

?>