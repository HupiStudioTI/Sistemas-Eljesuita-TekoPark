<?php
include_once "funciones.php";

try {
    // Conexión a la base de datos
    $conn = obtenerBD();

    // Simulación de la lectura del QR (reemplazar por código que lea el QR real)
    if (isset($_POST['codigo_qr'])) {
        $codigo_qr = $_POST['codigo_qr'];

        // Validar si contiene "VentaÑ" o ":"
        if (!empty($codigo_qr)) {
            if (strpos($codigo_qr, 'VentaÑ') !== false) {
                // Si contiene "VentaÑ", extraer el ID de venta
                $venta_id = trim(substr($codigo_qr, strpos($codigo_qr, 'VentaÑ') + strlen('VentaÑ')));
            } elseif (strpos($codigo_qr, ':') !== false) {
                // Si contiene ":", extraer el ID de venta
                $venta_id = trim(substr($codigo_qr, strpos($codigo_qr, ':') + 1));
            } else {
                // Si no contiene ninguno de los dos, tratar de encontrar el último número en la cadena
                $venta_id = preg_replace('/\D/', '', $codigo_qr); // Extrae solo los dígitos
            }

            // Consultar los datos de la venta
            $stmt = $conn->prepare("SELECT v.*, r.codigo_reserva, r.hora_desde, r.hora_hasta, r.cantidad_clientes, c.nombre AS primer_cliente 
                                    FROM ventas v
                                    LEFT JOIN reservas r ON v.reserva_id = r.id
                                    LEFT JOIN clientes_reserva cr ON cr.reserva_id = r.id
                                    LEFT JOIN clientes c ON cr.cliente_id = c.id
                                    WHERE v.id = ? 
                                    LIMIT 1");
            $stmt->bindParam(1, $venta_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $venta = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($venta) {
                // Mostrar los datos de la venta
                echo "<h1>Datos de la Venta</h1>";
                echo "<p><strong>ID Venta:</strong> " . htmlspecialchars($venta_id) . "</p>";
                echo "<p><strong>Código Reserva:</strong> " . htmlspecialchars($venta['codigo_reserva']) . "</p>";
                echo "<p><strong>Hora Desde:</strong> " . htmlspecialchars($venta['hora_desde']) . "</p>";
                echo "<p><strong>Hora Hasta:</strong> " . htmlspecialchars($venta['hora_hasta']) . "</p>";
                echo "<p><strong>Color:</strong> " . htmlspecialchars($venta['color']) . "</p>";
                echo "<p><strong>Primer Cliente:</strong> " . htmlspecialchars($venta['primer_cliente']) . "</p>";
            } else {
                echo "No se encontraron datos para esta venta.";
            }
        } else {
            echo "Código QR inválido.";
        }
    } else {
        echo "No se ha enviado un código QR válido.";
    }
} catch (PDOException $e) {
    echo "Error en la base de datos: " . $e->getMessage();
}
?>

<!-- Formulario para simular la lectura del QR -->
<form method="POST" action="leer_ticket.php">
    <label for="codigo_qr">Código QR:</label>
    <input type="text" id="codigo_qr" name="codigo_qr" placeholder="Ingrese el código QR">
    <button type="submit">Buscar</button>
</form>
